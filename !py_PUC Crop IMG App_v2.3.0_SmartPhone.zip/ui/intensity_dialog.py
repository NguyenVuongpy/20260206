from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton, 
                           QLabel, QFileDialog, QLineEdit, QProgressBar, QWidget,
                           QMessageBox, QFrame, QApplication,
                           QTextEdit, QTableWidget, QTableWidgetItem, QScrollArea,
                           QGroupBox, QListWidget, QInputDialog, QTabWidget, QCheckBox)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QFont, QIcon, QColor
import os
from PIL import Image
import numpy as np
import re
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import json
import shutil

class PatternManagementDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pattern Management")
        self.resize(400, 500)
        self.setup_ui()
        self.load_patterns()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(15, 15, 15, 15)

        # Tab widget
        tab_widget = QTabWidget()
        
        # Mono tab
        mono_tab = QWidget()
        mono_layout = QVBoxLayout(mono_tab)
        
        self.mono_list = QListWidget()
        self.mono_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #dcdde1;
                border-radius: 3px;
                padding: 5px;
            }
            QListWidget::item {
                padding: 5px;
                border-bottom: 1px solid #f0f0f0;
            }
            QListWidget::item:selected {
                background-color: #3498db;
                color: white;
            }
        """)
        mono_layout.addWidget(self.mono_list)

        # Color tab
        color_tab = QWidget()
        color_layout = QVBoxLayout(color_tab)
        
        self.color_list = QListWidget()
        self.color_list.setStyleSheet(self.mono_list.styleSheet())
        color_layout.addWidget(self.color_list)

        # Add tabs
        tab_widget.addTab(mono_tab, "Mono Patterns")
        tab_widget.addTab(color_tab, "Color Patterns")
        layout.addWidget(tab_widget)

        # Buttons for both tabs
        btn_layout = QHBoxLayout()
        
        add_btn = QPushButton("Add")
        edit_btn = QPushButton("Edit")
        remove_btn = QPushButton("Remove")
        
        for btn, icon_name in [(add_btn, "add"), (edit_btn, "editing"), (remove_btn, "delete")]:
            btn.setIcon(QIcon(f":/icons/{icon_name}.png"))
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #3498db;
                    color: white;
                    border: none;
                    border-radius: 3px;
                    padding: 5px 15px;
                    font-size: 11px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #2980b9;
                }
            """)
            btn_layout.addWidget(btn)

        add_btn.clicked.connect(lambda: self.add_pattern(tab_widget.currentIndex()))
        edit_btn.clicked.connect(lambda: self.edit_pattern(tab_widget.currentIndex()))
        remove_btn.clicked.connect(lambda: self.remove_pattern(tab_widget.currentIndex()))
        
        layout.addLayout(btn_layout)

        # Close button
        close_btn = QPushButton("Close")
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #95a5a6;
                color: white;
                border: none;
                border-radius: 3px;
                padding: 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #7f8c8d;
            }
        """)
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def load_patterns(self):
        try:
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
                    patterns = config.get('patterns', {})
                    
                    # Load mono patterns
                    mono_patterns = patterns.get('mono', [
                        'B064', 'B072', 'B384', 'B432',
                        'G064', 'G072', 'G384', 'G432',
                        'R064', 'R072', 'R384', 'R432',
                        'B020', 'B024',
                        'G020', 'G024',
                        'R020', 'R024',
                        'W062'
                    ])
                    self.mono_list.clear()
                    self.mono_list.addItems(sorted(mono_patterns))
                    
                    # Load color patterns
                    color_patterns = patterns.get('color', [
                        'B023', 'B032', 'B216',
                        'G023', 'G032', 'G216',
                        'R023', 'R032', 'R216'
                    ])
                    self.color_list.clear()
                    self.color_list.addItems(sorted(color_patterns))
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error loading patterns: {str(e)}")

    def save_patterns(self):
        try:
            config = {}
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
            
            # Get patterns from both lists
            mono_patterns = [self.mono_list.item(i).text() 
                            for i in range(self.mono_list.count())]
            color_patterns = [self.color_list.item(i).text() 
                             for i in range(self.color_list.count())]
            
            # Update patterns in config
            if 'patterns' not in config:
                config['patterns'] = {}
            config['patterns']['mono'] = mono_patterns
            config['patterns']['color'] = color_patterns
            
            # Save config
            with open('app_config.json', 'w') as f:
                json.dump(config, f, indent=4)
                
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error saving patterns: {str(e)}")

    def get_current_list(self, tab_index):
        return self.mono_list if tab_index == 0 else self.color_list

    def add_pattern(self, tab_index):
        pattern_type = "Mono" if tab_index == 0 else "Color"
        pattern, ok = QInputDialog.getText(
            self, 
            f"Add {pattern_type} Pattern",
            "Enter pattern (e.g., B064):",
            QLineEdit.EchoMode.Normal
        )
        
        if ok and pattern:
            current_list = self.get_current_list(tab_index)
            
            # Validate pattern format
            if not re.match(r'^[RGBW]\d{3}$', pattern):
                QMessageBox.warning(
                    self,
                    "Invalid Pattern",
                    "Pattern must start with R/G/B/W followed by 3 digits"
                )
                return
            
            # Check if pattern already exists
            existing_patterns = [current_list.item(i).text() 
                               for i in range(current_list.count())]
            if pattern in existing_patterns:
                QMessageBox.warning(self, "Warning", "Pattern already exists!")
                return
            
            current_list.addItem(pattern)
            current_list.sortItems()
            self.save_patterns()

    def edit_pattern(self, tab_index):
        current_list = self.get_current_list(tab_index)
        current = current_list.currentItem()
        
        if not current:
            QMessageBox.warning(self, "Warning", "Please select a pattern to edit")
            return
        
        pattern, ok = QInputDialog.getText(
            self,
            "Edit Pattern",
            "Edit pattern:",
            QLineEdit.EchoMode.Normal,
            current.text()
        )
        
        if ok and pattern:
            if not re.match(r'^[RGBW]\d{3}$', pattern):
                QMessageBox.warning(
                    self,
                    "Invalid Pattern",
                    "Pattern must start with R/G/B/W followed by 3 digits"
                )
                return
            
            current.setText(pattern)
            current_list.sortItems()
            self.save_patterns()

    def remove_pattern(self, tab_index):
        current_list = self.get_current_list(tab_index)
        current = current_list.currentItem()
        
        if not current:
            QMessageBox.warning(self, "Warning", "Please select a pattern to remove")
            return
        
        reply = QMessageBox.question(
            self,
            "Confirm Remove",
            f"Are you sure you want to remove pattern {current.text()}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            current_list.takeItem(current_list.row(current))
            self.save_patterns() 

class IntensityDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Image Intensity Analysis")
        self.resize(1400, 800)
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMaximizeButtonHint)
        self.setup_ui()
        self.load_patterns()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(15, 15, 15, 15)

        # Left panel
        left_panel = QFrame()
        left_panel.setMaximumWidth(int(self.width() * 0.25))
        left_layout = QVBoxLayout(left_panel)
        left_layout.setSpacing(10)

        # Pattern Type Selection
        pattern_group = QGroupBox("Pattern Type")
        pattern_layout = QVBoxLayout(pattern_group)
        
        self.mono_checkbox = QCheckBox("Mono Patterns")
        self.color_checkbox = QCheckBox("Color Patterns")
        pattern_layout.addWidget(self.mono_checkbox)
        pattern_layout.addWidget(self.color_checkbox)
        
        # Pattern Management Button
        pattern_btn = QPushButton("Manage Patterns")
        pattern_btn.setIcon(QIcon(":/icons/setting.png"))
        pattern_btn.setIconSize(QSize(26, 26))
        pattern_btn.clicked.connect(self.show_pattern_management)
        pattern_btn.setToolTip(
            "Open Pattern Management Dialog.\n\n"
            "Features:\n"
            "- Add/Edit/Remove Mono patterns\n"
            "- Add/Edit/Remove Color patterns\n"
            "- Patterns are saved automatically"
        )
        pattern_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                border: none;
                border-radius: 3px;
                padding: 8px 15px;
                font-weight: bold;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        pattern_layout.addWidget(pattern_btn)
        left_layout.addWidget(pattern_group)

        # Folder selection
        folder_layout = QHBoxLayout()
        self.folder_path = QLineEdit()
        self.folder_path.setReadOnly(True)
        self.folder_path.setPlaceholderText("Select folder containing TIF images...")
        
        browse_btn = QPushButton("Browse")
        browse_btn.setIcon(QIcon(":/icons/folder.png"))
        browse_btn.setIconSize(QSize(26, 26))
        browse_btn.clicked.connect(self.browse_folder)
        browse_btn.setToolTip(
            "Select folder containing camera subfolders with TIF images.\n\n"
            "Structure:\n"
            "Selected Folder\n"
            "  ├── Camera Folder 1\n"
            "  │   ├── pattern1.tif\n"
            "  │   └── pattern2.tif\n"
            "  └── Camera Folder 2\n"
            "      ├── pattern1.tif\n"
            "      └── pattern2.tif"
        )
        browse_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                border: none;
                border-radius: 3px;
                padding: 5px 15px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        
        folder_layout.addWidget(self.folder_path)
        folder_layout.addWidget(browse_btn)
        left_layout.addLayout(folder_layout)

        # Results table
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(3)
        self.results_table.setHorizontalHeaderLabels(["Camera", "Pattern", "Average Intensity"])
        self.results_table.horizontalHeader().setStretchLastSection(True)
        left_layout.addWidget(self.results_table)

        # Log section
        log_label = QLabel("Processing Log:")
        log_label.setStyleSheet("font-weight: bold;")
        left_layout.addWidget(log_label)

        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #f8f9fa;
                border: 1px solid #dcdde1;
                border-radius: 3px;
                padding: 5px;
                font-family: monospace;
            }
        """)
        left_layout.addWidget(self.log_text)

        # Right panel for chart
        right_panel = QFrame()
        right_panel.setStyleSheet("""
            QFrame {
                background-color: white;
                border: 1px solid #e1e1e1;
                border-radius: 5px;
                padding: 10px;
            }
        """)
        right_layout = QVBoxLayout(right_panel)

        # Matplotlib figure
        self.figure = Figure(figsize=(12, 6), facecolor='#FFFFFF')
        self.canvas = FigureCanvas(self.figure)
        right_layout.addWidget(self.canvas)

        # Buttons layout
        buttons_layout = QHBoxLayout()
        buttons_layout.addStretch()

        # Analyze button
        analyze_btn = QPushButton("Analyze Intensity")
        analyze_btn.setIcon(QIcon(":/icons/analyze.png"))
        analyze_btn.setIconSize(QSize(26, 26))
        analyze_btn.clicked.connect(self.analyze_intensity)
        analyze_btn.setToolTip(
            "Analyze intensity of selected patterns.\n\n"
            "Process:\n"
            "1. Finds all matching pattern files in each camera folder\n"
            "2. Calculates average intensity for each pattern\n"
            "3. Displays results in table and chart\n\n"
            "Note: Select at least one pattern type (Mono/Color) before analyzing"
        )
        analyze_btn.setStyleSheet("""
            QPushButton {
                background-color: #2ecc71;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 15px;
                font-weight: bold;
                font-size: 12px;
                min-width: 120px;
            }
            QPushButton:hover {
                background-color: #27ae60;
            }
        """)

        # Export button
        self.export_btn = QPushButton("Export Chart")
        self.export_btn.setIcon(QIcon(":/icons/export.png"))
        self.export_btn.setIconSize(QSize(26, 26))
        self.export_btn.clicked.connect(self.export_chart)
        self.export_btn.setEnabled(False)
        self.export_btn.setToolTip(
            "Export intensity analysis chart.\n\n"
            "Supported formats:\n"
            "- PNG (*.png)\n"
            "- PDF (*.pdf)\n\n"
            "Note: Button is enabled after analysis is complete"
        )
        self.export_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 15px;
                font-weight: bold;
                font-size: 12px;
                min-width: 120px;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QPushButton:disabled {
                background-color: #bdc3c7;
                color: #95a5a6;
            }
        """)

        buttons_layout.addWidget(analyze_btn)
        buttons_layout.addSpacing(10)
        buttons_layout.addWidget(self.export_btn)
        right_layout.addLayout(buttons_layout)

        # Add panels to content layout
        content_layout = QHBoxLayout()
        content_layout.addWidget(left_panel, 25)
        content_layout.addWidget(right_panel, 75)
        layout.addLayout(content_layout)

        # Pattern Type Checkboxes
        self.mono_checkbox.setToolTip(
            "Select to analyze Mono patterns:\n"
            "B064, B072, B384, B432, etc."
        )
        self.color_checkbox.setToolTip(
            "Select to analyze Color patterns:\n"
            "B023, B032, B216, etc."
        )

    def load_patterns(self):
        """Load patterns from config file"""
        try:
            default_patterns = {
                'patterns': {
                    'mono': [
                        'B064', 'B072', 'B384', 'B432',
                        'G064', 'G072', 'G384', 'G432',
                        'R064', 'R072', 'R384', 'R432',
                        'B020', 'B024',
                        'G020', 'G024',
                        'R020', 'R024',
                        'W062'
                    ],
                    'color': [
                        'B023', 'B032', 'B216',
                        'G023', 'G032', 'G216',
                        'R023', 'R032', 'R216'
                    ]
                }
            }

            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
                    patterns = config.get('patterns', default_patterns['patterns'])
                    self.mono_patterns = patterns.get('mono', default_patterns['patterns']['mono'])
                    self.color_patterns = patterns.get('color', default_patterns['patterns']['color'])
            else:
                self.mono_patterns = default_patterns['patterns']['mono']
                self.color_patterns = default_patterns['patterns']['color']
                
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error loading patterns: {str(e)}")
            # Use default patterns if error occurs
            self.mono_patterns = default_patterns['patterns']['mono']
            self.color_patterns = default_patterns['patterns']['color']

    def show_pattern_management(self):
        """Show pattern management dialog"""
        dialog = PatternManagementDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.load_patterns()

    def browse_folder(self):
        """Browse for folder containing TIF images"""
        folder = QFileDialog.getExistingDirectory(self, "Select Image Folder")
        if folder:
            self.folder_path.setText(folder)

    def log_message(self, message):
        """Add message to log"""
        self.log_text.append(f"{message}")
        QApplication.processEvents()

    def analyze_intensity(self):
        """Analyze intensity of selected patterns"""
        if not self.mono_checkbox.isChecked() and not self.color_checkbox.isChecked():
            QMessageBox.warning(self, "Warning", "Please select at least one pattern type!")
            return

        folder_path = self.folder_path.text()
        if not folder_path:
            QMessageBox.warning(self, "Warning", "Please select a folder first!")
            return

        try:
            self.log_text.clear()
            self.results_table.setRowCount(0)
            self.log_message("Starting analysis...")

            # Get selected patterns
            selected_patterns = []
            if self.mono_checkbox.isChecked():
                selected_patterns.extend(self.mono_patterns)
            if self.color_checkbox.isChecked():
                selected_patterns.extend(self.color_patterns)

            cameras = [d for d in os.listdir(folder_path) 
                      if os.path.isdir(os.path.join(folder_path, d))]
            
            intensity_data = []
            row = 0
            
            for camera in cameras:
                camera_path = os.path.join(folder_path, camera)
                self.log_message(f"\nAnalyzing camera: {camera}")

                # Check for .tif files directly in camera_path
                tif_files_in_camera_root = [f for f in os.listdir(camera_path) if f.endswith('.tif') and not '_ori.tif' in f]

                if not tif_files_in_camera_root:
                    self.log_message(f"  No .tif files found directly in '{camera}'. Searching subfolders...")
                    subfolders = [d for d in os.listdir(camera_path) if os.path.isdir(os.path.join(camera_path, d))]
                    
                    for subfolder in subfolders:
                        subfolder_path = os.path.join(camera_path, subfolder)
                        component_name = subfolder.split('_20')[0] if '_20' in subfolder else subfolder # Extract component name
                        
                        for file_in_subfolder in os.listdir(subfolder_path):
                            if file_in_subfolder.endswith('.tif') and '_ori.tif' not in file_in_subfolder:
                                old_file_path = os.path.join(subfolder_path, file_in_subfolder)
                                
                                # Extract pattern part from file name and remove '_imgY_Crop'
                                pattern_part = file_in_subfolder.replace('_imgY_Crop', '')
                                
                                # Construct new file name: A4VT5700AR08BC5_step01_0300NIT_B192.tif
                                new_file_name = f"{component_name}_{pattern_part}"
                                new_file_path = os.path.join(camera_path, new_file_name)
                                
                                if not os.path.exists(new_file_path):
                                    shutil.copy(old_file_path, new_file_path)
                                    self.log_message(f"  Copied and renamed: '{file_in_subfolder}' to '{new_file_name}' in '{camera}'")
                                else:
                                    self.log_message(f"  Skipping copy: '{new_file_name}' already exists in '{camera}'")
                                QApplication.processEvents()

                # Group files by pattern
                pattern_files = {}
                for file in os.listdir(camera_path):
                    if file.endswith('.tif') and '_ori.tif' not in file: # Ensure _ori.tif files are skipped here as well
                        for pattern in selected_patterns:
                            if pattern in file:
                                if pattern not in pattern_files:
                                    pattern_files[pattern] = []
                                pattern_files[pattern].append(file)
                                break

                # Process each pattern
                for pattern, files in pattern_files.items():
                    self.log_message(f"\nProcessing pattern {pattern} in {camera}:")
                    total_intensity = 0
                    valid_files = 0

                    for file in files:
                        try:
                            file_path = os.path.join(camera_path, file)
                            with Image.open(file_path) as img:
                                img_array = np.array(img)
                                intensity = np.mean(img_array)
                                total_intensity += intensity
                                valid_files += 1
                                self.log_message(f"  {file}: {intensity:.2f}")
                        except Exception as e:
                            self.log_message(f"Error processing {file}: {str(e)}")

                    if valid_files > 0:
                        avg_intensity = total_intensity / valid_files
                        self.log_message(f"Average intensity for {pattern} ({valid_files} files): {avg_intensity:.2f}")
                        
                        # Add to results table
                        self.results_table.insertRow(row)
                        self.results_table.setItem(row, 0, QTableWidgetItem(camera))
                        self.results_table.setItem(row, 1, QTableWidgetItem(f"{pattern} ({valid_files})"))
                        self.results_table.setItem(row, 2, QTableWidgetItem(f"{avg_intensity:.2f}"))
                        
                        intensity_data.append((camera, pattern, avg_intensity))
                        row += 1

            if intensity_data:
                self.plot_intensities(intensity_data)
                self.log_message("\nAnalysis completed successfully!")
            else:
                self.log_message("\nNo valid patterns found for analysis!")

        except Exception as e:
            self.log_message(f"Error during analysis: {str(e)}")
            QMessageBox.critical(self, "Error", f"Analysis failed: {str(e)}")

    def plot_intensities(self, intensity_data):
        """Plot intensity data"""
        self.figure.clear()
        
        # Create subplot
        ax = self.figure.add_subplot(111)
        ax.set_facecolor('#FFFFFF')
        
        # Color groups for different pattern types
        color_groups = {
            'B': ['#1e88e5', '#90caf9', '#0d47a1', '#4fc3f7', '#0277bd', '#81d4fa'],
            'G': ['#43a047', '#a5d6a7', '#1b5e20', '#81c784', '#2e7d32', '#c8e6c9'],
            'R': ['#e53935', '#ef9a9a', '#b71c1c', '#ef5350', '#c62828', '#ffcdd2'],
            'W': ['#424242', '#757575', '#bdbdbd', '#9e9e9e', '#616161', '#f5f5f5']
        }

        # Get all cameras and sort them
        all_cameras = sorted(list({cam for cam, _, _ in intensity_data}))
        x = range(len(all_cameras))
        
        # Group patterns by type
        pattern_groups = {}
        for _, pattern, _ in intensity_data:
            pattern_type = pattern[0]
            if pattern_type not in pattern_groups:
                pattern_groups[pattern_type] = []
            if pattern not in pattern_groups[pattern_type]:
                pattern_groups[pattern_type].append(pattern)
        
        # Plot each pattern type
        for pattern_type in ['B', 'G', 'R', 'W']:
            if pattern_type in pattern_groups:
                patterns = sorted(pattern_groups[pattern_type])
                colors = color_groups[pattern_type]
                
                for i, pattern in enumerate(patterns):
                    pattern_data = [next((intensity for cam, pat, intensity in intensity_data 
                                      if cam == camera and pat == pattern), float('nan')) 
                                  for camera in all_cameras]
                    
                    color_index = i % len(colors)
                    ax.plot(x, pattern_data,
                           label=pattern,
                           color=colors[color_index],
                           linewidth=2,
                           marker='o',
                           markersize=6,
                           markeredgewidth=1.5,
                           markeredgecolor='white',
                           alpha=0.9)

        # Customize plot
        ax.set_title('Pattern Intensity Analysis', pad=20, fontsize=14, fontweight='bold')
        ax.set_xlabel('Cameras', fontsize=12, labelpad=10)
        ax.set_ylabel('Intensity', fontsize=12, labelpad=10)
        
        # Set grid
        ax.grid(True, linestyle='--', alpha=0.2)
        ax.set_axisbelow(True)
        
        # Set x-axis labels
        ax.set_xticks(x)
        ax.set_xticklabels(all_cameras, rotation=45, ha='right')
        
        # Add legend
        legend = ax.legend(bbox_to_anchor=(1.02, 1),
                          loc='upper left',
                          fontsize=9,
                          title='Patterns',
                          title_fontsize=10,
                          frameon=True,
                          fancybox=True,
                          shadow=True,
                          ncol=2)
        legend.get_frame().set_alpha(0.9)

        # Adjust layout
        self.figure.subplots_adjust(right=0.85, bottom=0.2, top=0.95, left=0.1)
        
        # Update canvas
        self.canvas.draw()
        self.export_btn.setEnabled(True)

    def export_chart(self):
        """Export chart to file"""
        try:
            file_path, _ = QFileDialog.getSaveFileName(
                self,
                "Export Chart",
                "",
                "PNG Files (*.png);;PDF Files (*.pdf);;All Files (*.*)"
            )
            
            if file_path:
                self.figure.savefig(
                    file_path,
                    dpi=300,
                    bbox_inches='tight',
                    pad_inches=0.1
                )
                QMessageBox.information(self, "Success", "Chart exported successfully!")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to export chart: {str(e)}") 