import cv2
import numpy as np
import os
import re
import math
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
import sys
from PIL import Image 
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
import rc.icons 
from PyQt6 import QtCore, QtGui, QtWidgets 
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

def calculate_profile_metrics(img):
    """
    Calculate profile metrics for toedge detection
    Returns: D value and profile information
    """
    # Get image resolution
    img_height, img_width = img.shape[:2]
    
    # Determine the top and normal profile areas based on resolution
    if img_height == 1320 and img_width == 2868:
        # for 2868x1320
        top_profile_roi = img[194:1124, 0:6]  # (0,194; 6,1124)
        normal_profile_roi = img[194:1124, 6:12]  # (6,194; 12,1124)
    elif img_height == 1206 and img_width == 2622:
        # for 2622x1206
        top_profile_roi = img[194:1012, 0:6]  # (0,194; 6,1012)
        normal_profile_roi = img[194:1012, 6:12]  # (6,194; 12,1012)
    else:
        # If the resolution is different, the calculation is based on a ratio relative to 2868x1320
        scale_y = img_height / 1320.0
        scale_x = img_width / 2868.0
        
        # Calculate coordinates to scale
        top_y1 = int(194 * scale_y)
        top_y2 = int(1124 * scale_y)
        top_x1 = int(0 * scale_x)
        top_x2 = int(6 * scale_x)
        
        normal_y1 = int(194 * scale_y)
        normal_y2 = int(1124 * scale_y)
        normal_x1 = int(6 * scale_x)
        normal_x2 = int(12 * scale_x)
        
        top_profile_roi = img[top_y1:top_y2, top_x1:top_x2]
        normal_profile_roi = img[normal_y1:normal_y2, normal_x1:normal_x2]
    
    # Calculate the average of each column for the top profile
    top_profile_avg = np.mean(top_profile_roi, axis=0)
    normal_profile_avg = np.mean(normal_profile_roi)
    
    # Calculate D = min(TProfile) / Avg(Normal)
    min_top = np.min(top_profile_avg)
    
    D = min_top / normal_profile_avg if normal_profile_avg > 0 else 0
    
    # Calculate the average value
    avg_top = np.mean(top_profile_avg)
    avg_normal = normal_profile_avg
    
    return D, min_top, normal_profile_avg, avg_top, avg_normal, img_height, img_width

def detect_topedge_by_profile(image_path, threshold=0.92, file_name=None):
    """
    Topedge detection based on profile analysis
    threshold: classification threshold (D > threshold: no topedge, D <= threshold: topedge)
    """
    # Reading 16-bit images
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
    
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")
    
    # If the image has many channels, convert it to grayscale
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # USE A SINGLE THRESHOLD FOR ALL STEPS
    dynamic_threshold = threshold  # Use a fixed threshold
    
    # Calculate metrics (without bottom profile)
    D, min_top, normal_avg, avg_top, avg_normal, img_height, img_width = calculate_profile_metrics(img)
    
    # Determine if there is a topedge - USE A THRESHOLDER TO FIX IT
    has_topedge = D <= dynamic_threshold
    
    # Determine the scale factor to adjust the ROI for error detection
    if img_height == 1320 and img_width == 2868:
        # for 2868x1320
        scale_y = 1.0
        scale_x = 1.0
    elif img_height == 1206 and img_width == 2622:
        # for 2622x1206
        scale_y = 1206 / 1320.0
        scale_x = 2622 / 2868.0
    else:
        # Calculate scale factor
        scale_y = img_height / 1320.0
        scale_x = img_width / 2868.0
    
    # Identify the ROI for the top profile (if there are any errors)
    affected_roi_coords = None
    if has_topedge:
        # LOOK FOR THE TOP PROFILE WITH ERRORS
        # Calculate ROI coordinates based on resolution
        x1 = int(0 * scale_x)  # Starting from column 0
        x2 = int(30 * scale_x) 
        y1 = int(150 * scale_y)
        y2 = int(1150 * scale_y)
        affected_roi_coords = (x1, y1, x2, y2)
    
    # Create visualization - ONLY MARK THE DEFECT AREA
    result = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    result = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
    
    # Add resolution information to the log
    resolution_info = f"{img_width}x{img_height}"
    
    # Only draw the faulty area if a topedge is present
    if has_topedge and affected_roi_coords:
        x1, y1, x2, y2 = affected_roi_coords
        # Draw a red rectangle for the affected area
        cv2.rectangle(result, (x1, y1), (x2, y2), (0, 0, 255), 4)
        # Add text indicating which areas are affected and their resolution
        region_text = f"Top Profile Top_Edge (D={D:.3f}, Thresh={dynamic_threshold}) - {resolution_info}"
        cv2.putText(result, region_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    else:
        # If there is no topedge, display the message OK
        status_text = f"No Top_Edge (D={D:.3f}, Thresh={dynamic_threshold}) - {resolution_info}"
        cv2.putText(result, status_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
    # Apply a mask to the affected area (if have)
    if has_topedge and affected_roi_coords:
        mask = np.zeros(img.shape[:2], dtype=np.uint8)
        x1, y1, x2, y2 = affected_roi_coords
        mask[y1:y2, x1:x2] = 255
    else:
        mask = np.zeros(img.shape[:2], dtype=np.uint8)
    
    return result, mask, D, has_topedge, affected_roi_coords, avg_top, avg_normal, min_top, dynamic_threshold

def extract_pattern(file_name):
    """
    Extract patterns from filenames
    ONLY INCLUDES 192, 216
    """
    # Only process files containing step 01 to step 09
    if not re.search(r'step0[1-9]', file_name, re.IGNORECASE):
        return None
    
    # ONLY LOOK FOR PATTERNS WITH 192 OR 216
    patterns_to_try = [
        # Pattern 1: step01_100NIT_R192 (for 192, 216)
        r'(step0[1-9]_\d+NIT_[RGBWrgbw](?:192|216))',
        # Pattern 2: step01_100NIT_R192
        r'(step0[1-9]_.*?[RGBWrgbw](?:192|216))',
    ]
    
    for pattern in patterns_to_try:
        match = re.search(pattern, file_name, re.IGNORECASE)
        if match:
            matched_pattern = match.group(1)
            
            # Pattern normalization: ensuring uppercase letters for RGBW
            rgbw_match = re.search(r'[RGBWrgbw]', matched_pattern)
            if rgbw_match:
                rgbw_char = rgbw_match.group().upper()
                pattern_parts = matched_pattern.split(rgbw_match.group())
                if len(pattern_parts) >= 2:
                    matched_pattern = pattern_parts[0] + rgbw_char + pattern_parts[1]
            
            return matched_pattern
    
    # Try to find a simpler pattern
    simple_patterns = [
        r'(step0[1-9]_.*?192)',
        r'(step0[1-9]_.*?216)',
    ]
    
    for pattern in simple_patterns:
        match = re.search(pattern, file_name, re.IGNORECASE)
        if match:
            return match.group(1)
    
    return None

def check_for_topedge_in_folder(topedge_checker_thread, folder_path, file_names_in_group, pattern, 
                             mask_images_dir, mark_topedge_dir, crop_topedge_dir, 
                             threshold=0.92):
    """
    Check TopEdge in the folder - Catch errors immediately upon detection
    """
    base_folder_name = os.path.basename(folder_path)
    topedge_files = []  # List to track which files have topedge
    topedge_results = []  # Store results for files with topedge
    profile_data_list = []  # Store profile data for CSV export
    
    for file_name in file_names_in_group:
        file_path = os.path.join(folder_path, file_name)

        # Use the detect_topedge_by_profile function.
        try:
            result, mask, D, has_topedge, affected_roi_coords, avg_top, avg_normal, min_top, used_threshold = detect_topedge_by_profile(
                file_path, threshold=threshold, file_name=file_name
            )
        except Exception as e:
            topedge_checker_thread.update_log.emit(f"Error processing {file_name}: {str(e)}")
            continue

        # Extract resolution information from the image
        img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
        if img is not None:
            img_height, img_width = img.shape[:2]
            resolution = f"{img_width}x{img_height}"
        else:
            resolution = "Unknown"

        # Save profile information to CSV
        profile_data_list.append({
            "Folder": base_folder_name,
            "File Name": file_name,
            "Pattern": pattern if pattern else "Unknown",
            "Resolution": resolution,
            "D Value": D,
            "Top Avg": avg_top,
            "Normal Avg": avg_normal,
            "Top Min": min_top,
            "Threshold Used": used_threshold,
            "Has Top_Edge": "Yes" if has_topedge else "No",
            "Status": "Top_Edge Found" if has_topedge else "OK"
        })

        # Save mask image cho file bị topedge
        if has_topedge:
            mask_img_path = os.path.join(mask_images_dir, f"{base_folder_name}_{file_name.replace('.tif', '_mask.png')}")
            cv2.imwrite(mask_img_path, mask)
        
        # If TopEdge is available, save the information
        if has_topedge:
            topedge_files.append(file_name)
            
            # Save original image
            original_img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
            if original_img is not None:
                original_img_norm = cv2.normalize(original_img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
                if len(original_img_norm.shape) == 3:
                    original_img_norm = cv2.cvtColor(original_img_norm, cv2.COLOR_BGR2GRAY)
            else:
                original_img_norm = np.zeros((100, 100), dtype=np.uint8)  # Fallback
            
            # Define cropping area - TAKEN FROM ROI COORDS (adjusted for resolution)
            if has_topedge and affected_roi_coords:
                crop_coords = affected_roi_coords
            else:
                # Default resolution is 2868x1320
                crop_coords = (0, 150, 30, 1150)
            
            topedge_results.append({
                "file_name": file_name,
                "original_img": original_img_norm,
                "result_img": result,
                "D_value": D,
                "crop_coords": crop_coords,
                "used_threshold": used_threshold,
                "profile_data": profile_data_list[-1]  # Reference to the last added profile data
            })
    
    # If at least one file is topedge
    if topedge_results:
        # Create a result image with all files that are topedged
        # Use the first image as the base
        base_result = topedge_results[0]["result_img"]
        
        # Save result image
        aggregated_result_img_path = os.path.join(mark_topedge_dir, f"{base_folder_name}_{pattern}_topedge_result.png")
        cv2.imwrite(aggregated_result_img_path, base_result)
        
        # Create cropped images for each topedge-affected file
        individual_cropped_image_paths = []
        for idx, topedge_info in enumerate(topedge_results):
            crop_coords = topedge_info["crop_coords"]
            original_img = topedge_info["original_img"]
            
            x1, y1, x2, y2 = crop_coords
            # Add padding to cropped images
            padding = int(50 * (original_img.shape[0] / 1320.0))  # Adjust padding according to resolution
            crop_x_start = max(0, x1 - padding)
            crop_y_start = max(0, y1 - padding)
            crop_x_end = min(original_img.shape[1], x2 + padding)
            crop_y_end = min(original_img.shape[0], y2 + padding)
            
            cropped_img = original_img[crop_y_start:crop_y_end, crop_x_start:crop_x_end]
            
            # Create a cropped filename with threshold information
            cropped_filename = f"{base_folder_name}_{pattern}_D{topedge_info['D_value']:.3f}_Thresh{topedge_info['used_threshold']}_{idx+1}_cropped.png"
            individual_cropped_img_path = os.path.join(crop_topedge_dir, cropped_filename)
            cv2.imwrite(individual_cropped_img_path, cropped_img)
            individual_cropped_image_paths.append(individual_cropped_img_path)
        
        topedge_checker_thread.update_log.emit(f"Found topedge in {len(topedge_files)} files for pattern {pattern} in folder {base_folder_name}")
        
        # Returns report entries
        report_entries = []
        for cropped_path in individual_cropped_image_paths:
            report_entries.append({
                "result_img_path": aggregated_result_img_path,
                "cropped_img_path": cropped_path,
            })
        
        return True, report_entries, profile_data_list
    else:
        # No files are stuck on TopEdge
        return False, None, profile_data_list

def generate_excel_report(topedge_checker_thread, output_dir, reports, all_profile_data):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Top_Edge Report"
    # Prepare Summary workbook and sheet
    summary_path = os.path.join(os.path.dirname(output_dir), "Analysis_Report.xlsx")
    if os.path.exists(summary_path):
        summary_wb = _load_wb(summary_path)
    else:
        summary_wb = Workbook()
        summary_wb.active.title = "Summary"
    if "Top_Edge Report" in summary_wb.sheetnames:
        summary_ws = summary_wb["Top_Edge Report"]
        # Clear old content by removing and recreating
        summary_wb.remove(summary_ws)
        summary_ws = summary_wb.create_sheet("Top_Edge Report")
    else:
        summary_ws = summary_wb.create_sheet("Top_Edge Report")

    # Determine the maximum number of cropped images to create dynamic column headers
    max_cropped_images = 0
    for report_entry in reports:
        if "Cropped_Images" in report_entry and report_entry["Cropped_Images"] is not None:
            max_cropped_images = max(max_cropped_images, len(report_entry["Cropped_Images"]))

    # Add headers
    headers = ["Folder", "PTN", "Status", "Original Image with Mark"]
    for i in range(max_cropped_images):
        headers.append(f"Cropped Image {i+1}")
    sheet.append(headers)
    summary_ws.append(headers)

    header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    header_font = Font(bold=True)
    border_style = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

    for col in range(1, len(headers) + 1):
        cell = sheet.cell(row=1, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border_style
        scell = summary_ws.cell(row=1, column=col)
        scell.fill = header_fill
        scell.font = header_font
        scell.alignment = Alignment(horizontal="center", vertical="center")
        scell.border = border_style

    # Set fixed column widths
    sheet.column_dimensions['A'].width = 25  # Folder
    sheet.column_dimensions['B'].width = 20  # PTN
    sheet.column_dimensions['C'].width = 20  # Status
    sheet.column_dimensions['D'].width = 45  # Original Image with Mark
    summary_ws.column_dimensions['A'].width = 25
    summary_ws.column_dimensions['B'].width = 20
    summary_ws.column_dimensions['C'].width = 20
    summary_ws.column_dimensions['D'].width = 45

    # Scale factor for images when embedding into Excel
    scale_factor = 0.25 

    # Alternating background colors for rows with the same folder name
    colors = ["D9EAD3", "C9DAF8"]
    current_color_index = 0
    prev_folder = None

    def calc_status_height(text):
        clean_text = (text or "").strip()
        if not clean_text:
            return 20
        approx_chars_per_line = 28
        lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
        return lines * 18 + 4

    def adjust_status_cells(main_row, summary_row, status_text):
        desired_height = calc_status_height(status_text)
        for target_ws, row in ((sheet, main_row), (summary_ws, summary_row)):
            cell = target_ws.cell(row=row, column=3)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrapText=True)
            current_height = target_ws.row_dimensions[row].height if target_ws.row_dimensions[row].height is not None else 0
            if desired_height > current_height:
                target_ws.row_dimensions[row].height = desired_height

    # Separate reports into two groups: with errors and without errors
    reports_with_errors = []
    reports_without_errors = []
    
    for report_entry in reports:
        status = report_entry.get("Status", "")
        if status == "Top_Edge Found":
            reports_with_errors.append(report_entry)
        else:
            reports_without_errors.append(report_entry)
    
    # Combine: errors first, then no errors
    sorted_reports = reports_with_errors + reports_without_errors
    
    for row_idx, report_entry in enumerate(sorted_reports, start=2):
        folder = report_entry.get("Folder", "-")
        ptn = report_entry.get("Pattern", "-")
        status = report_entry.get("Status", "Top_Edge Found")
        result_img_path = report_entry.get("Result_Image")
        cropped_images_paths = report_entry.get("Cropped_Images")

        if folder != prev_folder:
            current_color_index = (current_color_index + 1) % 2
            prev_folder = folder
        row_fill = PatternFill(start_color=colors[current_color_index], end_color=colors[current_color_index], fill_type="solid")

        row_data = [folder, ptn, status]
        sheet.append(row_data)
        current_excel_row = sheet.max_row
        summary_ws.append(row_data)
        current_summary_row = summary_ws.max_row

        for col in range(1, len(row_data) + 1):
            cell = sheet.cell(row=current_excel_row, column=col)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.fill = row_fill
            cell.border = border_style
            scell = summary_ws.cell(row=current_summary_row, column=col)
            scell.alignment = Alignment(horizontal="center", vertical="center")
            scell.fill = row_fill
            scell.border = border_style

        adjust_status_cells(current_excel_row, current_summary_row, status)

        # Insert aggregated result image into column D
        if result_img_path and os.path.exists(result_img_path):
            with Image.open(result_img_path) as img_result_pil:
                w, h = img_result_pil.size
            scaled_w = int(w * topedge_checker_thread.IMAGE_SCALE_FACTOR)
            scaled_h = int(h * topedge_checker_thread.IMAGE_SCALE_FACTOR)

            img_result = ExcelImage(result_img_path)
            img_result.width = scaled_w
            img_result.height = scaled_h
            sheet.add_image(img_result, f'D{current_excel_row}')
            img_result2 = ExcelImage(result_img_path)
            img_result2.width = scaled_w
            img_result2.height = scaled_h
            summary_ws.add_image(img_result2, f'D{current_summary_row}')

            current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
            new_row_height = int(scaled_h * 0.75) + 2
            sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
            s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
            s_new_row_height = int(scaled_h * 0.75) + 2
            summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)
            
            current_col_width = sheet.column_dimensions['D'].width if sheet.column_dimensions['D'].width is not None else 0
            new_col_width = int(scaled_w / 7) + 2
            sheet.column_dimensions['D'].width = max(current_col_width, new_col_width)
            s_current_col_width = summary_ws.column_dimensions['D'].width if summary_ws.column_dimensions['D'].width is not None else 0
            s_new_col_width = int(scaled_w / 7) + 2
            summary_ws.column_dimensions['D'].width = max(s_current_col_width, s_new_col_width)

        # Insert individual cropped images into dynamic columns starting from column E
        if cropped_images_paths:
            for i, cropped_path in enumerate(cropped_images_paths):
                current_col_idx = 4 + i
                current_col_letter = get_column_letter(current_col_idx + 1)

                if cropped_path and os.path.exists(cropped_path):
                    with Image.open(cropped_path) as img_cropped_pil:
                        crop_width, crop_height = img_cropped_pil.size
                    
                    img_cropped = ExcelImage(cropped_path)
                    max_crop_size = 200
                    crop_ratio = min(max_crop_size / crop_width, max_crop_size / crop_height)
                    img_cropped.width = int(crop_width * crop_ratio)
                    img_cropped.height = int(crop_height * crop_ratio)
                    
                    sheet.add_image(img_cropped, f'{current_col_letter}{current_excel_row}')
                    img_cropped2 = ExcelImage(cropped_path)
                    img_cropped2.width = int(crop_width * crop_ratio)
                    img_cropped2.height = int(crop_height * crop_ratio)
                    summary_ws.add_image(img_cropped2, f'{current_col_letter}{current_summary_row}')

                    current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
                    new_row_height = int(img_cropped.height * 0.75) + 2
                    sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
                    s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
                    s_new_row_height = int(img_cropped.height * 0.75) + 2
                    summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)

                    current_col_width = sheet.column_dimensions[current_col_letter].width if sheet.column_dimensions[current_col_letter].width is not None else 0
                    new_col_width = int(img_cropped.width / 7) + 2
                    sheet.column_dimensions[current_col_letter].width = max(current_col_width, new_col_width)
                    s_current_col_width = summary_ws.column_dimensions[current_col_letter].width if summary_ws.column_dimensions[current_col_letter].width is not None else 0
                    s_new_col_width = int(img_cropped.width / 7) + 2
                    summary_ws.column_dimensions[current_col_letter].width = max(s_current_col_width, s_new_col_width)

    excel_file_path = os.path.join(output_dir, "Top_Edge_Detection_Report.xlsx")
    workbook.save(excel_file_path)
    # Save/commit Summary workbook
    summary_wb.save(summary_path)
    
    # Create a CSV file containing profile details
    if all_profile_data:
        csv_file_path = os.path.join(output_dir, "Top_Edge_Profile_Details.csv")
        df = pd.DataFrame(all_profile_data)
        
        # Arrange columns for easier readability - BOTTOM COLUMNS REMOVED
        column_order = [
            "Folder", "File Name", "Pattern", "Resolution", "Status", "Has Top_Edge",
            "D Value", "Threshold Used", "Top Avg", "Normal Avg", "Top Min"
        ]
        # Only retain the columns present in the DataFrame
        available_columns = [col for col in column_order if col in df.columns]
        df = df[available_columns]
        
        # Sort by Folder and File Name
        df = df.sort_values(by=["Folder", "File Name"])
        
        # Save file CSV
        df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
        topedge_checker_thread.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
        topedge_checker_thread.update_log.emit(f"Total records in CSV: {len(df)}")
    
    try:
        topedge_checker_thread.update_log.emit(f"Summary updated: {summary_path} -> 'Top_Edge Report'")
    except Exception:
        pass


# New class for running analysis in the background thread.
class Top_EdgeCheckerThread(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)

    ANALYSIS_RESULTS_FOLDER = "Top_Edge_Analysis_Results"
    IMAGE_SCALE_FACTOR = 0.18 # Set constant here

    def __init__(self, root_folder):
        super().__init__()
        self.root_folder = root_folder
        self.analysis_output_folder = os.path.join(self.root_folder, self.ANALYSIS_RESULTS_FOLDER)
        self.mask_images_dir = os.path.join(self.analysis_output_folder, "mask_images")
        self.mark_topedge_dir = os.path.join(self.analysis_output_folder, "mark_topedge")
        self.crop_topedge_dir = os.path.join(self.analysis_output_folder, "crop_topedge")
        
        os.makedirs(self.analysis_output_folder, exist_ok=True)
        os.makedirs(self.mask_images_dir, exist_ok=True)
        os.makedirs(self.mark_topedge_dir, exist_ok=True)
        os.makedirs(self.crop_topedge_dir, exist_ok=True)
        self.temp_files_to_delete = [] # Initialize list for temporary files
        self.all_profile_data = []  # Store all profile data for CSV export

    def _prepare_folder_for_analysis(self, folder_path, folder_name):
        # Get a list of TIFF files directly in the folder
        initial_image_paths = [os.path.join(folder_path, fname) 
                               for fname in os.listdir(folder_path) 
                               if fname.lower().endswith('.tif') and '_ori.tif' not in fname.lower()]

        if initial_image_paths: # If TIFF images are found directly in the folder (excluding _ori.tif)
            self.update_log.emit(f"Found {len(initial_image_paths)} TIFF images directly in {folder_name}.")
            return initial_image_paths

        # If no direct TIFF images, search subfolders and copy them to the root folder
        self.update_log.emit(f"No TIFF images found directly in {folder_name}. Searching subfolders and copying...")
        copied_image_paths = []
        for root, _, files in os.walk(folder_path):
            if root == folder_path: # Skip the root folder itself
                continue
            
            # Filter files for .tif and exclude _ori.tif
            filtered_files = [f for f in files if f.lower().endswith('.tif') and '_ori.tif' not in f.lower()]
            
            if filtered_files: # If any relevant TIFF files found in subfolder
                parent_subfolder_name = os.path.basename(root)
                self.update_log.emit(f"  Found {len(filtered_files)} TIFF images in subfolder: {parent_subfolder_name}")

                for file in filtered_files:
                    original_path = os.path.join(root, file)
                    
                    # Create new name: Parent_Subfolder_Name_Original_File_Name.tif
                    new_file_name = f"{parent_subfolder_name}_{file}"
                    destination_path = os.path.join(folder_path, new_file_name)
                    
                    shutil.copy2(original_path, destination_path)
                    copied_image_paths.append(destination_path)
                    self.temp_files_to_delete.append(destination_path) # Add to deletion list
                    self.update_log.emit(f"Copied '{os.path.basename(original_path)}' to '{new_file_name}' in {folder_name} for analysis.")

        return copied_image_paths

    def run(self):
        try:
            grouped_reports = []
            # Exclude analysis results folders when exporting report
            excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
            # Get a list of subfolders in the root folder
            folders = [f for f in os.listdir(self.root_folder) 
                      if os.path.isdir(os.path.join(self.root_folder, f)) 
                      and f not in excluded_folders]
            total_folders = len(folders)

            if total_folders == 0:
                self.finished.emit([])
                return

            for idx, folder_name in enumerate(folders):
                folder_path = os.path.join(self.root_folder, folder_name)
                
                self.update_progress.emit(int((idx + 1) / total_folders * 100))
                self.update_log.emit(f"Checking folder: {folder_name}...")

                # Prepare images for analysis: copy from subfolders if necessary
                image_paths_for_analysis = self._prepare_folder_for_analysis(folder_path, folder_name)
                
                if not image_paths_for_analysis:
                    self.update_log.emit(f"No relevant TIFF images found in folder: {folder_name} for analysis.")
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid TIFF images",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                # Debug: Show all found TIFF files
                self.update_log.emit(f"Found {len(image_paths_for_analysis)} TIFF files in {folder_name}")
                for img_path in image_paths_for_analysis[:5]:  # Show the first 5 files
                    file_name = os.path.basename(img_path)
                    self.update_log.emit(f"  File: {file_name}")

                grouped_files_by_pattern = {}
                for img_path in image_paths_for_analysis:
                    file_name = os.path.basename(img_path)
                    if file_name.lower().endswith(".tif"):
                        pattern = extract_pattern(file_name)
                        if pattern:
                            self.update_log.emit(f"  Pattern found: {pattern} for file: {file_name}")
                            if pattern not in grouped_files_by_pattern:
                                grouped_files_by_pattern[pattern] = []
                            grouped_files_by_pattern[pattern].append(file_name)
                        else:
                            self.update_log.emit(f"  No pattern found for file: {file_name}")

                if not grouped_files_by_pattern:
                    self.update_log.emit(f"No valid pattern found in folder: {folder_name}")
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid pattern found (requires 192/216)",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                self.update_log.emit(f"Found {len(grouped_files_by_pattern)} patterns in {folder_name}: {list(grouped_files_by_pattern.keys())}")

                for pattern, file_names_in_group in grouped_files_by_pattern.items():
                    self.update_log.emit(f"Processing pattern: {pattern} with {len(file_names_in_group)} files")
                   
                    topedge_found_in_group, report_entries, profile_data_list = check_for_topedge_in_folder(
                        self, # Pass self as topedge_checker_thread
                        folder_path, file_names_in_group, pattern,
                        self.mask_images_dir, self.mark_topedge_dir, self.crop_topedge_dir,
                        threshold=0.92
                    )
                    
                    # Save profile data
                    self.all_profile_data.extend(profile_data_list)
                    self.update_log.emit(f"Collected {len(profile_data_list)} profile records for pattern {pattern}")
                    
                    if topedge_found_in_group:
                        cropped_list = [entry["cropped_img_path"] for entry in (report_entries or []) if entry.get("cropped_img_path")]
                        result_image = report_entries[0]["result_img_path"] if report_entries else None
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": pattern,
                            "Status": "Top_Edge Found",
                            "Result_Image": result_image,
                            "Cropped_Images": cropped_list
                        })
                    else:
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": pattern,
                            "Status": "No topedge detected",
                            "Result_Image": None,
                            "Cropped_Images": []
                        })
            
            # Debug: Display information about profile data
            if self.all_profile_data:
                self.update_log.emit(f"Total profile records collected: {len(self.all_profile_data)}")
                
                # Analyze pattern distribution
                pattern_counts = {}
                for data in self.all_profile_data:
                    pattern = data.get("Pattern", "Unknown")
                    pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
                
                self.update_log.emit("Pattern distribution in profile data:")
                for pattern, count in pattern_counts.items():
                    self.update_log.emit(f"  {pattern}: {count} files")
                
                # Analyze step distributions
                step_counts = {}
                for data in self.all_profile_data:
                    file_name = data.get("File Name", "")
                    step_match = re.search(r'step0([1-9])', file_name, re.IGNORECASE)
                    if step_match:
                        step = step_match.group(0)
                        step_counts[step] = step_counts.get(step, 0) + 1
                
                self.update_log.emit("Step distribution in profile data:")
                for step, count in step_counts.items():
                    self.update_log.emit(f"  {step}: {count} files")
            
            if grouped_reports:
                generate_excel_report(self, self.analysis_output_folder, grouped_reports, self.all_profile_data)
                self.update_log.emit("Analysis complete! Excel report and CSV file generated.")
                
                topedge_folders = list(set(report['Folder'] for report in grouped_reports if report.get("Status") == "Top_Edge Found"))
                self.finished.emit(topedge_folders)
            else:
                # Still create CSV if profile data is available.
                if self.all_profile_data:
                    csv_file_path = os.path.join(self.analysis_output_folder, "Top_Edge_Profile_Details.csv")
                    df = pd.DataFrame(self.all_profile_data)
                    
                    # Arrange the columns for easier reading
                    column_order = [
                        "Folder", "File Name", "Pattern", "Resolution", "Status", "Has Top_Edge",
                        "D Value", "Threshold Used", "Top Avg", "Normal Avg", "Top Min"
                    ]
                    # Only retain the columns present in the DataFrame
                    available_columns = [col for col in column_order if col in df.columns]
                    df = df[available_columns]
                    
                    # Sort by Folder and File Name
                    df = df.sort_values(by=["Folder", "File Name"])
                    
                    df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
                    self.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
                    self.update_log.emit(f"Total records in CSV: {len(df)}")
                
                self.update_log.emit("Analysis complete! No folders with topedge, but CSV file generated.")
                self.finished.emit([])

        except Exception as e:
            self.update_log.emit(f"Error: {type(e).__name__} - {str(e)}")
            import traceback
            self.update_log.emit(f"Traceback: {traceback.format_exc()}")
            self.finished.emit([])
        finally:
            # Clean up temporary copied files
            if self.temp_files_to_delete:
                self.update_log.emit("Cleaning up temporary files...")
                for temp_file in self.temp_files_to_delete:
                    if os.path.exists(temp_file):
                        try:
                            os.remove(temp_file)
                            self.update_log.emit(f"Deleted temporary file: {os.path.basename(temp_file)}")
                        except Exception as e:
                            self.update_log.emit(f"Error deleting temporary file {os.path.basename(temp_file)}: {str(e)}")
                self.temp_files_to_delete.clear()
                
# UI - MainWindow class
class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_app_window = parent # Store reference to the main application window
        self.setWindowTitle("Top_Edge Detection Tool")
        self.resize(600, 600)
        self.setWindowIcon(QIcon(":/icons/topedge.png"))
        
        self.selected_folder = None # Initialize selected_folder
        self.analysis_output_folder = None # Initialize analysis_output_folder
        
        # Set light modern theme color palette
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 247, 250))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(52, 73, 94))
        self.setPalette(palette)

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Header container with gradient background
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(75)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)

        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        # Icon in header with shadow
        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        
        # Create shadow effect for icon button with increased intensity
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))
        icon_button.setGraphicsEffect(icon_shadow)
        
        # Set icon for button with larger size
        icon = QtGui.QIcon(":/icons/topedge.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70))
        
        # Add icon button to header layout
        header_layout.addWidget(icon_button)

        # Title container
        title_container = QVBoxLayout()
        title_container.setSpacing(-2)

        title_label = QLabel("Top_Edge Detection Tool")
        title_label.setFont(QFont("Segoe UI", 20, QFont.Weight.Bold))
        title_label.setStyleSheet("color: white; padding: 0; margin: 0;")

        subtitle_label = QLabel("Detect topedge in TIFF images automatically")
        subtitle_label.setFont(QFont("Segoe UI", 10))
        subtitle_label.setStyleSheet("color: rgba(255, 255, 255, 0.85);")
        subtitle_label.setContentsMargins(0, -5, 0, 0)

        title_container.addWidget(title_label)
        title_container.addWidget(subtitle_label)

        header_layout.addLayout(title_container)
        header_layout.addStretch()

        main_layout.addWidget(header_container)

        # Controls container
        controls_container = QWidget()
        controls_container.setObjectName("controlsContainer")
        controls_container.setStyleSheet("""
            #controlsContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        controls_container.setGraphicsEffect(self.create_shadow_effect())

        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setSpacing(15)

        # Select folder button
        self.btn_select_folder = QPushButton("Select Folder")
        self.btn_select_folder.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_DirIcon))
        self.btn_select_folder.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_select_folder.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
        """)
        self.btn_select_folder.clicked.connect(self.select_folder)
        controls_layout.addWidget(self.btn_select_folder)

        # Separator
        separator = QLabel("|")
        separator.setStyleSheet("color: #3498db; font-size: 20px;")
        separator.setFixedHeight(40)
        controls_layout.addWidget(separator)

        # Start button
        self.btn_start = QPushButton("Start Checking")
        self.btn_start.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MediaPlay))
        self.btn_start.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_start.setEnabled(False)
        self.btn_start.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """)
        self.btn_start.clicked.connect(self.start_checking)
        controls_layout.addWidget(self.btn_start)

        # Separator
        separator2 = QLabel("|")
        separator2.setStyleSheet("color: #3498db; font-size: 20px;")
        separator2.setFixedHeight(40)
        controls_layout.addWidget(separator2)

        # Open Excel button
        self.btn_open_excel = QPushButton("Open Report")
        self.btn_open_excel.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_FileIcon))
        self.btn_open_excel.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_open_excel.setEnabled(False)
        self.btn_open_excel.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """)
        self.btn_open_excel.clicked.connect(self.open_excel_report)
        controls_layout.addWidget(self.btn_open_excel)

        main_layout.addWidget(controls_container)

        # Progress container
        progress_container = QWidget()
        progress_container.setObjectName("progressContainer")
        progress_container.setStyleSheet("""
            #progressContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        progress_container.setGraphicsEffect(self.create_shadow_effect())

        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setSpacing(8)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 1px;
                text-align: center;
                height: 25px;
            }
            QProgressBar::chunk {
                background: #3498db;
                border-radius: 7px;
            }
        """)
        progress_layout.addWidget(self.progress_bar)

        main_layout.addWidget(progress_container)

        # Log container
        log_container = QWidget()
        log_container.setObjectName("logContainer")
        log_container.setStyleSheet("""
            #logContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        log_container.setGraphicsEffect(self.create_shadow_effect())

        log_layout = QVBoxLayout(log_container)
        log_layout.setSpacing(8)

        # Log header with icon
        log_header = QWidget()
        log_header_layout = QHBoxLayout(log_header)
        log_header_layout.setContentsMargins(0, 0, 0, 10)

        log_icon = QPushButton()
        log_icon.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MessageBoxInformation))
        log_icon.setIconSize(QSize(25, 25))
        log_icon.setFixedSize(25, 25)
        log_icon.setStyleSheet("""
            QPushButton {
                background: #f0f2f5;
                border: none;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        log_header_layout.addWidget(log_icon)

        log_label = QLabel("Processing Log:")
        log_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #2c3e50;")
        log_header_layout.addWidget(log_label)
        log_header_layout.addStretch()

        log_layout.addWidget(log_header)

        # Log text area
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        log_layout.addWidget(self.log_text)

        main_layout.addWidget(log_container)

        # Author info
        author_label = QLabel("Created by nguyenvanvuong1")
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        author_label.setStyleSheet("color: #3498db; padding: 0; margin: 0;")
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 25))
        return shadow

    def select_folder(self):
        self.selected_folder = QFileDialog.getExistingDirectory(
            self, 
            "Select Folder Containing TIFF Images",
            "",
            QFileDialog.Option.ShowDirsOnly
        )
        if self.selected_folder:
            self.log_text.append(f"Selected folder: {self.selected_folder}")
            self.analysis_output_folder = os.path.join(self.selected_folder, Top_EdgeCheckerThread.ANALYSIS_RESULTS_FOLDER)
            os.makedirs(self.analysis_output_folder, exist_ok=True) # Create result folder as soon as folder is selected
            self.btn_start.setEnabled(True)
            self.btn_open_excel.setEnabled(False)
            self.statusBar().showMessage(f"Selected folder: {os.path.basename(self.selected_folder)}")

    def start_checking(self):
        if self.selected_folder:
            self.checker = Top_EdgeCheckerThread(self.selected_folder)
            self.checker.update_progress.connect(self.update_progress)
            self.checker.update_log.connect(self.update_log)
            self.checker.finished.connect(self.on_finished)
            self.checker.start()

            self.btn_start.setEnabled(False)
            self.btn_open_excel.setEnabled(False)
            self.statusBar().showMessage("Checking for topedge...")

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_log(self, message):
        self.log_text.append(message)

    def on_finished(self, topedge_folders):
        self.btn_start.setEnabled(True)
        self.btn_open_excel.setEnabled(True)
        self.statusBar().showMessage("Check completed")

        if topedge_folders:
            unique_folders = list(set(topedge_folders))
            message = "Folders with topedge:\n"
            message += "\n".join(f"- {folder}" for folder in unique_folders)
            
            msg = QMessageBox(self)
            msg.setWindowTitle("Check Results")
            msg.setText(message)
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: #f5f5f5;
                }
                QMessageBox QLabel {
                    font-size: 14px;
                    color: #333;
                    padding: 10px;
                }
                QPushButton {
                    background-color: #2196F3;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 12px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #1976D2;
                }
            """)
            msg.exec()
        else:
            msg = QMessageBox(self)
            msg.setWindowTitle("Check Results")
            msg.setText("No topedge found")
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: #f5f5f5;
                }
                QMessageBox QLabel {
                    font-size: 14px;
                    color: #333;
                    padding: 10px;
                }
                QPushButton {
                    background-color: #2196F3;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 12px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #1976D2;
                }
            """)
            msg.exec()

    def open_excel_report(self):
        try:
            excel_path = os.path.join(self.analysis_output_folder, 'Top_Edge_Detection_Report.xlsx')
            if os.path.exists(excel_path):
                os.startfile(excel_path)
            else:
                QMessageBox.warning(self, "Error", "Excel report file not found!")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not open Excel file: {str(e)}")


    def closeEvent(self, event):
        if self.main_app_window: # Check if main window reference exists
            self.main_app_window.setEnabled(True) # Re-enable the main window
            self.main_app_window.remove_blur_effect() # Remove blur effect from main window
        super().closeEvent(event)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
