import os
import sys
import pandas as pd
import numpy as np
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect, QComboBox, QDialog, QTableWidget, QTableWidgetItem,
    QScrollArea, QGridLayout
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
from openpyxl import Workbook
from openpyxl.styles import Alignment, PatternFill, Border, Side, Font
from openpyxl.utils import get_column_letter
from openpyxl import load_workbook
# Optional: Excel COM for perfect sheet copy (keeps images & formatting)
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None
from PyQt6 import QtCore, QtGui, QtWidgets
import rc.icons

# Import detectors and CCD model helpers
from detector.hotpixel_detector import HotpixelChecker
from detector.bubble_detector import BubbleCheckerThread
from detector.lshape_detector import LShapeCheckerThread
from detector.ccd_detector import CCDChecker, load_model_config, save_model_config, ModelManagementDialog
from detector.hiaa_detector import HiaaCheckerThread
from detector.dust_detector import DustCheckerThread
from detector.topedge_detector import Top_EdgeCheckerThread

class CombinedDetectorController(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    update_detector_status = pyqtSignal(str, str)  # Signal: detector_name, status
    finished = pyqtSignal(dict)

    def __init__(self, root_folder, ccd_model_name, ccd_models_config):
        super().__init__()
        self.root_folder = root_folder
        self.ccd_model_name = ccd_model_name
        self.ccd_models_config = ccd_models_config

        self.results = {
            'hotpixel': [],
            'ccd': [],
            'bubble': [],
            'lshape': [],
            'hiaa': [],
            'dust': [],
            'topedge': []            
        }

        self.detectors = [
            {"name": "HotPixel", "key": "hotpixel", "thread": None, "status": "pending"},
            {"name": "CCD", "key": "ccd", "thread": None, "status": "pending"},
            {"name": "Bubble", "key": "bubble", "thread": None, "status": "pending"},
            {"name": "LShape", "key": "lshape", "thread": None, "status": "pending"},
            {"name": "Dust", "key": "dust", "thread": None, "status": "pending"},
            {"name": "Hiaa", "key": "hiaa", "thread": None, "status": "pending"},
            {"name": "TopEdge", "key": "topedge", "thread": None, "status": "pending"}
        ]
        
        self.combined_path = os.path.join(self.root_folder, "Analysis_Report.xlsx")
        self._summary_initialized = False

    def _forward_log(self, prefix):
        def _inner(message):
            self.update_log.emit(f"[{prefix}] {message}")
        return _inner

    def run(self):
        try:
            # Ensure combined workbook exists
            self._ensure_combined_workbook()
            
            # Update all detectors to "pending" first
            for det in self.detectors:
                det["status"] = "pending"
                self.update_detector_status.emit(det["name"], "pending")
            
            self.update_log.emit("Starting all detectors...")
            
            # HotPixel
            current_det = self.detectors[0]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            hot_thread = HotpixelChecker(self.root_folder)
            hot_thread.update_log.connect(self._forward_log(current_det['name']))
            hot_thread.update_progress.connect(lambda p: self.update_progress.emit(int(p/7)))
            result_container = []
            hot_thread.finished.connect(lambda folders: result_container.extend(folders))
            hot_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['hotpixel'] = list(set(result_container))
            self._append_summary_row(current_det['name'], self.results['hotpixel'])

            # CCD
            current_det = self.detectors[1]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            ccd_thread = CCDChecker(self.root_folder, self.ccd_model_name, self.ccd_models_config)
            ccd_thread.update_log.connect(self._forward_log(current_det['name']))
            ccd_thread.update_progress.connect(lambda p: self.update_progress.emit(int(100/7 + p/7)))
            ccd_result_container = []
            ccd_thread.finished.connect(lambda folders: ccd_result_container.extend(folders))
            ccd_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['ccd'] = list(set(ccd_result_container))
            self._append_summary_row(current_det['name'], self.results['ccd'])

            # Bubble
            current_det = self.detectors[2]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            bubble_thread = BubbleCheckerThread(self.root_folder)
            bubble_thread.update_log.connect(self._forward_log(current_det['name']))
            bubble_thread.update_progress.connect(lambda p: self.update_progress.emit(int(200/7 + p/7)))
            bubble_result_container = []
            bubble_thread.finished.connect(lambda folders: bubble_result_container.extend(folders))
            bubble_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['bubble'] = list(set(bubble_result_container))
            self._append_summary_row(current_det['name'], self.results['bubble'])

            # LShape
            current_det = self.detectors[3]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            lshape_thread = LShapeCheckerThread(self.root_folder)
            lshape_thread.update_log.connect(self._forward_log(current_det['name']))
            lshape_thread.update_progress.connect(lambda p: self.update_progress.emit(int(300/7 + p/7)))
            lshape_result_container = []
            lshape_thread.finished.connect(lambda folders: lshape_result_container.extend(folders))
            lshape_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['lshape'] = list(set(lshape_result_container))
            self._append_summary_row(current_det['name'], self.results['lshape'])

            # Dust
            current_det = self.detectors[4]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            dust_thread = DustCheckerThread(self.root_folder)
            dust_thread.update_log.connect(self._forward_log(current_det['name']))
            dust_thread.update_progress.connect(lambda p: self.update_progress.emit(int(400/7 + p/7)))
            dust_result_container = []
            dust_thread.finished.connect(lambda folders: dust_result_container.extend(folders))
            dust_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['dust'] = list(set(dust_result_container))
            self._append_summary_row(current_det['name'], self.results['dust'])

            # Hiaa
            current_det = self.detectors[5]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            hiaa_thread = HiaaCheckerThread(self.root_folder)
            hiaa_thread.update_log.connect(self._forward_log(current_det['name']))
            hiaa_thread.update_progress.connect(lambda p: self.update_progress.emit(int(500/7 + p/7)))
            hiaa_result_container = []
            hiaa_thread.finished.connect(lambda folders: hiaa_result_container.extend(folders))
            hiaa_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['hiaa'] = list(set(hiaa_result_container))
            self._append_summary_row(current_det['name'], self.results['hiaa'])

            # TopEdge
            current_det = self.detectors[6]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            topedge_thread = Top_EdgeCheckerThread(self.root_folder)
            topedge_thread.update_log.connect(self._forward_log(current_det['name']))
            topedge_thread.update_progress.connect(lambda p: self.update_progress.emit(int(600/7 + p/7)))
            topedge_result_container = []
            topedge_thread.finished.connect(lambda folders: topedge_result_container.extend(folders))
            topedge_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['topedge'] = list(set(topedge_result_container))
            self._append_summary_row(current_det['name'], self.results['topedge'])

            # Tạo file CSV tổng hợp
            self._create_combined_csv()

            self.update_progress.emit(100)
            self.update_log.emit("✅ All checks completed!")
            self.finished.emit(self.results)
        except Exception as e:
            self.update_log.emit(f"Error: {type(e).__name__} - {str(e)}")
            self.finished.emit(self.results)

    def _ensure_combined_workbook(self):
        if self._summary_initialized and os.path.exists(self.combined_path):
            return
        from openpyxl import load_workbook as _lw
        if os.path.exists(self.combined_path):
            wb = _lw(self.combined_path)
            if "Summary" in wb.sheetnames:
                ws = wb["Summary"]
                ws.delete_rows(1, ws.max_row)
            else:
                ws = wb.create_sheet("Summary")
        else:
            wb = Workbook()
            ws = wb.active
            ws.title = "Summary"
        
        headers = ["Detector", "Total Camera", "Camera List"]
        header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        header_font = Font(size=12, bold=True, color="333333")
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=1, column=col_idx)
            c.alignment = Alignment(horizontal='center', vertical='center')
            c.fill = header_fill
            c.font = header_font
            c.border = thin_border
            ws.column_dimensions[get_column_letter(col_idx)].width = 30 if col_idx != 3 else 60
        wb.save(self.combined_path)
        self._summary_initialized = True

    def _append_summary_row(self, name, folders):
        try:
            from openpyxl import load_workbook as _lw
            wb = _lw(self.combined_path)
            ws = wb["Summary"] if "Summary" in wb.sheetnames else wb.active
            thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
            folders_sorted = sorted(set(folders)) if folders else []
            error_count = len(folders_sorted)
            total_cameras = 0
            if os.path.exists(self.root_folder):
                total_cameras = len([f for f in os.listdir(self.root_folder) if os.path.isdir(os.path.join(self.root_folder, f)) 
                                    and f not in ["Hotpixel_Analysis_Results", "CCD_Analysis_Results", "Dust_Analysis_Results", "Hiaa_Analysis_Results",
                                                  "Bubble_Analysis_Results", "LShape_Analysis_Results"]])
            camera_count_text = f"{error_count} / {total_cameras}" if total_cameras > 0 else str(error_count)
            ws.append([name, camera_count_text, "\n".join(folders_sorted)])
            row = ws.max_row
            for col in range(1, 4):
                cell = ws.cell(row=row, column=col)
                cell.alignment = Alignment(horizontal='left', vertical='top', wrapText=True)
                cell.border = thin_border
            wb.save(self.combined_path)
            self.update_log.emit(f"Summary updated: {name} -> {error_count} / {total_cameras} cameras")
        except Exception as e:
            self.update_log.emit(f"Warning: could not update Summary for {name}: {e}")

    def _convert_numpy_types(self, value):
        """Convert numpy types to Python native types"""
        if value is None:
            return value
        
        # Check if value is a numpy scalar
        if isinstance(value, np.generic):
            # Convert numpy scalar to Python native type
            return value.item()
        
        # Check if value is a numpy array
        if isinstance(value, np.ndarray):
            # Convert numpy array to list
            return value.tolist()
        
        # For lists/tuples containing numpy types
        if isinstance(value, (list, tuple)):
            return [self._convert_numpy_types(item) for item in value]
        
        # For strings that might contain numpy representations
        if isinstance(value, str):
            # Clean up np.int64 strings
            import re
            # Pattern to match np.int64(123) or np.float64(123.45)
            pattern = r'np\.(?:int|float)\d+\(([^)]+)\)'
            if re.search(pattern, value):
                # Replace np.int64(123) with 123
                value = re.sub(r'np\.(?:int|float)\d+\(([^)]+)\)', r'\1', value)
        
        return value

    def _format_special_values(self, value):
        """Format special values like tuples, lists, numpy arrays for CSV output"""
        if value is None:
            return ''
        
        # Convert numpy types first
        value = self._convert_numpy_types(value)
        
        # Handle tuples
        if isinstance(value, tuple):
            # Format each element as string
            return f"({', '.join(str(item) for item in value)})"
        
        # Handle lists
        if isinstance(value, list):
            # Format each element as string
            return f"[{', '.join(str(item) for item in value)}]"
        
        # Handle strings that might still contain numpy representations
        if isinstance(value, str):
            # Further clean up if needed
            import re
            # Clean up any remaining numpy representations
            value = re.sub(r'np\.(?:int|float)\d+\(([^)]+)\)', r'\1', value)
        
        return value

    def _clean_dataframe_columns(self, df):
        """Clean all columns in DataFrame to remove numpy types"""
        if df.empty:
            return df
        
        # Apply conversion to all cells
        for col in df.columns:
            df[col] = df[col].apply(self._convert_numpy_types)
        
        return df

    def _create_combined_csv(self):
        """Create combined CSV file with all defect data grouped by image file"""
        try:
            self.update_log.emit("Creating combined CSV file...")
            
            # Define CSV files to read (try both subfolder and root folder locations)
            csv_locations = [
                {
                    'Hotpixel': os.path.join(self.root_folder, "Hotpixel_Analysis_Results", "Hotpixel_Profile_Details.csv"),
                    'CCD': os.path.join(self.root_folder, "CCD_Analysis_Results", "CCD_Profile_Details.csv"),
                    'Bubble': os.path.join(self.root_folder, "Bubble_Analysis_Results", "Bubble_Profile_Details.csv"),
                    'LShape': os.path.join(self.root_folder, "LShape_Analysis_Results", "LShape_Profile_Details.csv"),
                    'Dust': os.path.join(self.root_folder, "Dust_Analysis_Results", "Dust_Profile_Details.csv"),
                    'Hiaa': os.path.join(self.root_folder, "Hiaa_Analysis_Results", "Hiaa_Profile_Details.csv"),
                    'TopEdge': os.path.join(self.root_folder, "Top_Edge_Analysis_Results", "Top_Edge_Profile_Details.csv")
                },
                {
                    'Hotpixel': os.path.join(self.root_folder, "Hotpixel_Profile_Details.csv"),
                    'CCD': os.path.join(self.root_folder, "CCD_Profile_Details.csv"),
                    'Bubble': os.path.join(self.root_folder, "Bubble_Profile_Details.csv"),
                    'LShape': os.path.join(self.root_folder, "LShape_Profile_Details.csv"),
                    'Dust': os.path.join(self.root_folder, "Dust_Profile_Details.csv"),
                    'Hiaa': os.path.join(self.root_folder, "Hiaa_Profile_Details.csv"),
                    'TopEdge': os.path.join(self.root_folder, "Top_Edge_Profile_Details.csv")
                }
            ]
            
            # Dictionary to store data grouped by file
            file_data = {}
            
            # Process each detector's CSV file
            for detector_name in ['Hotpixel', 'CCD', 'Bubble', 'LShape', 'Dust', 'Hiaa', 'TopEdge']:
                csv_path = None
                # Try all possible locations
                for location_set in csv_locations:
                    if detector_name in location_set and os.path.exists(location_set[detector_name]):
                        csv_path = location_set[detector_name]
                        break
                
                if csv_path and os.path.exists(csv_path):
                    try:
                        df = pd.read_csv(csv_path, encoding='utf-8-sig')
                        if not df.empty:
                            self.update_log.emit(f"Processing {detector_name}: {len(df)} records")
                            
                            # Clean numpy types from the dataframe
                            df = self._clean_dataframe_columns(df)
                            
                            # Process each row in the CSV
                            for index, row in df.iterrows():
                                # Get common columns (with fallback values)
                                folder = row.get('Folder', 'Unknown')
                                file_name = row.get('File Name', 'Unknown')
                                pattern = row.get('Pattern', 'Unknown')
                                resolution = row.get('Resolution', 'Unknown')
                                status = row.get('Status', 'N/A')
                                
                                # Create a unique key for this file
                                file_key = f"{folder}_{file_name}"
                                
                                # Initialize if this is first time seeing this file
                                if file_key not in file_data:
                                    file_data[file_key] = {
                                        'Folder': folder,
                                        'File Name': file_name,
                                        'Pattern': pattern,
                                        'Resolution': resolution,
                                        'Status': set(),  # Use set to avoid duplicates
                                    }
                                
                                # Add detector prefix to detector-specific columns and store values
                                for col_name, value in row.items():
                                    if col_name not in ['Folder', 'File Name', 'Pattern', 'Resolution', 'Status']:
                                        # Add detector prefix to avoid column name conflicts
                                        new_col_name = f"{detector_name}_{col_name}"
                                        # Format value to clean up numpy types
                                        value = self._format_special_values(value)
                                        file_data[file_key][new_col_name] = value
                                
                                # Add status for this detector if it found an issue
                                if status and status != 'N/A' and status != 'OK':
                                    # Check if this detector actually found something
                                    has_defect = False
                                    
                                    # Look for indicator columns
                                    indicator_columns = ['Has', 'Found', 'Error', 'Defect', 'Detected']
                                    for col in row.index:
                                        if any(indicator in col for indicator in indicator_columns):
                                            val = row[col]
                                            val_str = str(val).lower()
                                            if (('true' in val_str or 'detected' in val_str or 
                                                  'found' in val_str or 'yes' in val_str or
                                                  'positive' in val_str)):
                                                has_defect = True
                                                break
                                            elif isinstance(val, (int, float)) and float(val) > 0:
                                                has_defect = True
                                                break
                                    
                                    if has_defect:
                                        file_data[file_key]['Status'].add(detector_name)
                                
                    except Exception as e:
                        self.update_log.emit(f"Error processing {detector_name} CSV: {e}")
                        import traceback
                        self.update_log.emit(f"Traceback: {traceback.format_exc()}")
                else:
                    self.update_log.emit(f"CSV file not found for {detector_name}")
            
            if not file_data:
                self.update_log.emit("No data to combine")
                return
            
            # Convert dictionary to DataFrame
            rows = []
            for file_key, data in file_data.items():
                # Convert Status set to string
                if data['Status']:
                    data['Status'] = ', '.join(sorted(data['Status']))
                else:
                    data['Status'] = 'OK'
                
                rows.append(data)
            
            combined_df = pd.DataFrame(rows)
            
            # Define column order for better organization
            common_columns = ['Folder', 'File Name', 'Pattern', 'Resolution', 'Status']
            
            # Get all detector-specific columns
            detector_columns = []
            for col in combined_df.columns:
                if col not in common_columns:
                    detector_columns.append(col)
            
            # Group detector columns by detector type for better organization
            detector_order = ['Hotpixel', 'CCD', 'Bubble', 'LShape', 'Dust', 'Hiaa', 'TopEdge']
            ordered_detector_columns = []
            
            for detector in detector_order:
                detector_cols = [col for col in detector_columns if col.startswith(f"{detector}_")]
                detector_cols.sort()
                ordered_detector_columns.extend(detector_cols)
            
            # Add any remaining columns not in the standard detectors
            remaining_cols = [col for col in detector_columns if col not in ordered_detector_columns]
            ordered_detector_columns.extend(sorted(remaining_cols))
            
            # Final column order
            final_columns = common_columns + ordered_detector_columns
            
            # Reorder DataFrame columns
            combined_df = combined_df.reindex(columns=final_columns)
            
            # Sort by Folder and File Name
            combined_df = combined_df.sort_values(by=['Folder', 'File Name'])
            
            # Reset index
            combined_df = combined_df.reset_index(drop=True)
            
            # Apply final cleaning to ensure no numpy types remain
            combined_df = self._clean_dataframe_columns(combined_df)
            
            # Save combined CSV file
            csv_output_path = os.path.join(self.root_folder, "Combined_Profile_Details.csv")
            combined_df.to_csv(csv_output_path, index=False, encoding='utf-8-sig')
            
            # Also create a more readable summary
            self._create_readable_summary(combined_df)
            
            self.update_log.emit(f"✅ Combined CSV file saved: {csv_output_path}")
            self.update_log.emit(f"Total unique files: {len(combined_df)}")
            
        except Exception as e:
            self.update_log.emit(f"Error creating combined CSV: {type(e).__name__} - {str(e)}")
            import traceback
            self.update_log.emit(f"Traceback: {traceback.format_exc()}")

    def _create_readable_summary(self, combined_df):
        """Create a more readable summary with separate columns for each defect type"""
        try:
            if combined_df.empty:
                return
            
            summary_rows = []
            
            for index, row in combined_df.iterrows():
                summary_row = {
                    'Folder': row.get('Folder', 'Unknown'),
                    'File Name': row.get('File Name', 'Unknown'),
                    'Pattern': row.get('Pattern', 'Unknown'),
                    'Resolution': row.get('Resolution', 'Unknown'),
                    'Status': row.get('Status', 'OK'),
                }
                
                # Add columns for each detector type
                detectors = ['Hotpixel', 'CCD', 'Bubble', 'LShape', 'Dust', 'Hiaa', 'TopEdge']
                
                for detector in detectors:
                    # Check if this detector has any columns in the data
                    detector_cols = [col for col in row.index if col.startswith(f"{detector}_")]
                    
                    if detector_cols:
                        # Check if any defect was detected
                        detected = 'No'
                        details = []
                        
                        for col in detector_cols:
                            value = row[col]
                            if pd.notna(value) and value != '' and value != 'N/A':
                                # Format value to clean up numpy types
                                value = self._format_special_values(value)
                                
                                # Check if this indicates a defect
                                col_name_lower = col.lower()
                                if any(indicator in col_name_lower for indicator in 
                                       ['has', 'found', 'error', 'defect', 'detected', 'number']):
                                    val_str = str(value).lower()
                                    if (('true' in val_str or 'detected' in val_str or 
                                          'found' in val_str or 'yes' in val_str or
                                          'positive' in val_str)):
                                        detected = 'Yes'
                                    elif isinstance(value, (int, float)) and float(value) > 0:
                                        detected = 'Yes'
                                
                                # Add to details if it's not a common column
                                if not any(common in col.lower() for common in 
                                          ['folder', 'file', 'pattern', 'resolution', 'status']):
                                    # Shorten very long values
                                    if isinstance(value, str) and len(value) > 100:
                                        value = value[:97] + "..."
                                    details.append(f"{col.replace(f'{detector}_', '')}: {value}")
                        
                        summary_row[f'{detector}_Detected'] = detected
                        summary_row[f'{detector}_Details'] = '; '.join(details) if details else ''
                    else:
                        summary_row[f'{detector}_Detected'] = 'No Data'
                        summary_row[f'{detector}_Details'] = ''
                
                summary_rows.append(summary_row)
            
            summary_df = pd.DataFrame(summary_rows)
            
            # Define column order for summary
            common_cols = ['Folder', 'File Name', 'Pattern', 'Resolution', 'Status']
            detector_cols = []
            for detector in ['Hotpixel', 'CCD', 'Bubble', 'LShape', 'Dust', 'Hiaa', 'TopEdge']:
                detector_cols.extend([f'{detector}_Detected', f'{detector}_Details'])
            
            final_cols = common_cols + detector_cols
            summary_df = summary_df.reindex(columns=final_cols)
            
            # Apply final cleaning
            summary_df = self._clean_dataframe_columns(summary_df)
            
            # Save summary CSV
            summary_path = os.path.join(self.root_folder, "Combined_Summary_Readable.csv")
            summary_df.to_csv(summary_path, index=False, encoding='utf-8-sig')
            
            self.update_log.emit(f"✅ Readable summary saved: {summary_path}")
            
        except Exception as e:
            self.update_log.emit(f"Error creating readable summary: {e}")

class DetectorStatusWidget(QWidget):
    """Compact widget for detector status"""
    def __init__(self, detector_name, parent=None):
        super().__init__(parent)
        self.detector_name = detector_name
        self.status = "pending"
        
        self.setFixedHeight(30)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(8)
        
        # Status icon
        self.icon_label = QLabel()
        self.icon_label.setFixedSize(16, 16)
        self._update_icon()
        layout.addWidget(self.icon_label)
        
        # Detector name
        self.name_label = QLabel(detector_name)
        self.name_label.setFont(QFont("Segoe UI", 9))
        self.name_label.setStyleSheet("color: #2c3e50;")
        layout.addWidget(self.name_label)
        
        # Status text
        self.status_label = QLabel("Pending")
        self.status_label.setFont(QFont("Segoe UI", 8))
        layout.addWidget(self.status_label)
        
        layout.addStretch()
    
    def _update_icon(self):
        if self.status == "completed":
            self.icon_label.setStyleSheet("""
                QLabel {
                    background: #27ae60;
                    border-radius: 8px;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.icon_label.setText("✓")
        elif self.status == "Checking":
            self.icon_label.setStyleSheet("""
                QLabel {
                    background: #3498db;
                    border-radius: 8px;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.icon_label.setText("▶")
        else:  # pending
            self.icon_label.setStyleSheet("""
                QLabel {
                    background: #95a5a6;
                    border-radius: 8px;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.icon_label.setText("●")
    
    def update_status(self, status):
        self.status = status
        self._update_icon()
        
        if status == "completed":
            self.status_label.setText("Completed")
            self.status_label.setStyleSheet("color: #27ae60; font-weight: bold;")
            self.name_label.setStyleSheet("color: #27ae60; font-weight: bold;")
        elif status == "Checking":
            self.status_label.setText("Checking...")
            self.status_label.setStyleSheet("color: #3498db; font-weight: bold;")
            self.name_label.setStyleSheet("color: #3498db; font-weight: bold;")
        else:  # pending
            self.status_label.setText("Pending")
            self.status_label.setStyleSheet("color: #7f8c8d;")
            self.name_label.setStyleSheet("color: #2c3e50;")

class SummaryDialog(QDialog):
    def __init__(self, parent, table_rows, open_cb):
        super().__init__(parent)
        self.setWindowTitle("Image Analysis Results")
        self.setModal(True)
        self.resize(800, 700)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        header = QWidget()
        header.setFixedHeight(70)
        header.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 10px;
            }
        """)
        hl = QHBoxLayout(header)
        hl.setContentsMargins(20, 0, 20, 0)
        
        title = QLabel("📊 Image Analysis Results")
        title.setStyleSheet("color: white; font-weight: bold;")
        title.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        hl.addWidget(title)
        hl.addStretch()
        
        self.btn_open = QPushButton("📁 Open Report Excel")
        self.btn_open.setStyleSheet("""
            QPushButton {
                background: #fff;
                color: #2c3e50;
                border: 2px solid #fff;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover {
                background: #eaf2fb;
                border-color: #eaf2fb;
            }
            QPushButton:pressed {
                background: #d0e0f0;
            }
        """)
        self.btn_open.clicked.connect(open_cb)
        hl.addWidget(self.btn_open)
        layout.addWidget(header)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: #f0f0f0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background: #3498db;
                border-radius: 6px;
                min-height: 30px;
            }
            QScrollBar::handle:vertical:hover {
                background: #2980b9;
            }
        """)
        
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Detector", "Total Camera", "Camera List"])
        self.table.setStyleSheet("""
            QTableWidget {
                background: #ffffff;
                border: 2px solid #e0e0e0;
                border-radius: 10px;
                gridline-color: #e8e8e8;
                font-size: 12px;
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid #f0f0f0;
            }
            QTableWidget::item:selected {
                background: #e3f2fd;
                color: #1976d2;
            }
            QHeaderView::section {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #f5f5f5, stop:1 #e8e8e8);
                color: #2c3e50;
                font-weight: bold;
                font-size: 13px;
                padding: 10px;
                border: none;
                border-bottom: 2px solid #3498db;
            }
        """)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        
        error_ratios = []
        for row in table_rows:
            if len(row) >= 5:
                error_count = row[3]
                total_count = row[4]
                if total_count > 0:
                    ratio = error_count / total_count
                    error_ratios.append(ratio)
                else:
                    error_ratios.append(0.0)
        
        min_ratio = min(error_ratios) if error_ratios else 0.0
        max_ratio = max(error_ratios) if error_ratios else 1.0
        
        for i, row in enumerate(table_rows):
            r = self.table.rowCount()
            self.table.insertRow(r)
            for c, val in enumerate(row[:3]):
                item = QTableWidgetItem(str(val))
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if c == 0:
                    item.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
                    item.setForeground(QColor("#2c3e50"))
                elif c == 1:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    item.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
                    if len(row) >= 5 and i < len(error_ratios):
                        ratio = error_ratios[i]
                        if max_ratio > min_ratio:
                            normalized = (ratio - min_ratio) / (max_ratio - min_ratio)
                        else:
                            normalized = 0.0
                        
                        red = int(255 * normalized)
                        green = int(255 * (1 - normalized))
                        blue = int(255 * (1 - normalized))
                        
                        red = min(255, max(200, red))
                        green = min(255, max(200, green))
                        blue = min(255, max(200, blue))
                        
                        bg_color = QColor(red, green, blue)
                        brightness = red * 0.299 + green * 0.587 + blue * 0.114
                        text_color = QColor("#000000") if brightness > 180 else QColor("#FFFFFF")
                        
                        item.setBackground(bg_color)
                        item.setForeground(text_color)
                else:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
                self.table.setItem(r, c, item)
        
        self.table.setColumnWidth(0, 200)
        self.table.setColumnWidth(1, 150)
        self.table.setWordWrap(True)
        self.table.resizeRowsToContents()
        
        scroll_area.setWidget(self.table)
        layout.addWidget(scroll_area)
        
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)
        btn_close = QPushButton("✕ Close")
        btn_close.setStyleSheet("""
            QPushButton {
                background: #3498db;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px 24px;
                font-weight: bold;
                font-size: 13px;
                min-width: 100px;
            }
            QPushButton:hover {
                background: #2980b9;
            }
            QPushButton:pressed {
                background: #21618c;
            }
        """)
        btn_close.clicked.connect(self.accept)
        btn_row.addStretch()
        btn_row.addWidget(btn_close)
        layout.addLayout(btn_row)


class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_app_window = parent
        self.setWindowTitle("Automatic Image Analysis Tool")
        self.resize(700, 900)  # Slightly taller for status grid
        self.setWindowIcon(QIcon(":/icons/image_analysis.png"))

        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 247, 250))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(52, 73, 94))
        self.setPalette(palette)

        app = QApplication.instance()
        if app is not None:
            try:
                app.setQuitOnLastWindowClosed(False)
            except Exception:
                pass

        self.selected_folder = None
        self.analysis_output_folder = None
        self.models_config = load_model_config()
        self.detector_widgets = {}

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Header
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(90)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)
        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))
        icon_button.setGraphicsEffect(icon_shadow)
        icon = QtGui.QIcon(":/icons/image_analysis.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70))
        header_layout.addWidget(icon_button)

        text_container = QtWidgets.QWidget()
        text_container.setStyleSheet("""
            QWidget {
                background: transparent;
            }
        """)
        text_layout = QtWidgets.QVBoxLayout(text_container)
        text_layout.setSpacing(5)

        title_label = QtWidgets.QLabel("Automatic Image Analysis Tool")
        title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        title_label.setFont(QtGui.QFont("Segoe UI", 22, QtGui.QFont.Weight.Bold))
        title_label.setStyleSheet("""
            color: white;
            padding: 0;
            margin: 0;
            letter-spacing: 1px;
        """)

        subtitle_label = QtWidgets.QLabel("HotPixel, CCD, Bubble, LShape, Dust, Hiaa, TopEdge Camera defect Checker")
        subtitle_label.setFont(QtGui.QFont("Segoe UI", 9, QtGui.QFont.Weight.Bold))
        subtitle_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.95);
            margin-top: 0px;
            padding: 0;
            letter-spacing: 0.5px;
        """)

        text_layout.addWidget(title_label)
        text_layout.addWidget(subtitle_label)
        header_layout.addWidget(text_container)

        header_layout.addStretch()

        self.btn_manage_models = QtWidgets.QPushButton("")
        self.btn_manage_models.setIcon(QIcon(":/icons/setting.png"))
        self.btn_manage_models.setIconSize(QSize(50, 50))
        self.btn_manage_models.setFixedSize(60, 60)
        self.btn_manage_models.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_manage_models.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.2);
                border: none;
                border-radius: 20px;
                padding: 5px;
                color: white;
            }
            QPushButton:hover { background-color: rgba(255, 255, 255, 0.3); }
            QPushButton:pressed { background-color: rgba(255, 255, 255, 0.4); }
        """)
        settings_shadow = QtWidgets.QGraphicsDropShadowEffect()
        settings_shadow.setBlurRadius(8)
        settings_shadow.setXOffset(1)
        settings_shadow.setYOffset(1)
        settings_shadow.setColor(QtGui.QColor(0, 0, 0, 60))
        self.btn_manage_models.setGraphicsEffect(settings_shadow)
        self.btn_manage_models.clicked.connect(self.manage_models)
        header_layout.addWidget(self.btn_manage_models)
        main_layout.addWidget(header_container)

        # Controls
        controls_container = QWidget()
        controls_container.setObjectName("controlsContainer")
        controls_container.setStyleSheet("""
            #controlsContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        controls_container.setGraphicsEffect(self.create_shadow_effect())
        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setSpacing(10)

        model_label = QLabel("Select Model:")
        model_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        model_label.setStyleSheet("color: #2c3e50;")
        controls_layout.addWidget(model_label)

        self.combo_model_selection = QtWidgets.QComboBox()
        self.combo_model_selection.setStyleSheet("""
            QComboBox {
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 8px;
                padding: 5px 10px;
                min-width: 80px;
                color: #2c3e50;
                font-size: 14px;
            }
            QComboBox:hover {
                border: 2px solid #3498db;
                background-color: #f7fbff;
            }
            QComboBox:focus {
                border: 2px solid #3498db;
                background-color: white;
            }

            /* Nút dropdown */
            QComboBox::drop-down {
                border: none;
                padding-right: 10px;
            }
            QComboBox::down-arrow {
                image: url(:/icons/down_arrow.png);
                width: 12px;
                height: 12px;
            }

            /* Drop-down list */
            QComboBox QAbstractItemView {
                background: white;  /* White background */
                border: 1px solid rgba(0, 0, 0, 0.2);  /* Light shadow border */
                border-radius: 6px;
                padding: 2px;
                outline: 0px;
                selection-background-color: transparent;
            }

            /* Reduced list padding */
            QComboBox QAbstractItemView::item {
                font-size: 14px;
                padding: 3px 10px;
                color: #2c3e50;
                background-color: white; /* White background */
            }

            /* Hover stands out more */
            QComboBox QAbstractItemView::item:hover {
                color: white;
                background-color: #00c2c7; /* Turquoise background */
                border-radius: 4px; /* Bo góc nhẹ */
            }

            /* Item is selected */
            QComboBox QAbstractItemView::item:selected {
                color: white;
                background-color: #00a2b3; /* Darker turquoise */
                border-radius: 4px;
            }
        """)
        controls_layout.addWidget(self.combo_model_selection)

        self.combo_model_selection.blockSignals(True)
        self.combo_model_selection.currentTextChanged.connect(self.on_model_selected)
        initial_config = load_model_config()
        self.models_config = initial_config["models"]
        self.last_selected_model = initial_config["last_selected_model"]
        if not self.models_config:
            self.models_config = {"D965": 721, "D914": 699}
            self.last_selected_model = "D965"
            save_model_config({"models": self.models_config, "last_selected_model": self.last_selected_model})
        self._load_models_to_combobox()
        if self.last_selected_model and self.last_selected_model in self.models_config:
            self.combo_model_selection.setCurrentText(self.last_selected_model)
            self.selected_model = self.last_selected_model
        elif self.models_config:
            self.selected_model = next(iter(self.models_config))
            self.combo_model_selection.setCurrentText(self.selected_model)
        else:
            self.selected_model = None
        self.combo_model_selection.blockSignals(False)
        if self.selected_model:
            self.on_model_selected()

        separator = QLabel("|")
        separator.setStyleSheet("color: #3498db; font-size: 20px;")
        separator.setFixedHeight(40)
        controls_layout.addWidget(separator)

        self.btn_select_folder = QPushButton("Select Folder")
        self.btn_select_folder.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_DirIcon))
        self.btn_select_folder.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_select_folder.setStyleSheet(self._button_style())
        self.btn_select_folder.clicked.connect(self.select_folder)
        controls_layout.addWidget(self.btn_select_folder)

        separator1 = QLabel("|")
        separator1.setStyleSheet("color: #3498db; font-size: 20px;")
        separator1.setFixedHeight(40)
        controls_layout.addWidget(separator1)

        self.btn_start = QPushButton("Start Checking")
        self.btn_start.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MediaPlay))
        self.btn_start.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_start.setEnabled(False)
        self.btn_start.setStyleSheet(self._button_style())
        self.btn_start.clicked.connect(self.start_checking)
        controls_layout.addWidget(self.btn_start)

        main_layout.addWidget(controls_container)

        # Detector Status Section - Compact
        status_container = QWidget()
        status_container.setObjectName("statusContainer")
        status_container.setStyleSheet("""
            #statusContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        status_container.setGraphicsEffect(self.create_shadow_effect())
        status_layout = QVBoxLayout(status_container)
        status_layout.setSpacing(0)
        
        status_header = QWidget()
        status_header_layout = QHBoxLayout(status_header)
        status_header_layout.setContentsMargins(0, 0, 0, 5)
        
        status_title = QLabel("Detector Status")
        status_title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        status_title.setStyleSheet("color: #2c3e50;")
        status_header_layout.addWidget(status_title)
        status_header_layout.addStretch()
        
        self.overall_status_label = QLabel("Overall: Ready")
        self.overall_status_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        self.overall_status_label.setStyleSheet("color: #3498db;")
        status_header_layout.addWidget(self.overall_status_label)
        
        status_layout.addWidget(status_header)
        
        # Grid for detector status widgets (4 columns for compact layout)
        grid_widget = QWidget()
        grid_layout = QGridLayout(grid_widget)
        grid_layout.setHorizontalSpacing(10)
        grid_layout.setVerticalSpacing(0)
        grid_layout.setContentsMargins(0, 0, 0, 0)
        
        detectors = ["HotPixel", "CCD", "Bubble", "LShape", "Dust", "Hiaa", "TopEdge"]
        for i, detector_name in enumerate(detectors):
            widget = DetectorStatusWidget(detector_name)
            self.detector_widgets[detector_name] = widget
            row = i // 4
            col = i % 4
            grid_layout.addWidget(widget, row, col)
        
        status_layout.addWidget(grid_widget)
        main_layout.addWidget(status_container)

        # Overall Progress
        progress_container = QWidget()
        progress_container.setObjectName("progressContainer")
        progress_container.setStyleSheet("""
            #progressContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        progress_container.setGraphicsEffect(self.create_shadow_effect())
        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setSpacing(0)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 1px;
                text-align: center;
                height: 25px;
                font-size: 11px;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 7px;
            }
        """)
        progress_layout.addWidget(self.progress_bar)
        main_layout.addWidget(progress_container)

        # Log
        log_container = QWidget()
        log_container.setObjectName("logContainer")
        log_container.setStyleSheet("""
            #logContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        log_container.setGraphicsEffect(self.create_shadow_effect())
        log_layout = QVBoxLayout(log_container)
        log_layout.setSpacing(0)
        log_header = QWidget()
        log_header_layout = QHBoxLayout(log_header)
        log_header_layout.setContentsMargins(0, 0, 0, 10)
        log_icon = QPushButton()
        log_icon.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MessageBoxInformation))
        log_icon.setIconSize(QSize(18, 18))
        log_icon.setFixedSize(18, 18)
        log_icon.setStyleSheet("""
            QPushButton {
                background: #f0f2f5;
                border: none;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        log_header_layout.addWidget(log_icon)
        log_label = QLabel("Processing Log:")
        log_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #2c3e50;")
        log_header_layout.addWidget(log_label)
        log_header_layout.addStretch()
        log_layout.addWidget(log_header)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        log_layout.addWidget(self.log_text)
        main_layout.addWidget(log_container)

        author_label = QLabel("Created by nguyenvanvuong1")
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        author_label.setStyleSheet("color: #3498db; padding: 0; margin: 0;")
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        self.controller = None
        self.summary_results = None

    def _button_style(self):
        return """
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 32px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 25))
        return shadow

    def _load_models_to_combobox(self):
        try:
            self.combo_model_selection.clear()
            for model_name in self.models_config.keys():
                self.combo_model_selection.addItem(model_name)
        except Exception:
            pass

    def on_model_selected(self):
        try:
            self.selected_model = self.combo_model_selection.currentText()
            self.last_selected_model = self.selected_model
            save_model_config({"models": self.models_config, "last_selected_model": self.last_selected_model})
            if hasattr(self, 'log_text'):
                self.log_text.append(f"Selected model: {self.selected_model}")
        except Exception:
            pass

    def select_folder(self):
        self.selected_folder = QFileDialog.getExistingDirectory(
            self,
            "Select Folder Containing TIFF Images",
            "",
            QFileDialog.Option.ShowDirsOnly
        )
        if self.selected_folder:
            self.log_text.append(f"Selected folder: {self.selected_folder}")
            self.analysis_output_folder = self.selected_folder
            self.btn_start.setEnabled(True)
            self.statusBar().showMessage(f"Selected folder: {os.path.basename(self.selected_folder)}")

    def start_checking(self):
        if not self.selected_folder:
            QMessageBox.warning(self, "Warning", "Please select a folder first!")
            return
        
        current_model = getattr(self, 'selected_model', None) or (self.combo_model_selection.currentText() if hasattr(self, 'combo_model_selection') else None)
        if current_model:
            save_model_config({"models": self.models_config, "last_selected_model": current_model})

        # Reset all detector widgets
        for detector_name, widget in self.detector_widgets.items():
            widget.update_status("pending")
        
        self.controller = CombinedDetectorController(self.selected_folder, current_model, self.models_config)
        self.controller.update_progress.connect(self.update_progress)
        self.controller.update_log.connect(self.update_log)
        self.controller.update_detector_status.connect(self.update_detector_status)
        self.controller.finished.connect(self.on_finished)
        self.controller.start()

        self.btn_start.setEnabled(False)
        self.overall_status_label.setText("Overall: Checking")
        self.overall_status_label.setStyleSheet("color: #3498db; font-weight: bold;")
        self.statusBar().showMessage("Running detectors...")

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_detector_status(self, detector_name, status):
        """Update individual detector status widget"""
        if detector_name in self.detector_widgets:
            self.detector_widgets[detector_name].update_status(status)

    def update_log(self, message):
        self.log_text.append(message)

    def on_finished(self, results):
        self.btn_start.setEnabled(True)
        self.overall_status_label.setText("Overall: Completed")
        self.overall_status_label.setStyleSheet("color: #27ae60; font-weight: bold;")
        self.statusBar().showMessage("Check completed")
        self.summary_results = results

        combined_path = None
        table_rows = []
        try:
            combined_path, table_rows = self._create_combined_excel_report(results)
        except Exception as e:
            self.log_text.append(f"Error creating combined report: {e}")

        def open_combined():
            if not combined_path or not os.path.exists(combined_path):
                QMessageBox.warning(self, "Error", "Combined report is not available.")
                return
            try:
                os.startfile(combined_path)
            except Exception as ee:
                QMessageBox.warning(self, "Error", f"Could not open Excel file: {ee}")

        self.summary_dialog = SummaryDialog(self, table_rows, open_combined)
        self.summary_dialog.exec()

    def _create_combined_excel_report(self, results):
        root = self.selected_folder
        if not root:
            return None, []
        
        from openpyxl import load_workbook as _lw
        combined_path = os.path.join(root, "Analysis_Report.xlsx")
        if os.path.exists(combined_path):
            wb = _lw(combined_path)
            if "Summary" in wb.sheetnames:
                ws = wb["Summary"]
                ws.delete_rows(1, ws.max_row)
            else:
                ws = wb.create_sheet("Summary", 0)
        else:
            wb = Workbook()
            ws = wb.active
            ws.title = "Summary"

        headers = ["Detector", "Total Camera", "Camera List"]
        header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        header_font = Font(size=12, bold=True, color="333333")
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=1, column=col_idx)
            c.alignment = Alignment(horizontal='center', vertical='center')
            c.fill = header_fill
            c.font = header_font
            c.border = thin_border
            ws.column_dimensions[get_column_letter(col_idx)].width = 30 if col_idx != 3 else 60

        total_cameras = 0
        if os.path.exists(root):
            total_cameras = len([f for f in os.listdir(root) if os.path.isdir(os.path.join(root, f)) 
                                and f not in ["Hotpixel_Analysis_Results", "CCD_Analysis_Results", "Dust_Analysis_Results", "Hiaa_Analysis_Results",
                                              "Bubble_Analysis_Results", "LShape_Analysis_Results", "Top_Edge_Analysis_Results"]])

        table_rows = []
        error_ratios = []

        def add_row(name, folders):
            folders_sorted = sorted(set(folders)) if folders else []
            error_count = len(folders_sorted)
            camera_count_text = f"{error_count} / {total_cameras}" if total_cameras > 0 else str(error_count)
            ws.append([name, camera_count_text, "\n".join(folders_sorted)])
            row = ws.max_row
            
            if total_cameras > 0:
                error_ratio = error_count / total_cameras
            else:
                error_ratio = 0.0
            error_ratios.append(error_ratio)
            
            for col in range(1, 7):
                cell = ws.cell(row=row, column=col)
                cell.alignment = Alignment(horizontal='left', vertical='top', wrapText=True)
                cell.border = thin_border
            
            camera_list_text = "\n".join(folders_sorted) if folders_sorted else ""
            table_rows.append([name, camera_count_text, camera_list_text, error_count, total_cameras])

        add_row("HotPixel Checking", results.get('hotpixel', []))
        add_row("CCD Checking", results.get('ccd', []))
        add_row("Bubble Checking", results.get('bubble', []))
        add_row("LShape", results.get('lshape', []))
        add_row("Dust", results.get('dust', []))
        add_row("Hiaa", results.get('hiaa', []))
        add_row("TopEdge", results.get('topedge', []))

        if error_ratios:
            min_ratio = min(error_ratios)
            max_ratio = max(error_ratios)
            
            for i, ratio in enumerate(error_ratios, start=2):
                if max_ratio > min_ratio:
                    normalized = (ratio - min_ratio) / (max_ratio - min_ratio)
                else:
                    normalized = 0.0
                
                red = int(255 * normalized)
                green = int(255 * (1 - normalized))
                blue = int(255 * (1 - normalized))
                
                red = min(255, max(200, red))
                green = min(255, max(200, green))
                blue = min(255, max(200, blue))
                
                fill_color = PatternFill(start_color=f"{red:02x}{green:02x}{blue:02x}", 
                                       end_color=f"{red:02x}{green:02x}{blue:02x}", 
                                       fill_type="solid")
                
                total_camera_cell = ws.cell(row=i, column=2)
                total_camera_cell.fill = fill_color
                
                brightness = red * 0.299 + green * 0.587 + blue * 0.114
                if brightness > 180:
                    total_camera_cell.font = Font(bold=True, color="000000")
                else:
                    total_camera_cell.font = Font(bold=True, color="FFFFFF")

        combined_path = os.path.join(root, "Analysis_Report.xlsx")
        wb.save(combined_path)
        self.log_text.append(f"Combined report saved: {combined_path}")
        return combined_path, table_rows

    def _try_copy_report(self, src_path, dest_wb, expected_sheet_name):
        return

    def _try_merge_reports_with_excel_com(self, combined_path, src_list):
        return

    def closeEvent(self, event):
        if self.main_app_window:
            self.main_app_window.setEnabled(True)
            self.main_app_window.remove_blur_effect()
        super().closeEvent(event)

    def manage_models(self):
        dialog = ModelManagementDialog(self.models_config.copy(), self)
        if dialog.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            updated = load_model_config()
            self.models_config = updated.get("models", {})
            last = updated.get("last_selected_model")
            self.combo_model_selection.clear()
            self.combo_model_selection.addItems(list(self.models_config.keys()))
            if last and last in self.models_config:
                self.combo_model_selection.setCurrentText(last)
                self.selected_model = last
            elif self.models_config:
                self.combo_model_selection.setCurrentIndex(0)
                self.selected_model = self.combo_model_selection.currentText()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())