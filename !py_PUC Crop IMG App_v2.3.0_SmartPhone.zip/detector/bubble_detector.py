import cv2
import numpy as np
import os
import re
import math
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
import sys
from PIL import Image 
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
import rc.icons 
from PyQt6 import QtCore, QtGui, QtWidgets 
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

def local_variance_filter(image, r=18):
    """
    Calculates local variance with a kernel size of 2*r+1
    """
    kernel_size = 2 * r + 1
    img_float = image.astype(np.float32)

    # Calculate mean
    mean = cv2.blur(img_float, (kernel_size, kernel_size))

    # Calculate mean of squares
    mean_sq = cv2.blur(img_float**2, (kernel_size, kernel_size))

    # Variance = E[X^2] - (E[X])^2
    variance = mean_sq - mean**2
    return variance

def detect_bubbles(image_path, r=18, threshold_scale=3.2, file_name=None):
    # read image 16-bit by OpenCV
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
    
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")
    
    # if images have many channel, convert to grayscale
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Apply Gaussian blur with sigma (radius) 2.00 to remove noise
    sigma = 3.2
    kernel_size = int(2 * np.ceil(2 * sigma) + 1)
    img = cv2.GaussianBlur(img, (kernel_size, kernel_size), sigma)
    
    # Apply variance filter
    var_img = local_variance_filter(img, r=r)

    # Normalize to 0-255 for visualization
    var_norm = cv2.normalize(var_img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)

    # Automatic threshold based on mean
    thresh_val = np.mean(var_img) * threshold_scale

    # Binary mask
    _, mask = cv2.threshold(var_img, thresh_val, 65535, cv2.THRESH_BINARY)

    # Morphology to remove noise
    mask = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5,5), np.uint8))

    # Find contours
    result = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Xử lý cho cả OpenCV 3.x và 4.x
    if len(result) == 3:
        # OpenCV 3.x: (image, contours, hierarchy)
        _, contours, _ = result
    elif len(result) == 2:
        # OpenCV 4.x: (contours, hierarchy)
        contours, _ = result
    else:
        contours = result[0] if result else []

    # Filter out contours near image borders with new parameter
    filtered_contours = []
    img_height, img_width = img.shape[:2]
    
    # setup for checking region
    left_border_threshold = 200  # skip left side 200 pixel
    other_border_threshold = 50  # remain 3 sides 50 pixel
    corner_radius = 50  # Border 50 pixel

    if file_name:
        pattern_match = re.search(r'step0[1-9]_\d+NIT_[RGBW](120|192|216)', file_name)
        if pattern_match:
            last_digits = pattern_match.group(1)
            left_border_threshold = 200

    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        
        # Check if the bounding box is outside the specified border regions
        if (x > left_border_threshold and 
            y > other_border_threshold and 
            (x + w) < (img_width - other_border_threshold) and 
            (y + h) < (img_height - other_border_threshold)):
            
            # Check the corner rounding for all 3-digit patterns.
            if file_name and re.search(r'step0[1-9]_\d+NIT_[RGBW](120|192|216)', file_name):
                # Check top-right corner (radius 50 pixels)
                top_right_x = x + w
                top_right_y = y
                top_right_center_x = img_width - corner_radius
                top_right_center_y = corner_radius
                
                # Calculate distance from top-right corner to the center of the rounded corner
                dist_top_right = np.sqrt((top_right_x - top_right_center_x)**2 + 
                                         (top_right_y - top_right_center_y)**2)
                
                # Check bottom-right corner (radius 50 pixels)
                bottom_right_x = x + w
                bottom_right_y = y + h
                bottom_right_center_x = img_width - corner_radius
                bottom_right_center_y = img_height - corner_radius
                
                # Calculate distance from bottom-right corner to the center of the rounded corner
                dist_bottom_right = np.sqrt((bottom_right_x - bottom_right_center_x)**2 + 
                                            (bottom_right_y - bottom_right_center_y)**2)
                
                # Skip bubbles that are within the rounded corner areas
                if dist_top_right <= corner_radius or dist_bottom_right <= corner_radius:
                    continue
            
            filtered_contours.append(cnt)

    contours = filtered_contours

    # Create a new mask containing only the filtered contours
    filtered_mask = np.zeros_like(mask)
    cv2.drawContours(filtered_mask, filtered_contours, -1, 65535, -1) # Draw filled white contours onto the new mask

    # Draw results
    result = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    result = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)

    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        cv2.rectangle(result, (x, y), (x + w, y + h), (0, 0, 255), 2)

    return result, filtered_mask, var_img

def extract_pattern(file_name):
    # Only process files containing step 01 to step 09
    if not re.search(r'step0[1-9]', file_name):
        return None
    
    # Only select patterns with values ​​of 120, 192 or 216
    match = re.search(r'step0[1-9]_\d+NIT_[RGBW](120|192|216)', file_name)
    if match:
        return match.group(0)
    return None

def are_centers_close(bbox1, bbox2, tolerance=25):
    x1, y1, w1, h1 = bbox1
    x2, y2, w2, h2 = bbox2

    center_x1 = x1 + w1 / 2
    center_y1 = y1 + h1 / 2
    center_x2 = x2 + w2 / 2
    center_y2 = y2 + h2 / 2

    # Calculate Euclidean distance between centers
    distance = np.sqrt((center_x1 - center_x2)**2 + (center_y1 - center_y2)**2)

    # Check for bounding box overlap
    # Calculate coordinates of the corners
    left1, top1, right1, bottom1 = x1, y1, x1 + w1, y1 + h1
    left2, top2, right2, bottom2 = x2, y2, x2 + w2, y2 + h2

    # Check for overlap
    overlap_x = max(0, min(right1, right2) - max(left1, left2))
    overlap_y = max(0, min(bottom1, bottom2) - max(top1, top2))
    has_overlap = (overlap_x > 0 and overlap_y > 0)

    # Return True if centers are close ENOUGH OR there is significant overlap
    return distance <= tolerance or has_overlap

def check_for_common_bubbles(bubble_checker_thread, folder_path, file_names_in_group, pattern, 
                             mask_images_dir, mark_bubbles_dir, crop_bubbles_dir, 
                             r=18, threshold_scale=3.2):
    all_bubble_data = [] # Temporary list to store information about common bubble instances
    base_folder_name = os.path.basename(folder_path) # Get base folder name
    profile_data_list = []  # Store profile data for CSV export

    # Kiểm tra nếu không có file nào trong group
    if not file_names_in_group:
        bubble_checker_thread.update_log.emit(f"Warning: No files in group for pattern {pattern}")
        return False, None, profile_data_list  # Trả về đủ 3 giá trị

    for file_name in file_names_in_group:
        file_path = os.path.join(folder_path, file_name)

        # Using OpenCV to read image
        img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
        if img is None:
            bubble_checker_thread.update_log.emit(f"Warning: Cannot read image {file_name}")
            continue  # Tiếp tục với file tiếp theo thay vì trả về
            
        if len(img.shape) == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Extract resolution information
        img_height, img_width = img.shape[:2]
        resolution = f"{img_width}x{img_height}"
        
        result, mask, var_img = detect_bubbles(file_path, r=r, threshold_scale=threshold_scale, file_name=file_name)

        # Save mask image for each image (always)
        mask_img_path = os.path.join(mask_images_dir, f"{base_folder_name}_{file_name.replace('.tif', '_mask.png')}")
        cv2.imwrite(mask_img_path, mask)

        # Find contours - xử lý cả 2 phiên bản trả về của OpenCV
        contours_result = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        if len(contours_result) == 3:
            # OpenCV 3.x: (image, contours, hierarchy)
            _, contours, _ = contours_result
        elif len(contours_result) == 2:
            # OpenCV 4.x: (contours, hierarchy)
            contours, _ = contours_result
        else:
            contours = contours_result[0] if contours_result else []
            
        bboxes = [cv2.boundingRect(cnt) for cnt in contours]
        
        # Calculate statistics for CSV
        num_defects = len(bboxes)
        max_variance = np.max(var_img) if var_img.size > 0 else 0
        mean_variance = np.mean(var_img) if var_img.size > 0 else 0
        threshold_used = np.mean(var_img) * threshold_scale if var_img.size > 0 else 0
        
        # Format defect positions (bounding boxes) for CSV
        defect_positions = ""
        if bboxes:
            # Format as: (x,y,w,h); (x,y,w,h); ...
            bbox_strings = []
            for bbox in bboxes:
                x, y, w, h = bbox
                bbox_strings.append(f"({x},{y},{w},{h})")
            defect_positions = "; ".join(bbox_strings)
        
        # Save profile information for CSV
        profile_data_list.append({
            "Folder": base_folder_name,
            "File Name": file_name,
            "Pattern": pattern if pattern else "Unknown",
            "Resolution": resolution,
            "R Parameter": r,
            "Threshold Scale": threshold_scale,
            "Threshold Used": threshold_used,
            "Number of Defects": num_defects,
            "Max Variance": max_variance,
            "Mean Variance": mean_variance,
            "Defect Positions": defect_positions,
            "Status": "Bubble Found" if num_defects > 0 else "OK"
        })
        
        # Store original image for cropping later if a common bubble is found
        original_img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
        if original_img is not None:
            original_img_norm = cv2.normalize(original_img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            if len(original_img_norm.shape) == 3:
                original_img_norm = cv2.cvtColor(original_img_norm, cv2.COLOR_BGR2GRAY)
        else:
            original_img_norm = np.zeros((100, 100), dtype=np.uint8)  # Fallback

        all_bubble_data.append({
            "file_name": file_name,
            "original_img": original_img_norm,
            "result_img": result,
            "mask_img": mask,
            "bboxes": bboxes,
            "var_img": var_img 
        })

    if len(all_bubble_data) < 3:
        # If not enough images to compare, no common bubbles, do not save individual result images
        return False, None, profile_data_list

    common_bubbles_found_instances = [] # Temporary list to store common bubble instance information
    processed_bbox1_indices = set() # To track bbox1s that have been processed as a reference point

    # Search for common bubbles
    for i, data1 in enumerate(all_bubble_data):
        for bbox1_idx, bbox1 in enumerate(data1["bboxes"]):
            # Create a unique key for the current bbox1
            bbox1_key = (i, bbox1_idx, bbox1[0], bbox1[1], bbox1[2], bbox1[3])
            if bbox1_key in processed_bbox1_indices:
                continue # Skip if this bbox1 has already been used as the main reference for a common bubble

            common_bubble_count = 1
            matching_images_data = [data1] 
            candidate_common_bboxes = [bbox1] # List of bboxes forming this common bubble group
            # To store keys of bbox2s that matched in this iteration
            matched_bbox2_keys = set()

            for j, data2 in enumerate(all_bubble_data):
                if i == j: continue # Avoid comparing with itself
                for bbox2_idx, bbox2 in enumerate(data2["bboxes"]):
                    # Create key for bbox2
                    bbox2_key = (j, bbox2_idx, bbox2[0], bbox2[1], bbox2[2], bbox2[3])
                    
                    if are_centers_close(bbox1, bbox2, tolerance=25):
                        common_bubble_count += 1
                        matching_images_data.append(data2)
                        candidate_common_bboxes.append(bbox2)
                        # Mark bbox1 and bbox2 as processed as part of a common bubble
                        processed_bbox1_indices.add(bbox1_key)
                        matched_bbox2_keys.add(bbox2_key) # Store matched bbox2s
                        break # Only need one matching bbox in this image
            
            if common_bubble_count >= 3:
                # Add all matched bbox2s to the processed list
                # so they are not selected as bbox1 to start a new common bubble
                processed_bbox1_indices.update(matched_bbox2_keys)

                # Calculate common center for the current common bubble cluster
                all_centers_x_current_cluster = [b[0] + b[2] / 2 for b in candidate_common_bboxes]
                all_centers_y_current_cluster = [b[1] + b[3] / 2 for b in candidate_common_bboxes]

                avg_center_x_current_cluster = int(np.mean(all_centers_x_current_cluster))
                avg_center_y_current_cluster = int(np.mean(all_centers_y_current_cluster))

                # Find the position with the highest variance in the common bubble region across all matching images
                max_variance_val_current_cluster = -1
                best_center_x_current_cluster, best_center_y_current_cluster = avg_center_x_current_cluster, avg_center_y_current_cluster

                for data in matching_images_data:
                    for bbox in data["bboxes"]:
                        if are_centers_close(bbox1, bbox, tolerance=25): # Check if this bbox belongs to the same common bubble
                            x, y, w, h = bbox
                            sub_var_img = data["var_img"][y:y+h, x:x+w]
                            if sub_var_img.size > 0:
                                max_idx = np.unravel_index(np.argmax(sub_var_img, axis=None), sub_var_img.shape)
                                current_max_variance = sub_var_img[max_idx]
                                
                                if current_max_variance > max_variance_val_current_cluster:
                                    max_variance_val_current_cluster = current_max_variance
                                    best_center_x_current_cluster = x + max_idx[1]
                                    best_center_y_current_cluster = y + max_idx[0]
                
                # Define bounding box for this common bubble instance
                x_common_instance = max(0, best_center_x_current_cluster - 100)
                y_common_instance = max(0, best_center_y_current_cluster - 100)
                w_common_instance = 200 
                h_common_instance = 200 

                # Determine the sharpest image for this bubble instance based on largest MASK area among matched bboxes
                best_img_idx_for_instance = None
                best_mask_area_for_instance = -1
                for j, data2 in enumerate(all_bubble_data):
                    mask_img_j = data2["mask_img"]
                    for bbox2 in data2["bboxes"]:
                        if are_centers_close(bbox1, bbox2, tolerance=25):
                            x2, y2, w2, h2 = bbox2
                            sub_mask = mask_img_j[y2:y2+h2, x2:x2+w2]
                            # Count white pixels (mask is 0/255 or 0/65535 but we drew 65535 then converted to uint8 earlier)
                            mask_area = int(np.count_nonzero(sub_mask))
                            if mask_area > best_mask_area_for_instance:
                                best_mask_area_for_instance = mask_area
                                best_img_idx_for_instance = j

                # Store information about this common bubble instance in the temporary list
                common_bubbles_found_instances.append({
                    "bbox": (x_common_instance, y_common_instance, w_common_instance, h_common_instance),
                    "center": (best_center_x_current_cluster, best_center_y_current_cluster),
                    "best_img_idx": best_img_idx_for_instance,
                    "best_mask_area": best_mask_area_for_instance
                })

    # --- End of loop for detecting common bubble instances ---

    final_aggregated_common_bubbles = []
    # Logic to aggregate common_bubbles_found_instances if they are too close
    merge_tolerance = 30 # Threshold to merge nearby bubbles (pixels)

    for instance in common_bubbles_found_instances:
        current_bbox = instance["bbox"]
        merged = False
        for i, merged_bbox in enumerate(final_aggregated_common_bubbles):
            # Check if current_bbox is close enough to merge with merged_bbox
            if are_centers_close(current_bbox, merged_bbox, tolerance=merge_tolerance):
                # Merge bounding boxes
                mx1, my1, mw1, mh1 = merged_bbox
                ix1, iy1, iw1, ih1 = current_bbox

                new_x1 = min(mx1, ix1)
                new_y1 = min(my1, iy1)
                new_x2 = max(mx1 + mw1, ix1 + iw1)
                new_y2 = max(my1 + mh1, iy1 + ih1)

                final_aggregated_common_bubbles[i] = (new_x1, new_y1, new_x2 - new_x1, new_y2 - new_y1)
                merged = True
                break
        if not merged:
            final_aggregated_common_bubbles.append(current_bbox)

    if final_aggregated_common_bubbles:
        # Choose the base image for drawing/cropping: the one with the largest matched mask area
        selected_img_idx = 0
        selected_area = -1
        for instance in common_bubbles_found_instances:
            if instance.get("best_mask_area", -1) > selected_area and instance.get("best_img_idx") is not None:
                selected_area = instance["best_mask_area"]
                selected_img_idx = instance["best_img_idx"]

        base_original_img = all_bubble_data[selected_img_idx]["original_img"]
        img_height, img_width = base_original_img.shape[:2]

        # Create a single result image marking all common bubbles
        result_with_all_common_bubbles = cv2.cvtColor(base_original_img, cv2.COLOR_GRAY2BGR)
        
        for idx, (x, y, w, h) in enumerate(final_aggregated_common_bubbles):
            cv2.rectangle(result_with_all_common_bubbles, (x, y), (x + w, y + h), (0, 0, 255), 2)
            # Add sequence number to bounding box
            text = str(idx + 1)
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 1
            font_thickness = 2
            text_size = cv2.getTextSize(text, font, font_scale, font_thickness)[0]
            # Place number at top-left corner, outside the bounding box
            text_x = x - 5 - text_size[0] # Shift left by 5 pixels and subtract text width
            text_y = y - 5 # Shift up by 5 pixels
            # Ensure number is not cut off outside the image
            text_x = max(0, text_x)
            text_y = max(text_size[1], text_y) # Ensure text_y is at least text height to avoid being cut off at the top
            cv2.putText(result_with_all_common_bubbles, text, (text_x, text_y), font, font_scale, (0, 0, 255), font_thickness, cv2.LINE_AA)

        # Create unique file name for the aggregated result image
        aggregated_result_img_path = os.path.join(mark_bubbles_dir, f"{base_folder_name}_{pattern}_all_common_bubbles_result.png")
        cv2.imwrite(aggregated_result_img_path, result_with_all_common_bubbles)

        # Create individual cropped images for each common bubble
        individual_cropped_image_paths = []
        for idx, (x, y, w, h) in enumerate(final_aggregated_common_bubbles):
            # Add padding for each individual cropped image
            padding_individual_crop = 100 
            # Use center of bbox for cropping
            center_x = x + w // 2
            center_y = y + h // 2

            crop_x_start = max(0, center_x - padding_individual_crop)
            crop_y_start = max(0, center_y - padding_individual_crop)
            crop_x_end = min(img_width, center_x + padding_individual_crop)
            crop_y_end = min(img_height, center_y + padding_individual_crop)

            cropped_individual_img = base_original_img[crop_y_start:crop_y_end, crop_x_start:crop_x_end]
            
            individual_cropped_img_path = os.path.join(crop_bubbles_dir, f"{base_folder_name}_{pattern}_common_bubble_{idx+1}_cropped.png")
            cv2.imwrite(individual_cropped_img_path, cropped_individual_img)
            individual_cropped_image_paths.append(individual_cropped_img_path)

        bubble_checker_thread.update_log.emit(f"Found {len(final_aggregated_common_bubbles)} aggregated common bubbles for pattern {pattern} in folder {os.path.basename(folder_path)}")
        
        # Return a list of entries, each entry for an individual cropped image
        # Each entry will have the aggregated result image and the corresponding individual cropped image
        report_entries = []
        for cropped_path in individual_cropped_image_paths:
            report_entries.append({
                "result_img_path": aggregated_result_img_path,
                "cropped_img_path": cropped_path,
            })
        return True, report_entries, profile_data_list
    else:
        # If no common bubbles are found, do not save individual result images
        return False, None, profile_data_list

def generate_excel_report(bubble_checker_thread, output_dir, reports, all_profile_data):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Bubble Report"
    # Prepare Summary workbook and sheet
    # Use summary_output_folder if provided, otherwise use parent of output_dir
    output_base = bubble_checker_thread.summary_output_folder if hasattr(bubble_checker_thread, 'summary_output_folder') and bubble_checker_thread.summary_output_folder else os.path.dirname(output_dir)
    summary_path = os.path.join(output_base, "Analysis_Report.xlsx")
    if os.path.exists(summary_path):
        summary_wb = _load_wb(summary_path)
    else:
        summary_wb = Workbook()
        summary_wb.active.title = "Summary"
    if "Bubble Report" in summary_wb.sheetnames:
        summary_ws = summary_wb["Bubble Report"]
        # Clear old content by removing and recreating
        summary_wb.remove(summary_ws)
        summary_ws = summary_wb.create_sheet("Bubble Report")
    else:
        summary_ws = summary_wb.create_sheet("Bubble Report")

    # Determine the maximum number of cropped images to create dynamic column headers
    max_cropped_images = 0
    for report_entry in reports:
        if "Cropped_Images" in report_entry and report_entry["Cropped_Images"] is not None:
            max_cropped_images = max(max_cropped_images, len(report_entry["Cropped_Images"]))

    # Add headers with yellow background and bold font
    headers = ["Folder", "PTN", "Status", "Original Image with Mark"]
    for i in range(max_cropped_images):
        headers.append(f"Cropped Image {i+1}")
    sheet.append(headers)
    summary_ws.append(headers)

    header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    header_font = Font(bold=True)
    border_style = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

    for col in range(1, len(headers) + 1):
        cell = sheet.cell(row=1, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border_style
        scell = summary_ws.cell(row=1, column=col)
        scell.fill = header_fill
        scell.font = header_font
        scell.alignment = Alignment(horizontal="center", vertical="center")
        scell.border = border_style

    # Set fixed column widths
    sheet.column_dimensions['A'].width = 25  # Folder
    sheet.column_dimensions['B'].width = 20  # PTN
    sheet.column_dimensions['C'].width = 20  # Status
    sheet.column_dimensions['D'].width = 45  # Original Image with Mark
    summary_ws.column_dimensions['A'].width = 25
    summary_ws.column_dimensions['B'].width = 20
    summary_ws.column_dimensions['C'].width = 20
    summary_ws.column_dimensions['D'].width = 45

    # Scale factor for images when embedding into Excel
    scale_factor = 0.25 

    # Alternating background colors for rows with the same folder name
    colors = ["D9EAD3", "C9DAF8"]
    current_color_index = 0
    prev_folder = None

    def calc_status_height(text):
        clean_text = (text or "").strip()
        if not clean_text:
            return 20
        approx_chars_per_line = 28
        lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
        return lines * 18 + 4

    def adjust_status_cells(main_row, summary_row, status_text):
        desired_height = calc_status_height(status_text)
        for target_ws, row in ((sheet, main_row), (summary_ws, summary_row)):
            cell = target_ws.cell(row=row, column=3)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrapText=True)
            current_height = target_ws.row_dimensions[row].height if target_ws.row_dimensions[row].height is not None else 0
            if desired_height > current_height:
                target_ws.row_dimensions[row].height = desired_height

    # Separate reports into two groups: with errors and without errors
    # Display folders with errors first (on top), then folders without errors
    reports_with_errors = []
    reports_without_errors = []
    
    for report_entry in reports:
        status = report_entry.get("Status", "")
        if status == "Bubble Found":
            reports_with_errors.append(report_entry)
        else:
            reports_without_errors.append(report_entry)
    
    # Combine: errors first, then no errors
    sorted_reports = reports_with_errors + reports_without_errors
    
    for row_idx, report_entry in enumerate(sorted_reports, start=2):
        folder = report_entry.get("Folder", "-")
        ptn = report_entry.get("Pattern", "-")
        status = report_entry.get("Status", "Bubble Found")
        result_img_path = report_entry.get("Result_Image")
        cropped_images_paths = report_entry.get("Cropped_Images")

        if folder != prev_folder:
            current_color_index = (current_color_index + 1) % 2
            prev_folder = folder
        row_fill = PatternFill(start_color=colors[current_color_index], end_color=colors[current_color_index], fill_type="solid")

        row_data = [folder, ptn, status]
        sheet.append(row_data)
        current_excel_row = sheet.max_row
        summary_ws.append(row_data)
        current_summary_row = summary_ws.max_row

        for col in range(1, len(row_data) + 1):
            cell = sheet.cell(row=current_excel_row, column=col)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.fill = row_fill
            cell.border = border_style
            scell = summary_ws.cell(row=current_summary_row, column=col)
            scell.alignment = Alignment(horizontal="center", vertical="center")
            scell.fill = row_fill
            scell.border = border_style

        adjust_status_cells(current_excel_row, current_summary_row, status)

        # Insert aggregated result image into column D
        if result_img_path and os.path.exists(result_img_path):
            with Image.open(result_img_path) as img_result_pil:
                w, h = img_result_pil.size
            scaled_w = int(w * bubble_checker_thread.IMAGE_SCALE_FACTOR)
            scaled_h = int(h * bubble_checker_thread.IMAGE_SCALE_FACTOR)

            img_result = ExcelImage(result_img_path)
            img_result.width = scaled_w
            img_result.height = scaled_h
            sheet.add_image(img_result, f'D{current_excel_row}')
            img_result2 = ExcelImage(result_img_path)
            img_result2.width = scaled_w
            img_result2.height = scaled_h
            summary_ws.add_image(img_result2, f'D{current_summary_row}')

            current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
            new_row_height = int(scaled_h * 0.75) + 2
            sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
            s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
            s_new_row_height = int(scaled_h * 0.75) + 2
            summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)
            
            current_col_width = sheet.column_dimensions['D'].width if sheet.column_dimensions['D'].width is not None else 0
            new_col_width = int(scaled_w / 7) + 2
            sheet.column_dimensions['D'].width = max(current_col_width, new_col_width)
            s_current_col_width = summary_ws.column_dimensions['D'].width if summary_ws.column_dimensions['D'].width is not None else 0
            s_new_col_width = int(scaled_w / 7) + 2
            summary_ws.column_dimensions['D'].width = max(s_current_col_width, s_new_col_width)

        # Insert individual cropped images into dynamic columns starting from column E
        if cropped_images_paths:
            for i, cropped_path in enumerate(cropped_images_paths):
                current_col_idx = 4 + i
                current_col_letter = get_column_letter(current_col_idx + 1)

                if cropped_path and os.path.exists(cropped_path):
                    with Image.open(cropped_path) as img_cropped_pil:
                        crop_width, crop_height = img_cropped_pil.size
                    
                    img_cropped = ExcelImage(cropped_path)
                    max_crop_size = 200
                    crop_ratio = min(max_crop_size / crop_width, max_crop_size / crop_height)
                    img_cropped.width = int(crop_width * crop_ratio)
                    img_cropped.height = int(crop_height * crop_ratio)
                    
                    sheet.add_image(img_cropped, f'{current_col_letter}{current_excel_row}')
                    img_cropped2 = ExcelImage(cropped_path)
                    img_cropped2.width = int(crop_width * crop_ratio)
                    img_cropped2.height = int(crop_height * crop_ratio)
                    summary_ws.add_image(img_cropped2, f'{current_col_letter}{current_summary_row}')

                    current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
                    new_row_height = int(img_cropped.height * 0.75) + 2
                    sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
                    s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
                    s_new_row_height = int(img_cropped.height * 0.75) + 2
                    summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)

                    current_col_width = sheet.column_dimensions[current_col_letter].width if sheet.column_dimensions[current_col_letter].width is not None else 0
                    new_col_width = int(img_cropped.width / 7) + 2
                    sheet.column_dimensions[current_col_letter].width = max(current_col_width, new_col_width)
                    s_current_col_width = summary_ws.column_dimensions[current_col_letter].width if summary_ws.column_dimensions[current_col_letter].width is not None else 0
                    s_new_col_width = int(img_cropped.width / 7) + 2
                    summary_ws.column_dimensions[current_col_letter].width = max(s_current_col_width, s_new_col_width)

    excel_file_path = os.path.join(output_dir, "Bubble_Detection_Report.xlsx")
    workbook.save(excel_file_path)
    # Save/commit Summary workbook
    summary_wb.save(summary_path)
    
    # Create a CSV file containing profile details
    if all_profile_data:
        csv_file_path = os.path.join(output_dir, "Bubble_Profile_Details.csv")
        df = pd.DataFrame(all_profile_data)
        
        # Arrange columns for easier readability
        column_order = [
            "Folder", "File Name", "Pattern", "Resolution", "Status",
            "R Parameter", "Threshold Scale", "Threshold Used",
            "Number of Defects", "Max Variance", "Mean Variance", "Defect Positions"
        ]
        # Only retain the columns present in the DataFrame
        available_columns = [col for col in column_order if col in df.columns]
        df = df[available_columns]
        
        # Sort by Folder and File Name
        df = df.sort_values(by=["Folder", "File Name"])
        
        # Save file CSV
        df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
        bubble_checker_thread.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
        bubble_checker_thread.update_log.emit(f"Total records in CSV: {len(df)}")
    
    try:
        bubble_checker_thread.update_log.emit(f"Summary updated: {summary_path} -> 'Bubble Report'")
    except Exception:
        pass


# New class for running analysis in background thread
class BubbleCheckerThread(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)

    ANALYSIS_RESULTS_FOLDER = "Bubble_Analysis_Results"
    IMAGE_SCALE_FACTOR = 0.18 # Set constant here

    def __init__(self, root_folder, summary_output_folder=None):
        super().__init__()
        self.root_folder = root_folder
        self.summary_output_folder = summary_output_folder  # Folder for Analysis_Report.xlsx
        self.analysis_output_folder = os.path.join(self.root_folder, self.ANALYSIS_RESULTS_FOLDER)
        self.mask_images_dir = os.path.join(self.analysis_output_folder, "mask_images")
        self.mark_bubbles_dir = os.path.join(self.analysis_output_folder, "mark_bubbles")
        self.crop_bubbles_dir = os.path.join(self.analysis_output_folder, "crop_bubbles")
        
        os.makedirs(self.analysis_output_folder, exist_ok=True)
        os.makedirs(self.mask_images_dir, exist_ok=True)
        os.makedirs(self.mark_bubbles_dir, exist_ok=True)
        os.makedirs(self.crop_bubbles_dir, exist_ok=True)
        self.temp_files_to_delete = [] # Initialize list for temporary files
        self.all_profile_data = []  # Store all profile data for CSV export

    def _prepare_folder_for_analysis(self, folder_path, folder_name):
        # Get a list of TIFF files directly in the folder
        initial_image_paths = [os.path.join(folder_path, fname) 
                               for fname in os.listdir(folder_path) 
                               if fname.lower().endswith('.tif') and '_ori.tif' not in fname.lower()]

        if initial_image_paths: # If TIFF images are found directly in the folder (excluding _ori.tif)
            self.update_log.emit(f"Found {len(initial_image_paths)} TIFF images directly in {folder_name}.")
            return initial_image_paths

        # If no direct TIFF images, search subfolders and copy them to the root folder
        self.update_log.emit(f"No TIFF images found directly in {folder_name}. Searching subfolders and copying...")
        copied_image_paths = []
        for root, _, files in os.walk(folder_path):
            if root == folder_path: # Skip the root folder itself
                continue
            
            # Filter files for .tif and exclude _ori.tif
            filtered_files = [f for f in files if f.lower().endswith('.tif') and '_ori.tif' not in f.lower()]
            
            if filtered_files: # If any relevant TIFF files found in subfolder
                parent_subfolder_name = os.path.basename(root)
                self.update_log.emit(f"  Found {len(filtered_files)} TIFF images in subfolder: {parent_subfolder_name}")

                for file in filtered_files:
                    original_path = os.path.join(root, file)
                    
                    # Create new name: Parent_Subfolder_Name_Original_File_Name.tif
                    new_file_name = f"{parent_subfolder_name}_{file}"
                    destination_path = os.path.join(folder_path, new_file_name)
                    
                    shutil.copy2(original_path, destination_path)
                    copied_image_paths.append(destination_path)
                    self.temp_files_to_delete.append(destination_path) # Add to deletion list
                    self.update_log.emit(f"Copied '{os.path.basename(original_path)}' to '{new_file_name}' in {folder_name} for analysis.")

        return copied_image_paths

    def save_bubble_image(self, img_path, bubble_pos, folder_name, ptn):
        try:
            img = Image.open(img_path)
            img_array = np.array(img)

            x, y = bubble_pos
            crop_size = 50
            left = max(0, x - crop_size // 2)
            top = max(0, y - crop_size // 2)
            right = min(img_array.shape[1], x + crop_size // 2)
            bottom = min(img_array.shape[0], y + crop_size // 2)

            cropped_img = img.crop((left, top, right, bottom))
            
            if cropped_img.mode in ('I;16', 'I'):
                array = np.array(cropped_img, dtype=np.float32)
                array -= array.min()
                array /= array.max()
                array *= 255.0
                array = array.astype(np.uint8)
                cropped_img = Image.fromarray(array, mode='L')

            output_path = os.path.join(self.crop_bubbles_dir, f"{folder_name}_{ptn}_bubble_crop.jpg")
            cropped_img.save(output_path, 'JPEG', quality=95)
            self.update_log.emit(f"Cropped image saved at: {output_path}")
            return output_path
        except Exception as e:
            self.update_log.emit(f"Error saving cropped image: {str(e)}")
            return None

    def save_marked_image(self, img_path, bubble_pos, folder_name, ptn):
        try:
            img = Image.open(img_path)
            img_array = np.array(img)
            
            if img_array.dtype == np.uint16:
                array = np.array(img, dtype=np.float32)
                array -= array.min()
                array /= array.max()
                array *= 255.0
                array = array.astype(np.uint8)
                img = Image.fromarray(array, mode='L')
            
            img_rgb = img.convert('RGB')
            img_array = np.array(img_rgb)
            
            x, y = bubble_pos
            size = 30
            color = [255, 0, 0]
            
            for i in range(-size, size + 1):
                for j in range(-size, size + 1):
                    if (abs(i) >= size-3 or abs(j) >= size-3) and \
                       0 <= x + i < img_array.shape[1] and 0 <= y + j < img_array.shape[0]:
                        img_array[y + j, x + i] = color
            
            marked_img = Image.fromarray(img_array)
            
            output_path = os.path.join(self.mark_bubbles_dir, f"{folder_name}_{ptn}_marked.jpg")
            marked_img.save(output_path, 'JPEG', quality=95)
            self.update_log.emit(f"Marked image saved at: {output_path}")
            
            new_width = int(marked_img.width * self.IMAGE_SCALE_FACTOR)
            new_height = int(marked_img.height * self.IMAGE_SCALE_FACTOR)
            scaled_marked_img = marked_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            scaled_output_path = os.path.join(self.mark_bubbles_dir, f"{folder_name}_{ptn}_marked_scaled.jpg")
            scaled_marked_img.save(scaled_output_path, 'JPEG', quality=95)
            self.update_log.emit(f"Scaled marked image saved at: {scaled_output_path}")
            
            return output_path, scaled_output_path, marked_img.size
        except Exception as e:
            self.update_log.emit(f"Error saving marked image: {str(e)}")
            return None, None, None

    def run(self):
        try:
            grouped_reports = []
            # Exclude analysis results folders when exporting report
            excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
            # Get a list of subfolders in the root folder
            folders = [f for f in os.listdir(self.root_folder) 
                      if os.path.isdir(os.path.join(self.root_folder, f)) 
                      and f not in excluded_folders]
            total_folders = len(folders)

            if total_folders == 0:
                self.finished.emit([])
                return

            for idx, folder_name in enumerate(folders):
                folder_path = os.path.join(self.root_folder, folder_name)
                
                self.update_progress.emit(int((idx + 1) / total_folders * 100))
                self.update_log.emit(f"Checking folder: {folder_name}...")

                # Prepare images for analysis: copy from subfolders if necessary
                image_paths_for_analysis = self._prepare_folder_for_analysis(folder_path, folder_name)
                
                # Skip if no TIFF images are found after preparation (including filtering by PTN)
                if not image_paths_for_analysis:
                    self.update_log.emit(f"No relevant TIFF images found in folder: {folder_name} for analysis.")
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid TIFF images (requires 120/192/216)",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                grouped_files_by_pattern = {}
                for img_path in image_paths_for_analysis:
                    file_name = os.path.basename(img_path)
                    if file_name.lower().endswith(".tif"):
                        pattern = extract_pattern(file_name)
                        if pattern:
                            if pattern not in grouped_files_by_pattern:
                                grouped_files_by_pattern[pattern] = []
                            grouped_files_by_pattern[pattern].append(file_name)

                if not grouped_files_by_pattern:
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid 120/192/216 pattern found",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                for pattern, file_names_in_group in grouped_files_by_pattern.items():
                    # Xử lý trường hợp file_names_in_group rỗng
                    if not file_names_in_group:
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": pattern,
                            "Status": "No files in pattern group",
                            "Result_Image": None,
                            "Cropped_Images": []
                        })
                        continue
                    
                    try:
                        bubble_found_in_group, report_entries, profile_data_list = check_for_common_bubbles(
                            self, # Pass self as bubble_checker_thread
                            folder_path, file_names_in_group, pattern,
                            self.mask_images_dir, self.mark_bubbles_dir, self.crop_bubbles_dir
                        )
                        
                        # Save profile data
                        self.all_profile_data.extend(profile_data_list)
                        
                        if bubble_found_in_group:
                            cropped_list = []
                            if report_entries:
                                for entry in report_entries:
                                    if entry and entry.get("cropped_img_path"):
                                        cropped_list.append(entry["cropped_img_path"])
                            
                            result_image = report_entries[0]["result_img_path"] if report_entries and report_entries[0] else None
                            grouped_reports.append({
                                "Folder": folder_name,
                                "Pattern": pattern,
                                "Status": "Bubble Found",
                                "Result_Image": result_image,
                                "Cropped_Images": cropped_list
                            })
                        else:
                            grouped_reports.append({
                                "Folder": folder_name,
                                "Pattern": pattern,
                                "Status": "No bubble detected",
                                "Result_Image": None,
                                "Cropped_Images": []
                            })
                            
                    except Exception as e:
                        self.update_log.emit(f"Error processing pattern {pattern} in folder {folder_name}: {str(e)}")
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": pattern,
                            "Status": f"Error: {str(e)[:50]}...",
                            "Result_Image": None,
                            "Cropped_Images": []
                        })
            
            if grouped_reports:
                generate_excel_report(self, self.analysis_output_folder, grouped_reports, self.all_profile_data)
                self.update_log.emit("Analysis complete! Excel report and CSV file generated.")
                
                bubble_folders = list(set(report['Folder'] for report in grouped_reports if report.get("Status") == "Bubble Found"))
                self.finished.emit(bubble_folders)
            else:
                # Still create CSV if profile data is available
                if self.all_profile_data:
                    csv_file_path = os.path.join(self.analysis_output_folder, "Bubble_Profile_Details.csv")
                    df = pd.DataFrame(self.all_profile_data)
                    
                    # Arrange columns for easier readability
                    column_order = [
                        "Folder", "File Name", "Pattern", "Resolution", "Status",
                        "R Parameter", "Threshold Scale", "Threshold Used",
                        "Number of Defects", "Max Variance", "Mean Variance", "Defect Positions"
                    ]
                    # Only retain the columns present in the DataFrame
                    available_columns = [col for col in column_order if col in df.columns]
                    df = df[available_columns]
                    
                    # Sort by Folder and File Name
                    df = df.sort_values(by=["Folder", "File Name"])
                    
                    df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
                    self.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
                    self.update_log.emit(f"Total records in CSV: {len(df)}")
                
                self.update_log.emit("Analysis complete! No folders processed, but CSV file generated.")
                self.finished.emit([])

        except Exception as e:
            self.update_log.emit(f"Error: {type(e).__name__} - {str(e)}")
            self.finished.emit([])
        finally:
            # Clean up temporary copied files
            if self.temp_files_to_delete:
                self.update_log.emit("Cleaning up temporary files...")
                for temp_file in self.temp_files_to_delete:
                    if os.path.exists(temp_file):
                        try:
                            os.remove(temp_file)
                            self.update_log.emit(f"Deleted temporary file: {os.path.basename(temp_file)}")
                        except Exception as e:
                            self.update_log.emit(f"Error deleting temporary file {os.path.basename(temp_file)}: {str(e)}")
                self.temp_files_to_delete.clear()

# UI - MainWindow class
class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_app_window = parent # Store reference to the main application window
        self.setWindowTitle("Bubble Detection Tool")
        self.resize(600, 600)
        self.setWindowIcon(QIcon(":/icons/bubble.png"))
        
        self.selected_folder = None # Initialize selected_folder
        self.analysis_output_folder = None # Initialize analysis_output_folder
        
        # Set light modern theme color palette
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 247, 250))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(52, 73, 94))
        self.setPalette(palette)

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Header container with gradient background
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(75)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)

        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        # Icon in header with shadow
        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        
        # Create shadow effect for icon button with increased intensity
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))
        icon_button.setGraphicsEffect(icon_shadow)
        
        # Set icon for button with larger size
        icon = QtGui.QIcon(":/icons/bubble.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70))
        
        # Add icon button to header layout
        header_layout.addWidget(icon_button)

        # Title container
        title_container = QVBoxLayout()
        title_container.setSpacing(-2)

        title_label = QLabel("Bubble Detection Tool")
        title_label.setFont(QFont("Segoe UI", 20, QFont.Weight.Bold))
        title_label.setStyleSheet("color: white; padding: 0; margin: 0;")

        subtitle_label = QLabel("Detect bubble in TIFF images automatically")
        subtitle_label.setFont(QFont("Segoe UI", 10))
        subtitle_label.setStyleSheet("color: rgba(255, 255, 255, 0.85);")
        subtitle_label.setContentsMargins(0, -5, 0, 0)

        title_container.addWidget(title_label)
        title_container.addWidget(subtitle_label)

        header_layout.addLayout(title_container)
        header_layout.addStretch()

        main_layout.addWidget(header_container)

        # Controls container
        controls_container = QWidget()
        controls_container.setObjectName("controlsContainer")
        controls_container.setStyleSheet("""
            #controlsContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        controls_container.setGraphicsEffect(self.create_shadow_effect())

        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setSpacing(15)

        # Select folder button
        self.btn_select_folder = QPushButton("Select Folder")
        self.btn_select_folder.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_DirIcon))
        self.btn_select_folder.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_select_folder.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
        """)
        self.btn_select_folder.clicked.connect(self.select_folder)
        controls_layout.addWidget(self.btn_select_folder)

        # Separator
        separator = QLabel("|")
        separator.setStyleSheet("color: #3498db; font-size: 20px;")
        separator.setFixedHeight(40)
        controls_layout.addWidget(separator)

        # Start button
        self.btn_start = QPushButton("Start Checking")
        self.btn_start.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MediaPlay))
        self.btn_start.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_start.setEnabled(False)
        self.btn_start.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """)
        self.btn_start.clicked.connect(self.start_checking)
        controls_layout.addWidget(self.btn_start)

        # Separator
        separator2 = QLabel("|")
        separator2.setStyleSheet("color: #3498db; font-size: 20px;")
        separator2.setFixedHeight(40)
        controls_layout.addWidget(separator2)

        # Open Excel button
        self.btn_open_excel = QPushButton("Open Report")
        self.btn_open_excel.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_FileIcon))
        self.btn_open_excel.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_open_excel.setEnabled(False)
        self.btn_open_excel.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """)
        self.btn_open_excel.clicked.connect(self.open_excel_report)
        controls_layout.addWidget(self.btn_open_excel)

        main_layout.addWidget(controls_container)

        # Progress container
        progress_container = QWidget()
        progress_container.setObjectName("progressContainer")
        progress_container.setStyleSheet("""
            #progressContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        progress_container.setGraphicsEffect(self.create_shadow_effect())

        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setSpacing(8)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 1px;
                text-align: center;
                height: 25px;
            }
            QProgressBar::chunk {
                background: #3498db;
                border-radius: 7px;
            }
        """)
        progress_layout.addWidget(self.progress_bar)

        main_layout.addWidget(progress_container)

        # Log container
        log_container = QWidget()
        log_container.setObjectName("logContainer")
        log_container.setStyleSheet("""
            #logContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        log_container.setGraphicsEffect(self.create_shadow_effect())

        log_layout = QVBoxLayout(log_container)
        log_layout.setSpacing(8)

        # Log header with icon
        log_header = QWidget()
        log_header_layout = QHBoxLayout(log_header)
        log_header_layout.setContentsMargins(0, 0, 0, 10)

        log_icon = QPushButton()
        log_icon.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MessageBoxInformation))
        log_icon.setIconSize(QSize(25, 25))
        log_icon.setFixedSize(25, 25)
        log_icon.setStyleSheet("""
            QPushButton {
                background: #f0f2f5;
                border: none;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        log_header_layout.addWidget(log_icon)

        log_label = QLabel("Processing Log:")
        log_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #2c3e50;")
        log_header_layout.addWidget(log_label)
        log_header_layout.addStretch()

        log_layout.addWidget(log_header)

        # Log text area
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        log_layout.addWidget(self.log_text)

        main_layout.addWidget(log_container)

        # Author info
        author_label = QLabel("Created by nguyenvanvuong1")
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        author_label.setStyleSheet("color: #3498db; padding: 0; margin: 0;")
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 25))
        return shadow

    def select_folder(self):
        self.selected_folder = QFileDialog.getExistingDirectory(
            self, 
            "Select Folder Containing TIFF Images",
            "",
            QFileDialog.Option.ShowDirsOnly
        )
        if self.selected_folder:
            self.log_text.append(f"Selected folder: {self.selected_folder}")
            self.analysis_output_folder = os.path.join(self.selected_folder, BubbleCheckerThread.ANALYSIS_RESULTS_FOLDER)
            os.makedirs(self.analysis_output_folder, exist_ok=True) # Create result folder as soon as folder is selected
            self.btn_start.setEnabled(True)
            self.btn_open_excel.setEnabled(False)
            self.statusBar().showMessage(f"Selected folder: {os.path.basename(self.selected_folder)}")

    def start_checking(self):
        if self.selected_folder:
            self.checker = BubbleCheckerThread(self.selected_folder)
            self.checker.update_progress.connect(self.update_progress)
            self.checker.update_log.connect(self.update_log)
            self.checker.finished.connect(self.on_finished)
            self.checker.start()

            self.btn_start.setEnabled(False)
            self.btn_open_excel.setEnabled(False)
            self.statusBar().showMessage("Checking for bubbles...")

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_log(self, message):
        self.log_text.append(message)

    def on_finished(self, bubble_folders):
        self.btn_start.setEnabled(True)
        self.btn_open_excel.setEnabled(True)
        self.statusBar().showMessage("Check completed")

        if bubble_folders:
            unique_folders = list(set(bubble_folders))
            message = "Folders with bubbles:\n"
            message += "\n".join(f"- {folder}" for folder in unique_folders)
            
            msg = QMessageBox(self)
            msg.setWindowTitle("Check Results")
            msg.setText(message)
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: #f5f5f5;
                }
                QMessageBox QLabel {
                    font-size: 14px;
                    color: #333;
                    padding: 10px;
                }
                QPushButton {
                    background-color: #2196F3;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 12px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #1976D2;
                }
            """)
            msg.exec()
        else:
            msg = QMessageBox(self)
            msg.setWindowTitle("Check Results")
            msg.setText("No bubbles found")
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: #f5f5f5;
                }
                QMessageBox QLabel {
                    font-size: 14px;
                    color: #333;
                    padding: 10px;
                }
                QPushButton {
                    background-color: #2196F3;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 12px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #1976D2;
                }
            """)
            msg.exec()

    def open_excel_report(self):
        try:
            excel_path = os.path.join(self.analysis_output_folder, 'Bubble_Detection_Report.xlsx')
            if os.path.exists(excel_path):
                os.startfile(excel_path)
            else:
                QMessageBox.warning(self, "Error", "Excel report file not found!")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not open Excel file: {str(e)}")


    def closeEvent(self, event):
        if self.main_app_window: # Check if main window reference exists
            self.main_app_window.setEnabled(True) # Re-enable the main window
            self.main_app_window.remove_blur_effect() # Remove blur effect from main window
        super().closeEvent(event)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
