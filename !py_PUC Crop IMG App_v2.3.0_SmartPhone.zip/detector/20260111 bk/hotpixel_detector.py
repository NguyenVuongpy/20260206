import os
import sys
import math
import numpy as np
from PIL import Image
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout,QWidget , QPushButton, QLabel, QTextEdit, QFileDialog, QWidget, QProgressBar, QMessageBox, QHBoxLayout, QFrame, QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal,QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from scipy import ndimage
import rc.icons
from PyQt6 import QtCore, QtGui, QtWidgets
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

class HotpixelChecker(QThread):
    # Signals to update progress and log
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)  # Changed to emit list of hotpixel folders

    # Scale factor for images in Excel
    IMAGE_SCALE_FACTOR = 0.18
    
    # Folder for analysis results
    ANALYSIS_RESULTS_FOLDER = "Hotpixel_Analysis_Results"

    def __init__(self, root_folder):
        super().__init__()
        self.root_folder = root_folder
        self.analysis_output_folder = os.path.join(self.root_folder, self.ANALYSIS_RESULTS_FOLDER)
        os.makedirs(self.analysis_output_folder, exist_ok=True) # Ensure this folder exists
        self.temp_files_to_delete = [] # List of temporary files to delete
        # self.temp_analysis_folder = os.path.join(self.analysis_output_folder, "temp_analysis") # Temporary folder to save copied images
        # os.makedirs(self.temp_analysis_folder, exist_ok=True)

    def _prepare_folder_for_analysis(self, folder_path, folder_name):
        # Get a list of TIFF files directly in the folder
        initial_image_paths = [os.path.join(folder_path, fname) for fname in os.listdir(folder_path) if fname.endswith('.tif') and '_ori.tif' not in fname]

        if initial_image_paths:  # If there are TIFF images directly in the folder (excluding _ori.tif)
            return initial_image_paths

        # If there are no direct TIFF images, search in subfolders and copy them to the root folder
        self.update_log.emit(f"No TIFF images found directly in {folder_name}. Searching subfolders and copying...")
        copied_image_paths = []
        for root, _, files in os.walk(folder_path):
            # Skip the root folder itself if it's the parent of the subfolders
            if root == folder_path:
                continue

            for file in files:
                if file.endswith('.tif') and '_ori.tif' not in file: # Ignore files containing '_ori.tif'
                    original_path = os.path.join(root, file)
                    
                    # Get the name of the direct subfolder containing the original image
                    parent_folder_name = os.path.basename(root)

                    # Extract the part of the folder name before the first underscore '_'
                    # For example, from "A4VT5700AM02AE7_20250828015218", it will extract "A4VT5700AM02AE7"
                    base_folder_name = parent_folder_name.split('_')[0]
                    
                    # Create the new name: Base_Folder_Name_Original_File_Name.tif
                    new_file_name = f"{base_folder_name}_{file}"
                    destination_path = os.path.join(folder_path, new_file_name)
                    
                    shutil.copy2(original_path, destination_path)
                    copied_image_paths.append(destination_path)
                    self.temp_files_to_delete.append(destination_path)  # Add to the deletion list
                    self.update_log.emit(f"Copied '{os.path.basename(original_path)}' to '{new_file_name}' in {folder_name} for analysis.")

        return copied_image_paths

    def run(self):
        try:
            results = []
            hotpixel_folders = []  # List to store folders with hotpixels
            # Exclude analysis results folders when exporting report
            excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
            folders = [f for f in os.listdir(self.root_folder) 
                      if os.path.isdir(os.path.join(self.root_folder, f)) 
                      and f not in excluded_folders]
            total_folders = len(folders)

            if total_folders == 0:
                self.finished.emit([])
                return

            # Define position tolerance (how many pixels apart to consider as same hotpixel)
            POSITION_TOLERANCE = 8  # pixels in x or y direction

            def are_positions_similar(pos1, pos2):
                """Check if two positions are within tolerance of each other"""
                return abs(pos1[0] - pos2[0]) <= POSITION_TOLERANCE and abs(pos1[1] - pos2[1]) <= POSITION_TOLERANCE

            def find_similar_positions(target_pos, positions):
                """Find all positions similar to target_pos in the list"""
                return [pos for pos in positions if are_positions_similar(target_pos, pos)]

            for idx, folder_name in enumerate(folders):
                folder_path = os.path.join(self.root_folder, folder_name)
                
                # Prepare images for analysis if no TIFFs directly in the folder
                image_paths_for_analysis = self._prepare_folder_for_analysis(folder_path, folder_name)

                # Skip if no TIFF images are found after preparation
                if not image_paths_for_analysis:
                    self.update_log.emit(f"No TIFF images found in folder: {folder_name}")
                    results.append({
                        'Folder': folder_name,
                        'PTN': None,
                        'Hotpixel Coordinates': None,
                        'Cropped Image Path': None,
                        'Source Image Path': None,
                        'Hotpixel Intensity': None,
                        'Hotpixel Size': None,
                        'Status': 'No valid TIFF images available for checking'
                    })
                    continue

                # Update progress
                self.update_progress.emit(int((idx + 1) / total_folders * 100))
                self.update_log.emit(f"Checking folder: {folder_name}...")

                # Group images by full pattern (step_NIT_PTN)
                image_groups = {}
                for img_path in image_paths_for_analysis:
                    img_name = os.path.basename(img_path)
                    
                    # Ignore files that contain "120" in their name
                    if '120' in img_name:
                        self.update_log.emit(f"Skipping file containing '120': {img_name}")
                        continue
                    
                    # Improved laboratory extraction logic - only accepts steps 01 to 09
                    parts = img_name.split('_')
                    # Look for the pattern that starts with "step" followed by digits từ 01 đến 09
                    step_index = -1
                    target_steps = [f'step{i:02d}' for i in range(1, 10)]  # step01 to step09

                    for i, part in enumerate(parts):
                        if part in target_steps:  # Only steps 01 to 09 will be accepted
                            step_index = i
                            break

                    if step_index != -1 and len(parts) - step_index >= 3:
                        # Take the step part and the next two parts
                        ptn_full = '_'.join(parts[step_index:step_index+3])
                        # Remove any file extension
                        ptn_full = ptn_full.split('.')[0]
                        
                        if ptn_full not in image_groups:
                            image_groups[ptn_full] = []
                        image_groups[ptn_full].append(img_path)
                    else:
                        # Skip if no suitable pattern is found or if there are not enough parts
                        self.update_log.emit(f"Skipping file due to invalid step pattern (only step01-step09 accepted): {img_name}")
                        continue
                
                # Check if there are any valid image groups after filtering
                if not image_groups:
                    # No valid images found (all were skipped due to invalid pattern)
                    results.append({
                        'Folder': folder_name,
                        'PTN': None,
                        'Hotpixel Coordinates': None,
                        'Cropped Image Path': None,
                        'Source Image Path': None,
                        'Hotpixel Intensity': None,
                        'Hotpixel Size': None,
                        'Status': 'No valid TIFF images available for checking'
                    })
                    continue
                
                # Track if any PTN group was actually processed (has at least 2 images)
                has_valid_ptn_groups = False
                
                # Check for hotpixels in each PTN group
                for ptn, img_paths_in_group in image_groups.items():
                    if len(img_paths_in_group) < 2:
                        continue  # Skip if there are less than 2 images in the group
                    
                    has_valid_ptn_groups = True

                    # Find hotpixel positions and intensities in each image
                    hotpixel_data = []  # Store (position, intensity, size, img_path) for each hotpixel
                    
                    for img_path in img_paths_in_group:
                        img = np.array(Image.open(img_path))
                        
                        # Find the maximum intensity value
                        max_intensity = np.max(img)
                        
                        # Find all pixels with the maximum intensity
                        hotpixel_mask = img == max_intensity
                        
                        # Check for isolated high-intensity pixels
                        labeled_mask, num_features = ndimage.label(hotpixel_mask)
                        
                        for feature_idx in range(1, num_features + 1):
                            # Get positions of this feature
                            feature_positions = np.argwhere(labeled_mask == feature_idx)
                            
                            # If feature is small (1-3 pixels), consider it a potential hotpixel
                            if len(feature_positions) <= 3:
                                # For each small feature, take its first position
                                # Convert from (row, column) to (x, y) = (column, row)
                                y, x = feature_positions[0]
                                hotpixel_data.append({
                                    'position': (x, y),
                                    'intensity': max_intensity,
                                    'size': len(feature_positions),
                                    'img_path': img_path
                                })
                                break  # Take only the first small bright feature
                    
                    # Check for clusters of similar positions
                    if len(hotpixel_data) >= 3:
                        # Find position clusters
                        position_clusters = []
                        data_clusters = []
                        remaining_data = hotpixel_data.copy()
                        
                        while remaining_data:
                            current_data = remaining_data[0]
                            current_pos = current_data['position']
                            
                            # Find similar positions
                            similar_indices = [i for i, data in enumerate(remaining_data) 
                                             if are_positions_similar(current_pos, data['position'])]
                            
                            # Extract the cluster
                            cluster_data = [remaining_data[i] for i in similar_indices]
                            cluster_positions = [data['position'] for data in cluster_data]
                            
                            position_clusters.append(cluster_positions)
                            data_clusters.append(cluster_data)
                            
                            # Remove clustered data from remaining
                            for i in sorted(similar_indices, reverse=True):
                                del remaining_data[i]
                        
                        # Check each cluster
                        for cluster_idx, cluster in enumerate(position_clusters):
                            if len(cluster) >= 3:  # At least 3 similar positions
                                # Calculate average position
                                avg_x = int(round(sum(p[0] for p in cluster) / len(cluster)))
                                avg_y = int(round(sum(p[1] for p in cluster) / len(cluster)))
                                avg_pos = (avg_x, avg_y)
                                
                                # Find the strongest hotpixel in this cluster
                                cluster_data = data_clusters[cluster_idx]
                                
                                # Calculate a "hotpixel strength" score (intensity * size)
                                hotpixel_scores = [data['intensity'] * data['size'] for data in cluster_data]
                                
                                # Find the index of the strongest hotpixel
                                strongest_idx = np.argmax(hotpixel_scores)
                                strongest_data = cluster_data[strongest_idx]
                                
                                # Get the image path and hotpixel info from the strongest hotpixel
                                strongest_img_path = strongest_data['img_path']
                                strongest_intensity = strongest_data['intensity']
                                strongest_size = strongest_data['size']
                                
                                # Save the result with the strongest image
                                crop_path = self.save_hotpixel_image(strongest_img_path, avg_pos, folder_name, ptn)
                                results.append({
                                    'Folder': folder_name,
                                    'PTN': ptn,
                                    'Hotpixel Coordinates': avg_pos,
                                    'Original Positions': cluster,
                                    'Cropped Image Path': crop_path,
                                    'Source Image Path': strongest_img_path,  # Store path to source image
                                    'Hotpixel Intensity': strongest_intensity,
                                    'Hotpixel Size': strongest_size,
                                    'Status': 'Hotpixel Found'
                                })
                                if folder_name not in hotpixel_folders:
                                    hotpixel_folders.append(folder_name)
                                self.update_log.emit(f"Hotpixel found in PTN: {ptn} around position {avg_pos} (intensity: {strongest_intensity}, size: {strongest_size})")
                
                # If no hotpixel is found in the folder, but we had valid PTN groups
                if not any(result['Folder'] == folder_name for result in results):
                    if has_valid_ptn_groups:
                        # Had valid images but no hotpixel found
                        results.append({
                            'Folder': folder_name,
                            'PTN': None,
                            'Hotpixel Coordinates': None,
                            'Cropped Image Path': None,
                            'Source Image Path': None,
                            'Hotpixel Intensity': None,
                            'Hotpixel Size': None,
                            'Status': 'No Hotpixel'
                        })
                    else:
                        # No valid PTN groups (all groups had less than 2 images)
                        results.append({
                            'Folder': folder_name,
                            'PTN': None,
                            'Hotpixel Coordinates': None,
                            'Cropped Image Path': None,
                            'Source Image Path': None,
                            'Hotpixel Intensity': None,
                            'Hotpixel Size': None,
                            'Status': 'No valid TIFF images available for checking'
                        })

            # Export results to Excel with images
            self.export_to_excel(results)
            self.update_progress.emit(100) 
            self.finished.emit(hotpixel_folders)
        except Exception as e:
            self.update_log.emit(f"Error: {str(e)}")
            self.finished.emit([])

    def save_hotpixel_image(self, img_path, hotpixel_pos, folder_name, ptn):
        try:
            img = Image.open(img_path)
            img_array = np.array(img)

            # Define a crop area around the hotpixel
            x, y = hotpixel_pos
            crop_size = 50  # Crop a 50x50 area around the hotpixel
            left = max(0, x - crop_size // 2)
            top = max(0, y - crop_size // 2)
            right = min(img_array.shape[1], x + crop_size // 2)
            bottom = min(img_array.shape[0], y + crop_size // 2)

            # Crop the image
            cropped_img = img.crop((left, top, right, bottom))
            
            # Convert 16-bit TIF to 8-bit JPG with better quality
            if cropped_img.mode in ('I;16', 'I'):
                array = np.array(cropped_img, dtype=np.float32)
                array -= array.min()
                array /= array.max()
                array *= 255.0
                array = array.astype(np.uint8)
                cropped_img = Image.fromarray(array, mode='L')

            # Save the image as JPG with higher quality
            output_folder = os.path.join(self.analysis_output_folder, "hotpixel_crops")
            os.makedirs(output_folder, exist_ok=True)
            output_path = os.path.join(output_folder, f"{folder_name}_{ptn}_hotpixel_crop.jpg")
            cropped_img.save(output_path, 'JPEG', quality=95)  # Increase quality to 95
            self.update_log.emit(f"Cropped image saved at: {output_path}")
            return output_path
        except Exception as e:
            self.update_log.emit(f"Error saving cropped image: {str(e)}")
            return None

    def save_marked_image(self, img_path, hotpixel_pos, folder_name, ptn):
        try:
            img = Image.open(img_path)
            img_array = np.array(img)
            
            # Convert 16-bit TIF to 8-bit JPG first with better quality
            if img_array.dtype == np.uint16:
                array = np.array(img, dtype=np.float32)
                array -= array.min()
                array /= array.max()
                array *= 255.0
                array = array.astype(np.uint8)
                img = Image.fromarray(array, mode='L')
            
            # Convert to RGB for drawing
            img_rgb = img.convert('RGB')
            img_array = np.array(img_rgb)
            
            # Draw a red rectangle around the hotpixel (more visible)
            x, y = hotpixel_pos
            size = 30  # Increase size for better visibility
            color = [255, 0, 0]  # Red color
            
            # Draw a thicker rectangle
            for i in range(-size, size + 1):
                for j in range(-size, size + 1):
                    if (abs(i) >= size-3 or abs(j) >= size-3) and \
                       0 <= x + i < img_array.shape[1] and 0 <= y + j < img_array.shape[0]:
                        img_array[y + j, x + i] = color
            
            # Convert back to PIL image
            marked_img = Image.fromarray(img_array)
            
            # Save the original marked image with higher quality
            output_folder = os.path.join(self.analysis_output_folder, "hotpixel_marked")
            os.makedirs(output_folder, exist_ok=True)
            output_path = os.path.join(output_folder, f"{folder_name}_{ptn}_marked.jpg")
            marked_img.save(output_path, 'JPEG', quality=95)
            self.update_log.emit(f"Marked image saved at: {output_path}")
            
            # Create a scaled version of Excel
            new_width = int(marked_img.width * self.IMAGE_SCALE_FACTOR)
            new_height = int(marked_img.height * self.IMAGE_SCALE_FACTOR)
            scaled_marked_img = marked_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            scaled_output_path = os.path.join(output_folder, f"{folder_name}_{ptn}_marked_scaled.jpg")
            scaled_marked_img.save(scaled_output_path, 'JPEG', quality=95) # Lưu ảnh scaled với chất lượng cao
            self.update_log.emit(f"Scaled marked image saved at: {scaled_output_path}")
            self.temp_files_to_delete.append(scaled_output_path) # Thêm vào danh sách xóa
            
            return output_path, scaled_output_path, marked_img.size # Trả về cả đường dẫn ảnh gốc và ảnh scaled, cùng với kích thước gốc
        except Exception as e:
            self.update_log.emit(f"Error saving marked image: {str(e)}")
            return None, None, None # Trả về None cho tất cả các giá trị

    def export_to_excel(self, results):  
        try:  
            # Create workbook và worksheet
            wb = Workbook()  
            ws = wb.active  
            ws.title = "Hotpixel Report"  
            # Prepare Summary workbook and sheet
            summary_path = os.path.join(self.root_folder, "Analysis_Report.xlsx")
            if os.path.exists(summary_path):
                summary_wb = _load_wb(summary_path)
            else:
                summary_wb = Workbook()
                summary_wb.active.title = "Summary"
            if "Hotpixel Report" in summary_wb.sheetnames:
                s_ws = summary_wb["Hotpixel Report"]
                summary_wb.remove(s_ws)
                s_ws = summary_wb.create_sheet("Hotpixel Report")
            else:
                s_ws = summary_wb.create_sheet("Hotpixel Report")

            # Add a title with a yellow background and bold text
            headers = ["Folder", "PTN", "Hotpixel Coordinates", "Intensity", "Size", "Status", "Original Image with Mark", "Cropped Image"]  
            ws.append(headers)
            s_ws.append(headers)

            header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")  # Nền vàng
            header_font = Font(bold=True)  
            border_style = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

            for col in range(1, len(headers) + 1):  
                cell = ws.cell(row=1, column=col)
                cell.fill = header_fill  
                cell.font = header_font  
                cell.alignment = Alignment(horizontal="center", vertical="center")  
                cell.border = border_style  
                scell = s_ws.cell(row=1, column=col)
                scell.fill = header_fill
                scell.font = header_font
                scell.alignment = Alignment(horizontal="center", vertical="center")
                scell.border = border_style

            # Set column width
            ws.column_dimensions['A'].width = 25
            ws.column_dimensions['B'].width = 20
            ws.column_dimensions['C'].width = 20
            ws.column_dimensions['D'].width = 15
            ws.column_dimensions['E'].width = 10
            ws.column_dimensions['F'].width = 20
            ws.column_dimensions['G'].width = 45
            ws.column_dimensions['H'].width = 22
            s_ws.column_dimensions['A'].width = 25
            s_ws.column_dimensions['B'].width = 20
            s_ws.column_dimensions['C'].width = 20
            s_ws.column_dimensions['D'].width = 15
            s_ws.column_dimensions['E'].width = 10
            s_ws.column_dimensions['F'].width = 20
            s_ws.column_dimensions['G'].width = 45
            s_ws.column_dimensions['H'].width = 22

            # Alternating background colors for rows with the same folder name.
            folder_colors = {}  # Save a color for each folder.
            colors = ["D9EAD3", "C9DAF8"]  # Light green and light blue
            current_color_index = 0  
            prev_folder = None

            def calc_status_height(text):
                clean_text = (text or "").strip()
                if not clean_text:
                    return 18
                approx_chars_per_line = 28
                lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
                return lines * 18 + 4

            def adjust_status_cells(main_row, summary_row, status_text):
                desired_height = calc_status_height(status_text)
                for target_ws, row in ((ws, main_row), (s_ws, summary_row)):
                    cell = target_ws.cell(row=row, column=6)
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrapText=True)
                    current_height = target_ws.row_dimensions[row].height if target_ws.row_dimensions[row].height is not None else 0
                    if desired_height > current_height:
                        target_ws.row_dimensions[row].height = desired_height

            # Separate results into two groups: with errors and without errors
            # Display folders with errors first (on top), then folders without errors
            results_with_errors = []
            results_without_errors = []
            
            for result in results:
                status = result.get('Status', 'Unknown')
                if status == 'Hotpixel Found':
                    results_with_errors.append(result)
                else:
                    results_without_errors.append(result)
            
            # Combine: errors first, then no errors
            sorted_results = results_with_errors + results_without_errors
            
            # Add data and images - top up the folders containing errors
            for result in sorted_results:  
                folder = result.get('Folder', '-')
                ptn = result.get('PTN', '-') or '-'
                coordinates = result.get('Hotpixel Coordinates')
                intensity = result.get('Hotpixel Intensity')
                size = result.get('Hotpixel Size')
                status = result.get('Status', 'Unknown')
                crop_path = result.get('Cropped Image Path')
                source_img_path = result.get('Source Image Path')

                # If the folder changes color, change its color
                if folder != prev_folder:  
                    current_color_index = (current_color_index + 1) % 2  
                    prev_folder = folder  

                row_fill = PatternFill(start_color=colors[current_color_index], end_color=colors[current_color_index], fill_type="solid")

                # Adding data to a new row - handling None values
                row = [
                    folder, 
                    ptn, 
                    str(coordinates) if coordinates else '-', 
                    intensity if intensity is not None else '-', 
                    size if size is not None else '-', 
                    status
                ]  
                ws.append(row)  
                row_idx = ws.max_row
                s_ws.append(row)
                s_row_idx = s_ws.max_row

                # Formatting for each cell in the row
                for col in range(1, len(row) + 1):  
                    cell = ws.cell(row=row_idx, column=col)
                    cell.alignment = Alignment(horizontal="center", vertical="center")  
                    cell.fill = row_fill  # Paint the background  
                    cell.border = border_style  # Add borders
                    scell = s_ws.cell(row=s_row_idx, column=col)
                    scell.alignment = Alignment(horizontal="center", vertical="center")
                    scell.fill = row_fill
                    scell.border = border_style

                adjust_status_cells(row_idx, s_row_idx, status)

                # Insert the original image with a watermark if hotpixels are available
                if coordinates and status == 'Hotpixel Found' and source_img_path and os.path.exists(source_img_path):
                    original_marked_path, scaled_marked_path, original_size = self.save_marked_image(source_img_path, coordinates, folder, ptn)
                    if scaled_marked_path:
                        img = ExcelImage(scaled_marked_path)
                        
                        # Get the actual size of the scaled image from the file
                        with Image.open(scaled_marked_path) as scaled_pil_img:
                            scaled_width = scaled_pil_img.width
                            scaled_height = scaled_pil_img.height
                        
                        img.width = scaled_width
                        img.height = scaled_height
                        
                        ws.add_image(img, f'G{row_idx}')
                        img2 = ExcelImage(scaled_marked_path)
                        img2.width = scaled_width
                        img2.height = scaled_height
                        s_ws.add_image(img2, f'G{s_row_idx}')
                        
                        # Adjust row height (unit: points, 1 pixel ~ 0.75 point)
                        # Add a 5-point buffer.
                        current_row_height = ws.row_dimensions[row_idx].height if ws.row_dimensions[row_idx].height is not None else 0
                        new_row_height = int(scaled_height * 0.75) + 2
                        ws.row_dimensions[row_idx].height = max(current_row_height, new_row_height)
                        s_current_row_height = s_ws.row_dimensions[s_row_idx].height if s_ws.row_dimensions[s_row_idx].height is not None else 0
                        s_ws.row_dimensions[s_row_idx].height = max(s_current_row_height, new_row_height)
                        
                        # Adjust column width (unit: column units, 1 unit ~ 7 pixels)
                        # Add a 2-column buffer
                        current_col_width = ws.column_dimensions['G'].width if ws.column_dimensions['G'].width is not None else 0
                        new_col_width = int(scaled_width / 7) + 2
                        ws.column_dimensions['G'].width = max(current_col_width, new_col_width)
                        s_current_col_width = s_ws.column_dimensions['G'].width if s_ws.column_dimensions['G'].width is not None else 0
                        s_ws.column_dimensions['G'].width = max(s_current_col_width, new_col_width)
                        
                # Insert cropped images if available
                if crop_path and os.path.exists(crop_path):  
                    img = ExcelImage(crop_path)  
                    # Get the original image size of the cropped image
                    with Image.open(crop_path) as cropped_original_img:
                        crop_width, crop_height = cropped_original_img.size
                    # Calculate the ratio to maintain the original aspect ratio
                    max_crop_size = 140  # Maximum size for cropped images
                    crop_ratio = min(max_crop_size / crop_width, max_crop_size / crop_height)
                    img.width = int(crop_width * crop_ratio)
                    img.height = int(crop_height * crop_ratio)
                    ws.add_image(img, f'H{row_idx}')  
                    img_s = ExcelImage(crop_path)
                    img_s.width = img.width
                    img_s.height = img.height
                    s_ws.add_image(img_s, f'H{s_row_idx}')
                    
                    # Adjust row height (unit: points, 1 pixel ~ 0.75 point)
                    # Add a 5-point buffer
                    current_row_height = ws.row_dimensions[row_idx].height if ws.row_dimensions[row_idx].height is not None else 0
                    new_row_height = int(img.height * 0.75) + 2
                    ws.row_dimensions[row_idx].height = max(current_row_height, new_row_height)
                    s_current_row_height2 = s_ws.row_dimensions[s_row_idx].height if s_ws.row_dimensions[s_row_idx].height is not None else 0
                    s_ws.row_dimensions[s_row_idx].height = max(s_current_row_height2, new_row_height)
                    
                    # Adjust column width (unit: column units, 1 unit ~ 7 pixels)
                    # Add a 2-column buffer
                    current_col_width = ws.column_dimensions['H'].width if ws.column_dimensions['H'].width is not None else 0
                    new_col_width = int(img.width / 7) + 2
                    ws.column_dimensions['H'].width = max(current_col_width, new_col_width)
                    s_current_col_width2 = s_ws.column_dimensions['H'].width if s_ws.column_dimensions['H'].width is not None else 0
                    s_ws.column_dimensions['H'].width = max(s_current_col_width2, new_col_width)

            # Save file Excel  
            output_excel_path = os.path.join(self.analysis_output_folder, 'hotpixel_report.xlsx')
            self.update_log.emit(f"Attempting to save Excel report to: {output_excel_path}")
            wb.save(output_excel_path)
            # Save/commit Summary workbook
            summary_wb.save(summary_path)
            try:
                self.update_log.emit(f"Summary updated: {summary_path} -> 'Hotpixel Report'")
            except Exception:
                pass
            self.update_log.emit(f"Excel report saved at: {output_excel_path}")  
            # Summary workbook is updated directly above; no post-copy needed
            
            # Delete temporary files after saving Excel
            for temp_file in self.temp_files_to_delete:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
                    self.update_log.emit(f"Deleted temporary file: {temp_file}")
            self.temp_files_to_delete.clear() # Delete the list after deleting the file

        except Exception as e:  
            self.update_log.emit(f"Error exporting to Excel: {type(e).__name__} - {str(e)}") # Update error log


class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_app_window = parent # Store reference to the main application window
        self.setWindowTitle("Hotpixel Detection Tool")
        self.resize(600, 600)
        self.setWindowIcon(QIcon(":/icons/hotpixel.png"))
        
        self.selected_folder = None # Initialize selected_folder
        self.analysis_output_folder = None # Initialize analysis_output_folder
        
        # Set light modern theme color palette
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 247, 250))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(52, 73, 94))
        self.setPalette(palette)

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Header container with gradient background
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(75)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)

        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        # Icon in header with shadow
        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        
        # Create a shadow effect for the button icon with a darker shade
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))  # Increase the intensity of the shadow
        icon_button.setGraphicsEffect(icon_shadow)
        
        # Set the button icon to a larger size
        icon = QtGui.QIcon(":/icons/hotpixel.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70))  # Increase icon size
        
        # Add a button icon to the header layout
        header_layout.addWidget(icon_button)

        # Title container
        title_container = QVBoxLayout()
        title_container.setSpacing(-2)

        title_label = QLabel("Hotpixel Detection Tool")
        title_label.setFont(QFont("Segoe UI", 20, QFont.Weight.Bold))
        title_label.setStyleSheet("color: white; padding: 0; margin: 0;")

        subtitle_label = QLabel("Detect hotpixel in TIFF images automatically")
        subtitle_label.setFont(QFont("Segoe UI", 10))
        subtitle_label.setStyleSheet("color: rgba(255, 255, 255, 0.85);")
        subtitle_label.setContentsMargins(0, -5, 0, 0)

        title_container.addWidget(title_label)
        title_container.addWidget(subtitle_label)

        header_layout.addLayout(title_container)
        header_layout.addStretch()

        main_layout.addWidget(header_container)

        # Controls container
        controls_container = QWidget()
        controls_container.setObjectName("controlsContainer")
        controls_container.setStyleSheet("""
            #controlsContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        controls_container.setGraphicsEffect(self.create_shadow_effect())

        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setSpacing(15)

        # Select folder button
        self.btn_select_folder = QPushButton("Select Folder")
        self.btn_select_folder.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_DirIcon))
        self.btn_select_folder.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_select_folder.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
        """)
        self.btn_select_folder.clicked.connect(self.select_folder)
        controls_layout.addWidget(self.btn_select_folder)

        # Separator
        separator = QLabel("|")
        separator.setStyleSheet("color: #3498db; font-size: 20px;")
        separator.setFixedHeight(40)
        controls_layout.addWidget(separator)

        # Start button
        self.btn_start = QPushButton("Start Checking")
        self.btn_start.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MediaPlay))
        self.btn_start.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_start.setEnabled(False)
        self.btn_start.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """)
        self.btn_start.clicked.connect(self.start_checking)
        controls_layout.addWidget(self.btn_start)

        # Separator
        separator2 = QLabel("|")
        separator2.setStyleSheet("color: #3498db; font-size: 20px;")
        separator2.setFixedHeight(40)
        controls_layout.addWidget(separator2)

        # Open Excel button
        self.btn_open_excel = QPushButton("Open Report")
        self.btn_open_excel.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_FileIcon))
        self.btn_open_excel.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_open_excel.setEnabled(False)
        self.btn_open_excel.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """)
        self.btn_open_excel.clicked.connect(self.open_excel_report)
        controls_layout.addWidget(self.btn_open_excel)

        main_layout.addWidget(controls_container)

        # Progress container
        progress_container = QWidget()
        progress_container.setObjectName("progressContainer")
        progress_container.setStyleSheet("""
            #progressContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        progress_container.setGraphicsEffect(self.create_shadow_effect())

        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setSpacing(8)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 1px;
                text-align: center;
                height: 25px;
            }
            QProgressBar::chunk {
                background: #3498db;
                border-radius: 7px;
            }
        """)
        progress_layout.addWidget(self.progress_bar)

        main_layout.addWidget(progress_container)

        # Log container
        log_container = QWidget()
        log_container.setObjectName("logContainer")
        log_container.setStyleSheet("""
            #logContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        log_container.setGraphicsEffect(self.create_shadow_effect())

        log_layout = QVBoxLayout(log_container)
        log_layout.setSpacing(8)

        # Log header with icon
        log_header = QWidget()
        log_header_layout = QHBoxLayout(log_header)
        log_header_layout.setContentsMargins(0, 0, 0, 10)

        log_icon = QPushButton()
        log_icon.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MessageBoxInformation))
        log_icon.setIconSize(QSize(25, 25))
        log_icon.setFixedSize(25, 25)
        log_icon.setStyleSheet("""
            QPushButton {
                background: #f0f2f5;
                border: none;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        log_header_layout.addWidget(log_icon)

        log_label = QLabel("Processing Log:")
        log_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #2c3e50;")
        log_header_layout.addWidget(log_label)
        log_header_layout.addStretch()

        log_layout.addWidget(log_header)

        # Log text area
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        log_layout.addWidget(self.log_text)

        main_layout.addWidget(log_container)

        # Author info
        author_label = QLabel("Created by nguyenvanvuong1")
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        author_label.setStyleSheet("color: #3498db; padding: 0; margin: 0;")
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 25))
        return shadow

    def select_folder(self):
        self.selected_folder = QFileDialog.getExistingDirectory(
            self, 
            "Select Folder Containing TIFF Images",
            "",
            QFileDialog.Option.ShowDirsOnly
        )
        if self.selected_folder:
            self.log_text.append(f"Selected folder: {self.selected_folder}")
            self.analysis_output_folder = os.path.join(self.selected_folder, HotpixelChecker.ANALYSIS_RESULTS_FOLDER)
            os.makedirs(self.analysis_output_folder, exist_ok=True) # Tạo thư mục kết quả ngay khi chọn folder
            self.btn_start.setEnabled(True)
            self.btn_open_excel.setEnabled(False)
            self.statusBar().showMessage(f"Selected folder: {os.path.basename(self.selected_folder)}")

    def start_checking(self):
        if self.selected_folder:
            self.checker = HotpixelChecker(self.selected_folder)
            self.checker.update_progress.connect(self.update_progress)
            self.checker.update_log.connect(self.update_log)
            self.checker.finished.connect(self.on_finished)
            self.checker.start()

            self.btn_start.setEnabled(False)
            self.btn_open_excel.setEnabled(False)
            self.statusBar().showMessage("Checking for hotpixels...")

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_log(self, message):
        self.log_text.append(message)

    def on_finished(self, hotpixel_folders):
        self.btn_start.setEnabled(True)
        self.btn_open_excel.setEnabled(True)
        self.statusBar().showMessage("Check completed")

        if hotpixel_folders:
            # Get a list of unique folders containing hotpixels.
            unique_folders = list(set(hotpixel_folders))
            message = "Folders with hotpixels:\n"
            message += "\n".join(f"- {folder}" for folder in unique_folders)
            
            # Create a message box with style
            msg = QMessageBox(self)
            msg.setWindowTitle("Check Results")
            msg.setText(message)
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: #f5f5f5;
                }
                QMessageBox QLabel {
                    font-size: 14px;
                    color: #333;
                    padding: 10px;
                }
                QPushButton {
                    background-color: #2196F3;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 12px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #1976D2;
                }
            """)
            msg.exec()
        else:
            msg = QMessageBox(self)
            msg.setWindowTitle("Check Results")
            msg.setText("No hotpixels found")
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: #f5f5f5;
                }
                QMessageBox QLabel {
                    font-size: 14px;
                    color: #333;
                    padding: 10px;
                }
                QPushButton {
                    background-color: #2196F3;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 12px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #1976D2;
                }
            """)
            msg.exec()

    def open_excel_report(self):
        try:
            excel_path = os.path.join(self.analysis_output_folder, 'hotpixel_report.xlsx')
            if os.path.exists(excel_path):
                os.startfile(excel_path)
            else:
                QMessageBox.warning(self, "Error", "Excel report file not found!")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not open Excel file: {str(e)}")

    def closeEvent(self, event):
        if self.main_app_window: # Check if main window reference exists
            self.main_app_window.setEnabled(True) # Re-enable the main window
            self.main_app_window.remove_blur_effect() # Remove blur effect from main window
        super().closeEvent(event)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())