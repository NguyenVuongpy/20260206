import os
import sys
from datetime import datetime
import pandas as pd
import numpy as np
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect, QComboBox, QDialog, QTableWidget, QTableWidgetItem,
    QScrollArea, QGridLayout
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
from openpyxl import Workbook
from openpyxl.styles import Alignment, PatternFill, Border, Side, Font, Color
from openpyxl.utils import get_column_letter
from openpyxl import load_workbook
# Optional: Excel COM for perfect sheet copy (keeps images & formatting)
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None
from PyQt6 import QtCore, QtGui, QtWidgets
import rc.icons
from log_functions import script_dir

# Import detectors and CCD model helpers
from detector.hotpixel_detector import HotpixelChecker
from detector.bubble_detector import BubbleCheckerThread
from detector.lshape_detector import LShapeCheckerThread
from detector.ccd_detector import CCDChecker, load_model_config, save_model_config, ModelManagementDialog
from detector.hiaa_detector import HiaaCheckerThread
from detector.dust_detector import DustCheckerThread
from detector.topedge_detector import Top_EdgeCheckerThread

class CombinedDetectorController(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    update_detector_status = pyqtSignal(str, str)  # Signal: detector_name, status
    finished = pyqtSignal(dict)

    def __init__(self, root_folder, ccd_model_name, ccd_models_config):
        super().__init__()
        self.root_folder = root_folder
        self.ccd_model_name = ccd_model_name
        self.ccd_models_config = ccd_models_config

        self.results = {
            'hotpixel': [],
            'ccd': [],
            'bubble': [],
            'lshape': [],
            'hiaa': [],
            'dust': [],
            'topedge': []            
        }

        self.detectors = [
            {"name": "HotPixel", "key": "hotpixel", "thread": None, "status": "pending"},
            {"name": "CCD", "key": "ccd", "thread": None, "status": "pending"},
            {"name": "Bubble", "key": "bubble", "thread": None, "status": "pending"},
            {"name": "LShape", "key": "lshape", "thread": None, "status": "pending"},
            {"name": "Dust", "key": "dust", "thread": None, "status": "pending"},
            {"name": "Hiaa", "key": "hiaa", "thread": None, "status": "pending"},
            {"name": "TopEdge", "key": "topedge", "thread": None, "status": "pending"}
        ]

        # Output folder at script location:
        #   PUC_Crop_Image_Result\<YYYYmmddHHMMSS>_Check_Result\Analysis_Report.xlsx
        #   PUC_Crop_Image_Result\<YYYYmmddHHMMSS>_Check_Result\Summary_log.csv
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        self.output_root_dir = os.path.join(script_dir, "PUC_Crop_Image_Result")
        os.makedirs(self.output_root_dir, exist_ok=True)
        self.run_output_folder = os.path.join(self.output_root_dir, f"{timestamp}_Check_Result")
        os.makedirs(self.run_output_folder, exist_ok=True)

        self.combined_path = os.path.join(self.run_output_folder, "Analysis_Report.xlsx")
        self.summary_csv_path = os.path.join(self.run_output_folder, "Summary_log.csv")
        self._summary_initialized = False

    def _forward_log(self, prefix):
        def _inner(message):
            self.update_log.emit(f"[{prefix}] {message}")
        return _inner

    def run(self):
        try:
            # Ensure combined workbook exists
            self._ensure_combined_workbook()
            
            # Update all detectors to "pending" first
            for det in self.detectors:
                det["status"] = "pending"
                self.update_detector_status.emit(det["name"], "pending")
            
            self.update_log.emit("Starting all detectors...")
            
            # HotPixel
            current_det = self.detectors[0]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            hot_thread = HotpixelChecker(self.root_folder, summary_output_folder=self.run_output_folder)
            hot_thread.update_log.connect(self._forward_log(current_det['name']))
            hot_thread.update_progress.connect(lambda p: self.update_progress.emit(int(p/7)))
            result_container = []
            hot_thread.finished.connect(lambda folders: result_container.extend(folders))
            hot_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['hotpixel'] = list(set(result_container))
            self._append_summary_row(current_det['name'], self.results['hotpixel'])

            # CCD
            current_det = self.detectors[1]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            ccd_thread = CCDChecker(self.root_folder, self.ccd_model_name, self.ccd_models_config, summary_output_folder=self.run_output_folder)
            ccd_thread.update_log.connect(self._forward_log(current_det['name']))
            ccd_thread.update_progress.connect(lambda p: self.update_progress.emit(int(100/7 + p/7)))
            ccd_result_container = []
            ccd_thread.finished.connect(lambda folders: ccd_result_container.extend(folders))
            ccd_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['ccd'] = list(set(ccd_result_container))
            self._append_summary_row(current_det['name'], self.results['ccd'])

            # Bubble
            current_det = self.detectors[2]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            bubble_thread = BubbleCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            bubble_thread.update_log.connect(self._forward_log(current_det['name']))
            bubble_thread.update_progress.connect(lambda p: self.update_progress.emit(int(200/7 + p/7)))
            bubble_result_container = []
            bubble_thread.finished.connect(lambda folders: bubble_result_container.extend(folders))
            bubble_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['bubble'] = list(set(bubble_result_container))
            self._append_summary_row(current_det['name'], self.results['bubble'])

            # LShape
            current_det = self.detectors[3]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            lshape_thread = LShapeCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            lshape_thread.update_log.connect(self._forward_log(current_det['name']))
            lshape_thread.update_progress.connect(lambda p: self.update_progress.emit(int(300/7 + p/7)))
            lshape_result_container = []
            lshape_thread.finished.connect(lambda folders: lshape_result_container.extend(folders))
            lshape_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['lshape'] = list(set(lshape_result_container))
            self._append_summary_row(current_det['name'], self.results['lshape'])

            # Dust
            current_det = self.detectors[4]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            dust_thread = DustCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            dust_thread.update_log.connect(self._forward_log(current_det['name']))
            dust_thread.update_progress.connect(lambda p: self.update_progress.emit(int(400/7 + p/7)))
            dust_result_container = []
            dust_thread.finished.connect(lambda folders: dust_result_container.extend(folders))
            dust_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['dust'] = list(set(dust_result_container))
            self._append_summary_row(current_det['name'], self.results['dust'])

            # Hiaa
            current_det = self.detectors[5]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            hiaa_thread = HiaaCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            hiaa_thread.update_log.connect(self._forward_log(current_det['name']))
            hiaa_thread.update_progress.connect(lambda p: self.update_progress.emit(int(500/7 + p/7)))
            hiaa_result_container = []
            hiaa_thread.finished.connect(lambda folders: hiaa_result_container.extend(folders))
            hiaa_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['hiaa'] = list(set(hiaa_result_container))
            self._append_summary_row(current_det['name'], self.results['hiaa'])

            # TopEdge
            current_det = self.detectors[6]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            topedge_thread = Top_EdgeCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            topedge_thread.update_log.connect(self._forward_log(current_det['name']))
            topedge_thread.update_progress.connect(lambda p: self.update_progress.emit(int(600/7 + p/7)))
            topedge_result_container = []
            topedge_thread.finished.connect(lambda folders: topedge_result_container.extend(folders))
            topedge_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['topedge'] = list(set(topedge_result_container))
            self._append_summary_row(current_det['name'], self.results['topedge'])

            # Áp dụng heatmap cho cột "Total Camera"
            self._apply_heatmap_to_total_camera()

            # Tạo file CSV tổng hợp
            self._create_combined_csv()

            self.update_progress.emit(100)
            self.update_log.emit("✅ All checks completed!")
            self.finished.emit(self.results)
        except Exception as e:
            self.update_log.emit(f"Error: {type(e).__name__} - {str(e)}")
            self.finished.emit(self.results)

    def _ensure_combined_workbook(self):
        if self._summary_initialized and os.path.exists(self.combined_path):
            return
        from openpyxl import load_workbook as _lw
        if os.path.exists(self.combined_path):
            wb = _lw(self.combined_path)
            if "Summary" in wb.sheetnames:
                ws = wb["Summary"]
                ws.delete_rows(1, ws.max_row)
            else:
                ws = wb.create_sheet("Summary")
        else:
            wb = Workbook()
            ws = wb.active
            ws.title = "Summary"
        
        headers = ["Detector", "Total Camera", "Camera List"]
        header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        header_font = Font(size=12, bold=True, color="333333")
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=1, column=col_idx)
            c.alignment = Alignment(horizontal='center', vertical='center')
            c.fill = header_fill
            c.font = header_font
            c.border = thin_border
            ws.column_dimensions[get_column_letter(col_idx)].width = 30 if col_idx != 3 else 60
        wb.save(self.combined_path)
        self._summary_initialized = True

    def _get_checked_cameras_count(self):
        """Lấy số lượng camera thực sự đã được check"""
        if not os.path.exists(self.root_folder):
            return 0
        
        # Lấy tất cả các folder trong root_folder
        all_camera_folders = [f for f in os.listdir(self.root_folder) 
                             if os.path.isdir(os.path.join(self.root_folder, f))]
        
        # Loại bỏ các folder kết quả phân tích
        excluded_folders = ["Hotpixel_Analysis_Results", "CCD_Analysis_Results", 
                           "Dust_Analysis_Results", "Hiaa_Analysis_Results",
                           "Bubble_Analysis_Results", "LShape_Analysis_Results",
                           "Top_Edge_Analysis_Results"]
        
        camera_folders = [f for f in all_camera_folders if f not in excluded_folders]
        
        # Đếm số camera có ít nhất một file ảnh để check
        checked_cameras = 0
        for camera in camera_folders:
            camera_path = os.path.join(self.root_folder, camera)
            # Kiểm tra xem có file ảnh nào trong folder không
            image_extensions = ['.tif', '.tiff', '.png', '.jpg', '.jpeg', '.bmp']
            has_images = any(f.lower().endswith(tuple(image_extensions)) 
                           for f in os.listdir(camera_path) if os.path.isfile(os.path.join(camera_path, f)))
            if has_images:
                checked_cameras += 1
        
        return checked_cameras, len(camera_folders)

    def _append_summary_row(self, name, folders):
        try:
            from openpyxl import load_workbook as _lw
            wb = _lw(self.combined_path)
            ws = wb["Summary"] if "Summary" in wb.sheetnames else wb.active
            thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
            
            folders_sorted = sorted(set(folders)) if folders else []
            error_count = len(folders_sorted)
            
            # Lấy số camera đã check và tổng số camera
            checked_cameras, total_cameras = self._get_checked_cameras_count()
            
            # Hiển thị: "số camera lỗi / số camera đã check (tổng số camera)"
            if checked_cameras > 0:
                if total_cameras > checked_cameras:
                    camera_count_text = f"{error_count} / {checked_cameras} ({total_cameras})"
                else:
                    camera_count_text = f"{error_count} / {checked_cameras}"
            else:
                camera_count_text = f"{error_count} / 0 ({total_cameras})"
            
            # Tạo danh sách camera với định dạng rõ ràng
            camera_list_text = "\n".join(folders_sorted)
            
            ws.append([name, camera_count_text, camera_list_text])
            row = ws.max_row
            
            # Áp dụng định dạng cho tất cả các cell trong hàng
            for col in range(1, 4):
                cell = ws.cell(row=row, column=col)
                cell.alignment = Alignment(horizontal='left', vertical='top', wrapText=True)
                cell.border = thin_border
            
            # Đặc biệt, căn giữa cho cột "Total Camera"
            total_camera_cell = ws.cell(row=row, column=2)
            total_camera_cell.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
            
            wb.save(self.combined_path)
            self.update_log.emit(f"Summary updated: {name} -> {camera_count_text}")
        except Exception as e:
            self.update_log.emit(f"Warning: could not update Summary for {name}: {e}")

    def _apply_heatmap_to_total_camera(self):
        """Áp dụng heatmap cho cột Total Camera dựa trên tỷ lệ lỗi"""
        try:
            from openpyxl import load_workbook
            from openpyxl.styles import PatternFill
            
            wb = load_workbook(self.combined_path)
            ws = wb["Summary"] if "Summary" in wb.sheetnames else wb.active
            
            # Lấy dữ liệu từ cột B (Total Camera)
            max_row = ws.max_row
            if max_row <= 1:  # Chỉ có header
                wb.save(self.combined_path)
                return
            
            # Tính toán tỷ lệ lỗi cao nhất để chuẩn hóa màu
            error_rates = []
            for row in range(2, max_row + 1):
                cell_value = ws.cell(row=row, column=2).value
                if cell_value:
                    # Parse giá trị: "error_count / checked_cameras (total_cameras)"
                    parts = str(cell_value).split('/')
                    if len(parts) >= 2:
                        try:
                            error_count = int(parts[0].strip())
                            # Lấy số checked_cameras từ phần thứ 2
                            checked_part = parts[1].strip()
                            # Xử lý trường hợp có (total_cameras)
                            if '(' in checked_part:
                                checked_part = checked_part.split('(')[0].strip()
                            checked_cameras = int(checked_part) if checked_part else 0
                            
                            if checked_cameras > 0:
                                error_rate = error_count / checked_cameras
                                error_rates.append(error_rate)
                        except (ValueError, IndexError):
                            pass
            
            if not error_rates:
                wb.save(self.combined_path)
                return
            
            max_error_rate = max(error_rates)
            
            # Áp dụng màu gradient từ xanh (0%) đến đỏ (100%)
            for row in range(2, max_row + 1):
                cell = ws.cell(row=row, column=2)
                cell_value = cell.value
                
                if cell_value:
                    try:
                        # Parse giá trị
                        parts = str(cell_value).split('/')
                        if len(parts) >= 2:
                            error_count = int(parts[0].strip())
                            checked_part = parts[1].strip()
                            if '(' in checked_part:
                                checked_part = checked_part.split('(')[0].strip()
                            checked_cameras = int(checked_part) if checked_part else 0
                            
                            if checked_cameras > 0:
                                error_rate = error_count / checked_cameras
                                
                                # Tính toán màu gradient từ xanh (0%) đến đỏ (100%)
                                if error_rate <= 0:
                                    # Không có lỗi: màu xanh lá cây nhạt
                                    color = "C6EFCE"  # Xanh lá cây nhạt
                                elif error_rate >= max_error_rate:
                                    # Lỗi nhiều nhất: màu đỏ đậm
                                    color = "FFC7CE"  # Đỏ nhạt
                                else:
                                    # Tính toán gradient
                                    ratio = error_rate / max_error_rate if max_error_rate > 0 else 0
                                    # Từ xanh (0, 255, 0) đến đỏ (255, 0, 0) qua vàng (255, 255, 0)
                                    if ratio <= 0.5:
                                        # Xanh -> Vàng
                                        r = int(255 * (ratio * 2))
                                        g = 255
                                        b = 0
                                    else:
                                        # Vàng -> Đỏ
                                        r = 255
                                        g = int(255 * (2 - ratio * 2))
                                        b = 0
                                    
                                    # Chuyển đổi sang hex
                                    color = f"{r:02X}{g:02X}{b:02X}"
                                    # Lấy màu tương phản tốt hơn từ palette Excel
                                    if ratio < 0.2:
                                        color = "F8F9E6"  # Vàng rất nhạt
                                    elif ratio < 0.4:
                                        color = "FFF2CC"  # Vàng nhạt
                                    elif ratio < 0.6:
                                        color = "FFE699"  # Vàng
                                    elif ratio < 0.8:
                                        color = "FFD966"  # Cam nhạt
                                    else:
                                        color = "FFC7CE"  # Đỏ nhạt
                                
                                # Áp dụng fill
                                cell.fill = PatternFill(start_color=color, end_color=color, fill_type="solid")
                                
                                # Thêm font đậm cho giá trị cao
                                if error_rate > 0.5:
                                    from openpyxl.styles import Font
                                    cell.font = Font(bold=True)
                    except (ValueError, IndexError, ZeroDivisionError):
                        # Nếu không parse được, giữ nguyên
                        pass
            
            wb.save(self.combined_path)
            self.update_log.emit("✅ Heatmap applied to Total Camera column")
            
        except Exception as e:
            self.update_log.emit(f"Warning: could not apply heatmap: {e}")

    def _convert_numpy_types(self, value):
        """Convert numpy types to Python native types"""
        if value is None:
            return value
        
        # Check if value is a numpy scalar
        if isinstance(value, np.generic):
            # Convert numpy scalar to Python native type
            return value.item()
        
        # Check if value is a numpy array
        if isinstance(value, np.ndarray):
            # Convert numpy array to list
            return value.tolist()
        
        # For lists/tuples containing numpy types
        if isinstance(value, (list, tuple)):
            return [self._convert_numpy_types(item) for item in value]
        
        # For strings that might contain numpy representations
        if isinstance(value, str):
            # Clean up np.int64 strings
            import re
            # Pattern to match np.int64(123) or np.float64(123.45)
            pattern = r'np\.(?:int|float)\d+\(([^)]+)\)'
            if re.search(pattern, value):
                # Replace np.int64(123) with 123
                value = re.sub(r'np\.(?:int|float)\d+\(([^)]+)\)', r'\1', value)
        
        return value

    def _format_special_values(self, value):
        """Format special values like tuples, lists, numpy arrays for CSV output"""
        if value is None:
            return ''
        
        # Convert numpy types first
        value = self._convert_numpy_types(value)
        
        # Handle tuples
        if isinstance(value, tuple):
            # Format each element as string
            return f"({', '.join(str(item) for item in value)})"
        
        # Handle lists
        if isinstance(value, list):
            # Format each element as string
            return f"[{', '.join(str(item) for item in value)}]"
        
        # Handle strings that might still contain numpy representations
        if isinstance(value, str):
            # Further clean up if needed
            import re
            # Clean up any remaining numpy representations
            value = re.sub(r'np\.(?:int|float)\d+\(([^)]+)\)', r'\1', value)
        
        return value

    def _convert_bbox_to_coordinate_pairs(self, defect_positions_str):
        """
        Convert bounding box format (x, y, w, h) to (x1, y1)-(x2, y2) format.
        Input: "(594,581,269,41); (594,582,269,41)"  # (x, y, width, height)
        Output: "(594,581)-(863,622); (594,582)-(863,623)"  # (x1, y1)-(x2, y2)
        """
        import re
        if not defect_positions_str:
            return ""
        
        # Clean the string and split by semicolon
        defect_positions_str = str(defect_positions_str).strip()
        if defect_positions_str == "" or defect_positions_str.lower() == "nan":
            return ""
        
        # Parse all bounding boxes
        pattern = r"\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)"
        matches = re.findall(pattern, defect_positions_str)
        
        formatted_boxes = []
        for match in matches:
            try:
                x, y, w, h = map(int, match)
                x2 = x + w
                y2 = y + h
                formatted_boxes.append(f"({x},{y})-({x2},{y2})")
            except ValueError:
                # If parsing fails, keep original
                formatted_boxes.append(f"({','.join(match)})")
        
        return "; ".join(formatted_boxes) if formatted_boxes else defect_positions_str

    def _clean_dataframe_columns(self, df):
        """Clean all columns in DataFrame to remove numpy types"""
        if df.empty:
            return df
        
        # Apply conversion to all cells
        for col in df.columns:
            df[col] = df[col].apply(self._convert_numpy_types)
        
        return df

    def _safe_str(self, v):
        try:
            if v is None:
                return ""
            if isinstance(v, float) and pd.isna(v):
                return ""
            return str(v)
        except Exception:
            return ""

    def _normalize_result(self, value):
        """Normalize Result column values to 'NG' (error) or 'OK' (no error) or 'No Check'"""
        if value is None:
            return "OK"
        
        value_str = str(value).strip()
        value_lower = value_str.lower()
        
        # If already normalized, return as is
        if value_lower == "ng":
            return "NG"
        if value_lower == "ok":
            return "OK"
        if value_lower == "no check":
            return "No Check"
        
        # Check for error indicators
        error_indicators = [
            "hotpixel found", "ccd detected", "bubble found", 
            "lshape defect found", "dust found", "hiaa found", 
            "top_edge found", "topedge found", "yes", "true", 
            "detected", "found", "error", "defect"
        ]
        
        # Check if value indicates an error
        for indicator in error_indicators:
            if indicator in value_lower:
                return "NG"
        
        # Default to OK if value is "No", "False", or empty
        if value_lower in ["no", "false", ""]:
            return "OK"
        
        # If we can't determine, default to OK
        return "OK"

    def _extract_pid_sn(self, file_name: str) -> str:
        """Extract PID from file name by taking characters before first '_'."""
        s = self._safe_str(file_name)
        if not s:
            return ""
        return s.split("_", 1)[0]

    def _parse_positions_from_row(self, detector_name: str, row) -> list[tuple[float, float]]:
        """
        Extract positions used to compare 'same location' across files.
        """
        import re

        positions: list[tuple[float, float]] = []

        if detector_name == "Hotpixel":
            s = self._safe_str(row.get("Hotpixel Position", ""))
            m = re.search(r"\(\s*(\d+)\s*,\s*(\d+)\s*\)", s)
            if m:
                positions.append((float(m.group(1)), float(m.group(2))))
            return positions

        if detector_name in {"Bubble", "Dust", "LShape"}:
            s = self._safe_str(row.get("Defect Positions", ""))
            for m in re.finditer(r"\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)", s):
                x, y, w, h = map(float, m.groups())
                # Calculate center point
                positions.append((x + w / 2.0, y + h / 2.0))
            return positions

        if detector_name == "CCD":
            s = self._safe_str(row.get("Error Positions", ""))
            for m in re.finditer(
                r"\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*-\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)",
                s,
            ):
                x1, y1, x2, y2 = map(float, m.groups())
                positions.append(((x1 + x2) / 2.0, (y1 + y2) / 2.0))
            return positions

        return positions

    def _filter_df_require_common_positions(self, detector_name: str, df: pd.DataFrame) -> pd.DataFrame:
        """
        Return ALL data without filtering by common positions.
        """
        # Simply return the DataFrame as-is (no filtering)
        return df.copy()

    def _create_combined_csv(self):
        """Create combined CSV file with all defect data grouped by image file"""
        try:
            self.update_log.emit("Creating combined CSV file...")
            
            # Define CSV files to read (try both subfolder and root folder locations)
            csv_locations = [
                {
                    'Hotpixel': os.path.join(self.root_folder, "Hotpixel_Analysis_Results", "Hotpixel_Profile_Details.csv"),
                    'CCD': os.path.join(self.root_folder, "CCD_Analysis_Results", "CCD_Profile_Details.csv"),
                    'Bubble': os.path.join(self.root_folder, "Bubble_Analysis_Results", "Bubble_Profile_Details.csv"),
                    'LShape': os.path.join(self.root_folder, "LShape_Analysis_Results", "LShape_Profile_Details.csv"),
                    'Dust': os.path.join(self.root_folder, "Dust_Analysis_Results", "Dust_Profile_Details.csv"),
                    'Hiaa': os.path.join(self.root_folder, "Hiaa_Analysis_Results", "Hiaa_Profile_Details.csv"),
                    'TopEdge': os.path.join(self.root_folder, "Top_Edge_Analysis_Results", "Top_Edge_Profile_Details.csv")
                },
                {
                    'Hotpixel': os.path.join(self.root_folder, "Hotpixel_Profile_Details.csv"),
                    'CCD': os.path.join(self.root_folder, "CCD_Profile_Details.csv"),
                    'Bubble': os.path.join(self.root_folder, "Bubble_Profile_Details.csv"),
                    'LShape': os.path.join(self.root_folder, "LShape_Profile_Details.csv"),
                    'Dust': os.path.join(self.root_folder, "Dust_Profile_Details.csv"),
                    'Hiaa': os.path.join(self.root_folder, "Hiaa_Profile_Details.csv"),
                    'TopEdge': os.path.join(self.root_folder, "Top_Edge_Profile_Details.csv")
                }
            ]
            
            # Dictionary to store data grouped by (camera, PID, pattern)
            # Key: (camera, pid, pattern)
            combined_data = {}
            
            # Process each detector's CSV file
            for detector_name in ['Hotpixel', 'CCD', 'Bubble', 'LShape', 'Dust', 'Hiaa', 'TopEdge']:
                csv_path = None
                # Try all possible locations
                for location_set in csv_locations:
                    if detector_name in location_set and os.path.exists(location_set[detector_name]):
                        csv_path = location_set[detector_name]
                        break
                
                if csv_path and os.path.exists(csv_path):
                    try:
                        df = pd.read_csv(csv_path, encoding='utf-8-sig')
                        if not df.empty:
                            self.update_log.emit(f"Processing {detector_name}: {len(df)} records")

                            # Clean numpy types from the dataframe
                            df = self._clean_dataframe_columns(df)
                            
                            # Special pre-computation for Hotpixel
                            hotpixel_cluster_map = None
                            if detector_name == "Hotpixel":
                                try:
                                    import re
                                    from collections import defaultdict

                                    # Must match detector/hotpixel_detector.py
                                    HOTPIXEL_POSITION_TOLERANCE = 8  # pixels in x or y direction

                                    def _parse_hotpixel_pos(pos_str: str):
                                        """
                                        Parse "(x, y)" from Hotpixel_Profile_Details.csv.
                                        Returns (x:int, y:int) or None.
                                        """
                                        s = self._safe_str(pos_str).strip()
                                        if not s or s.lower() in {"none", "nan"}:
                                            return None
                                        m = re.search(r"\(\s*(\d+)\s*,\s*(\d+)\s*\)", s)
                                        if not m:
                                            return None
                                        return int(m.group(1)), int(m.group(2))

                                    def _is_hotpixel_found(row_dict) -> bool:
                                        # hotpixel_detector.py writes "Hotpixel Found" column as Yes/No
                                        hp_found = self._safe_str(row_dict.get("Hotpixel Found", "")).strip().lower()
                                        if hp_found in {"yes", "y", "true", "1"}:
                                            return True
                                        # Fallback: Status contains "Hotpixel Found"
                                        status = self._safe_str(row_dict.get("Status", "")).strip().lower()
                                        return "hotpixel found" in status

                                    # Build positions per (Folder, Pattern)
                                    # Keep File Name and Max Intensity so we can write them into Summary_log.csv
                                    grouped = defaultdict(list)  # (folder, pattern) -> list[dict]
                                    for _idx, _row in df.iterrows():
                                        folder_val = self._safe_str(_row.get("Folder", "")).strip()
                                        pattern_val = self._safe_str(_row.get("Pattern", "")).strip()
                                        file_name_val = self._safe_str(_row.get("File Name", "")).strip()
                                        pos = _parse_hotpixel_pos(_row.get("Hotpixel Position", ""))
                                        if not folder_val or not pattern_val or not file_name_val or pos is None:
                                            continue
                                        if not _is_hotpixel_found(_row):
                                            continue
                                        grouped[(folder_val, pattern_val)].append(
                                            {
                                                "Folder": folder_val,
                                                "Pattern": pattern_val,
                                                "File_Name": file_name_val,
                                                "X": pos[0],
                                                "Y": pos[1],
                                                "Pos_Str": f"({pos[0]}, {pos[1]})",
                                                "Max_Intensity": self._safe_str(_row.get("Max Intensity", "")).strip(),
                                            }
                                        )

                                    # Cluster by tolerance, require >= 3 unique images (File Name)
                                    # Map each (Folder, Pattern, File_Name) -> cluster info (avg pos + file list)
                                    hotpixel_cluster_map = {}
                                    for (folder_val, pattern_val), items in grouped.items():
                                        processed = set()
                                        for i, p1 in enumerate(items):
                                            if i in processed:
                                                continue
                                            cluster_indices = [i]
                                            unique_files = {p1["File_Name"]}

                                            for j, p2 in enumerate(items[i + 1 :], start=i + 1):
                                                if j in processed:
                                                    continue
                                                if (
                                                    abs(p1["X"] - p2["X"]) <= HOTPIXEL_POSITION_TOLERANCE
                                                    and abs(p1["Y"] - p2["Y"]) <= HOTPIXEL_POSITION_TOLERANCE
                                                ):
                                                    cluster_indices.append(j)
                                                    unique_files.add(p2["File_Name"])
                                                    processed.add(j)

                                            if len(unique_files) >= 3:
                                                cluster_items = [items[k] for k in cluster_indices]
                                                avg_x = int(round(sum(ci["X"] for ci in cluster_items) / len(cluster_items)))
                                                avg_y = int(round(sum(ci["Y"] for ci in cluster_items) / len(cluster_items)))
                                                avg_pos_str = f"({avg_x}, {avg_y})"

                                                # Use strongest / max intensity in cluster for Summary_log.csv
                                                intensities = []
                                                for ci in cluster_items:
                                                    try:
                                                        intensities.append(int(float(ci.get("Max_Intensity", ""))))
                                                    except Exception:
                                                        continue
                                                cluster_max_intensity = str(max(intensities)) if intensities else ""

                                                # Keep map format consistent with other detectors: "(x, y)"
                                                map_str = avg_pos_str

                                                for ci in cluster_items:
                                                    key = (folder_val, pattern_val, ci["File_Name"])
                                                    # If a file somehow belongs to multiple clusters, keep unique strings
                                                    existing = hotpixel_cluster_map.get(key)
                                                    if existing:
                                                        if map_str and map_str not in existing["map_str"].split("; "):
                                                            existing["map_str"] = (existing["map_str"] + "; " + map_str) if existing["map_str"] else map_str
                                                        if cluster_max_intensity and cluster_max_intensity not in existing["intensity"].split("; "):
                                                            existing["intensity"] = (
                                                                (existing["intensity"] + "; " + cluster_max_intensity)
                                                                if existing["intensity"]
                                                                else cluster_max_intensity
                                                            )
                                                    else:
                                                        hotpixel_cluster_map[key] = {
                                                            "map_str": map_str or "",
                                                            "intensity": cluster_max_intensity,
                                                        }

                                            processed.add(i)
                                except Exception as e:
                                    self.update_log.emit(f"Warning: could not pre-compute hotpixel clusters: {e}")
                                    hotpixel_cluster_map = None

                            # Pre-computation for CCD: only count as NG when
                            # there are at least 3 images (different file_name) with CCD error at the same position
                            # (grouped by Folder + Pattern + error center position with tolerance=40 pixels).
                            ccd_cluster_info = None
                            if detector_name == "CCD":
                                try:
                                    import re
                                    CCD_POSITION_TOLERANCE = 40  # pixels tolerance for CCD error center positions (from ccd_detector.py)
                                    
                                    # Extract error center positions for each row (with file_name)
                                    ccd_positions_list = []
                                    for idx, row in df.iterrows():
                                        folder_val = self._safe_str(row.get("Folder", "")).strip()
                                        pattern_val = self._safe_str(row.get("Pattern", "")).strip()
                                        file_name_val = self._safe_str(row.get("File Name", "")).strip()
                                        error_pos_str = self._safe_str(row.get("Error Positions", "")).strip()
                                        
                                        if not error_pos_str or error_pos_str.lower() == "nan":
                                            continue
                                        
                                        # Parse error positions: (x1,y1)-(x2,y2); (x1,y1)-(x2,y2); ...
                                        # Format: (x1,y1)-(x2,y2)
                                        error_pattern = r"\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*-\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)"
                                        matches = re.finditer(error_pattern, error_pos_str)
                                        
                                        for match in matches:
                                            x1, y1, x2, y2 = map(float, match.groups())
                                            # Calculate center point (same as get_error_regions in ccd_detector.py)
                                            center_x = (x1 + x2) / 2.0
                                            center_y = (y1 + y2) / 2.0
                                            error_pos_str_formatted = f"({int(x1)},{int(y1)})-({int(x2)},{int(y2)})"
                                            ccd_positions_list.append({
                                                "Folder": folder_val,
                                                "Pattern": pattern_val,
                                                "File_Name": file_name_val,
                                                "Center_X": center_x,
                                                "Center_Y": center_y,
                                                "Error_Pos": error_pos_str_formatted
                                            })
                                    
                                    if ccd_positions_list:
                                        # Group similar positions (within tolerance) and count unique file_names
                                        cluster_groups = []
                                        processed = set()
                                        
                                        for i, pos1 in enumerate(ccd_positions_list):
                                            if i in processed:
                                                continue
                                            
                                            # Find all positions similar to pos1
                                            cluster_indices = [i]
                                            unique_files = {pos1["File_Name"]}
                                            
                                            for j, pos2 in enumerate(ccd_positions_list[i+1:], start=i+1):
                                                if j in processed:
                                                    continue
                                                
                                                # Check if same folder and pattern
                                                if pos1["Folder"] != pos2["Folder"] or pos1["Pattern"] != pos2["Pattern"]:
                                                    continue
                                                
                                                # Check if centers are within tolerance (Euclidean distance <= 40)
                                                distance = np.sqrt((pos1["Center_X"] - pos2["Center_X"])**2 + 
                                                                  (pos1["Center_Y"] - pos2["Center_Y"])**2)
                                                if distance <= CCD_POSITION_TOLERANCE:
                                                    cluster_indices.append(j)
                                                    unique_files.add(pos2["File_Name"])
                                                    processed.add(j)
                                            
                                            # Only store if >= 3 unique images
                                            if len(unique_files) >= 3:
                                                # Store cluster info for each error position in cluster
                                                for idx in cluster_indices:
                                                    cluster_groups.append({
                                                        "Folder": pos1["Folder"],
                                                        "Pattern": pos1["Pattern"],
                                                        "File_Name": ccd_positions_list[idx]["File_Name"],
                                                        "Error_Pos": ccd_positions_list[idx]["Error_Pos"],
                                                        "Cluster_Size": len(unique_files)
                                                    })
                                            processed.add(i)
                                        
                                        if cluster_groups:
                                            ccd_cluster_info = pd.DataFrame(cluster_groups)
                                except Exception as e:
                                    self.update_log.emit(f"Warning: could not pre-compute {detector_name} clusters: {e}")
                                    ccd_cluster_info = None

                            # Pre-computation for Bubble, Dust, LShape
                            defect_cluster_info = None
                            if detector_name in {"Bubble", "Dust", "LShape"}:
                                try:
                                    import re
                                    TOLERANCE_MAP = {
                                        "Bubble": 25,
                                        "Dust": 80,
                                        "LShape": 100
                                    }
                                    POSITION_TOLERANCE = TOLERANCE_MAP.get(detector_name, 100)
                                    
                                    defect_positions_list = []
                                    for idx, row in df.iterrows():
                                        folder_val = self._safe_str(row.get("Folder", "")).strip()
                                        pattern_val = self._safe_str(row.get("Pattern", "")).strip()
                                        file_name_val = self._safe_str(row.get("File Name", "")).strip()
                                        defect_pos_str = self._safe_str(row.get("Defect Positions", "")).strip()
                                        
                                        if not defect_pos_str or defect_pos_str.lower() == "nan":
                                            continue
                                        
                                        bbox_pattern = r"\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)"
                                        matches = re.finditer(bbox_pattern, defect_pos_str)
                                        
                                        for match in matches:
                                            x, y, w, h = map(float, match.groups())
                                            center_x = x + w / 2.0
                                            center_y = y + h / 2.0
                                            defect_positions_list.append({
                                                "Folder": folder_val,
                                                "Pattern": pattern_val,
                                                "File_Name": file_name_val,
                                                "Center_X": center_x,
                                                "Center_Y": center_y,
                                                "Bbox": f"({int(x)},{int(y)},{int(w)},{int(h)})"
                                            })
                                    
                                    if defect_positions_list:
                                        cluster_groups = []
                                        processed = set()
                                        
                                        for i, pos1 in enumerate(defect_positions_list):
                                            if i in processed:
                                                continue
                                            
                                            cluster_indices = [i]
                                            unique_files = {pos1["File_Name"]}
                                            
                                            for j, pos2 in enumerate(defect_positions_list[i+1:], start=i+1):
                                                if j in processed:
                                                    continue
                                                
                                                if pos1["Folder"] != pos2["Folder"] or pos1["Pattern"] != pos2["Pattern"]:
                                                    continue
                                                
                                                dist_x = abs(pos1["Center_X"] - pos2["Center_X"])
                                                dist_y = abs(pos1["Center_Y"] - pos2["Center_Y"])
                                                if dist_x <= POSITION_TOLERANCE and dist_y <= POSITION_TOLERANCE:
                                                    cluster_indices.append(j)
                                                    unique_files.add(pos2["File_Name"])
                                                    processed.add(j)
                                            
                                            if len(unique_files) >= 3:
                                                for idx in cluster_indices:
                                                    cluster_groups.append({
                                                        "Folder": pos1["Folder"],
                                                        "Pattern": pos1["Pattern"],
                                                        "File_Name": defect_positions_list[idx]["File_Name"],
                                                        "Bbox": defect_positions_list[idx]["Bbox"],
                                                        "Cluster_Size": len(unique_files)
                                                    })
                                            processed.add(i)
                                        
                                        if cluster_groups:
                                            defect_cluster_info = pd.DataFrame(cluster_groups)
                                except Exception as e:
                                    self.update_log.emit(f"Warning: could not pre-compute {detector_name} clusters: {e}")
                                    defect_cluster_info = None

                            # Process each row
                            for index, row in df.iterrows():
                                # Get common columns
                                folder = row.get('Folder', 'Unknown')
                                file_name = row.get('File Name', 'Unknown')
                                pattern = row.get('Pattern', 'Unknown')
                                resolution = row.get('Resolution', 'Unknown')
                                
                                # Extract PID from file name
                                pid = self._extract_pid_sn(file_name)
                                
                                # Create a unique key for (camera, PID, pattern)
                                unique_key = (folder, pid, pattern)
                                
                                # Initialize if this is first time seeing this combination
                                if unique_key not in combined_data:
                                    combined_data[unique_key] = {
                                        'Camera': folder,
                                        'PID': pid,
                                        'Pattern': pattern,
                                        'Resolution': resolution,
                                        'File_Name_Original': file_name,  # Store original for Date_Time lookup
                                        'Status': set(),  # For Result column (NG detectors)
                                        # Initialize all detector columns with "No Check"
                                        'Hotpixel_Result': "No Check",
                                        'Hotpixel_Map': "",
                                        'Hotpixel_Intesity': "",
                                        'CCD_Result': "No Check",
                                        'CCD_Map': "",
                                        'CCD_Result_NG': "No Check",
                                        'CCD_Map_NG': "",
                                        'CCD_Slope': "",
                                        'CCD_Threshold': "",
                                        'Bubble_Result': "No Check",
                                        'Bubble_Map': "",
                                        'Bubble_Value': "",
                                        'LShape_Result': "No Check",
                                        'LShape_Map': "",
                                        'LShape_Value': "",
                                        'Dust_Result': "No Check",
                                        'Dust_Map': "",
                                        'Dust_Value': "",
                                        'Hiaa_result': "No Check",
                                        'Hiaa_Map': "",
                                        'Hiaa_Value': "",
                                        'Hiaa_Threshold': "",
                                        'TopEdge_Result': "No Check",
                                        'TopEdge_Map': "",
                                        'TopEdge_Value': "",
                                        'TopEdge_Threshold': ""
                                    }
                                
                                # Process based on detector type
                                if detector_name == "Hotpixel":
                                    # Determine if this file has a valid hotpixel cluster
                                    cluster_ok = False
                                    cluster_info = None
                                    if hotpixel_cluster_map is not None:
                                        try:
                                            folder_val = self._safe_str(row.get("Folder", "")).strip()
                                            pattern_val = self._safe_str(row.get("Pattern", "")).strip()
                                            file_name_val = self._safe_str(row.get("File Name", "")).strip()
                                            if folder_val and pattern_val and file_name_val:
                                                cluster_info = hotpixel_cluster_map.get((folder_val, pattern_val, file_name_val))
                                                if cluster_info:
                                                    cluster_ok = True
                                        except Exception:
                                            cluster_ok = False
                                    
                                    if cluster_ok:
                                        combined_data[unique_key]["Hotpixel_Result"] = "NG"

                                        # Write position in original format "(x, y)"
                                        new_map = self._format_special_values((cluster_info or {}).get("map_str", ""))
                                        if new_map:
                                            cur_map = self._safe_str(combined_data[unique_key].get("Hotpixel_Map", "")).strip()
                                            if not cur_map:
                                                combined_data[unique_key]["Hotpixel_Map"] = new_map
                                            elif new_map not in cur_map.split("; "):
                                                combined_data[unique_key]["Hotpixel_Map"] = cur_map + "; " + new_map

                                        # Use cluster max intensity (strongest) if available, else fallback to row intensity
                                        new_int = self._format_special_values((cluster_info or {}).get("intensity", ""))
                                        if not new_int:
                                            new_int = self._format_special_values(row.get("Max Intensity", ""))
                                        if new_int:
                                            cur_int = self._safe_str(combined_data[unique_key].get("Hotpixel_Intesity", "")).strip()
                                            if not cur_int:
                                                combined_data[unique_key]["Hotpixel_Intesity"] = new_int
                                            elif new_int not in cur_int.split("; "):
                                                combined_data[unique_key]["Hotpixel_Intesity"] = cur_int + "; " + new_int

                                        combined_data[unique_key]['Status'].add("Hotpixel")
                                    else:
                                        # Only mark as OK if we found data for this detector
                                        if combined_data[unique_key].get("Hotpixel_Result") != "NG":
                                            combined_data[unique_key]["Hotpixel_Result"] = "OK"
                                
                                elif detector_name in {"Bubble", "LShape", "Dust"}:
                                    prefix = detector_name
                                    
                                    # Determine if this file has a valid defect cluster
                                    cluster_ok = False
                                    if defect_cluster_info is not None:
                                        try:
                                            import re
                                            folder_val = self._safe_str(row.get("Folder", "")).strip()
                                            pattern_val = self._safe_str(row.get("Pattern", "")).strip()
                                            file_name_val = self._safe_str(row.get("File Name", "")).strip()
                                            defect_pos_str = self._safe_str(row.get("Defect Positions", "")).strip()
                                            
                                            if defect_pos_str and folder_val and pattern_val and file_name_val:
                                                bbox_pattern = r"\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)"
                                                matches = re.finditer(bbox_pattern, defect_pos_str)
                                                
                                                for match in matches:
                                                    x, y, w, h = map(int, match.groups())
                                                    bbox_str = f"({x},{y},{w},{h})"
                                                    
                                                    mask = (
                                                        (defect_cluster_info["Folder"] == folder_val) &
                                                        (defect_cluster_info["Pattern"] == pattern_val) &
                                                        (defect_cluster_info["File_Name"] == file_name_val) &
                                                        (defect_cluster_info["Bbox"] == bbox_str)
                                                    )
                                                    match_rows = defect_cluster_info[mask]
                                                    if not match_rows.empty and match_rows["Cluster_Size"].iloc[0] >= 3:
                                                        cluster_ok = True
                                                        break
                                        except Exception as e:
                                            cluster_ok = False
                                    
                                    if cluster_ok:
                                        status_val = row.get("Status", "OK")
                                        result_val = self._normalize_result(status_val)
                                        combined_data[unique_key][f"{prefix}_Result"] = result_val
                                        
                                        defect_positions = self._format_special_values(
                                            row.get("Defect Positions", "")
                                        )
                                        formatted_positions = self._convert_bbox_to_coordinate_pairs(defect_positions)
                                        combined_data[unique_key][f"{prefix}_Map"] = formatted_positions
                                        
                                        combined_data[unique_key][f"{prefix}_Value"] = self._format_special_values(
                                            row.get("Max Variance", "")
                                        )
                                        
                                        if result_val == "NG":
                                            combined_data[unique_key]['Status'].add(prefix)
                                    else:
                                        # Only mark as OK if we found data for this detector
                                        combined_data[unique_key][f"{prefix}_Result"] = "OK"
                                
                                elif detector_name == "CCD":
                                    status_val = row.get("Status", row.get("Has CCD", "OK"))
                                    result_val = self._normalize_result(status_val)
                                    combined_data[unique_key]["CCD_Result"] = result_val
                                    combined_data[unique_key]["CCD_Map"] = self._format_special_values(
                                        row.get("Error Positions", "")
                                    )
                                    
                                    # Get Max Slope
                                    max_slope_raw = row.get("Max Slope", None)
                                    severity_score_raw = row.get("Severity Score", None)
                                    
                                    if max_slope_raw is None or (isinstance(max_slope_raw, float) and pd.isna(max_slope_raw)):
                                        max_slope = severity_score_raw if severity_score_raw is not None else ""
                                    else:
                                        max_slope = max_slope_raw
                                    
                                    if max_slope is not None and max_slope != "" and not (isinstance(max_slope, float) and pd.isna(max_slope)):
                                        try:
                                            max_slope_float = float(max_slope)
                                            combined_data[unique_key]["CCD_Slope"] = f"{max_slope_float:.6f}"
                                        except (ValueError, TypeError):
                                            combined_data[unique_key]["CCD_Slope"] = self._format_special_values(max_slope)
                                    else:
                                        combined_data[unique_key]["CCD_Slope"] = ""
                                    
                                    combined_data[unique_key]["CCD_Threshold"] = self._format_special_values(
                                        row.get("Slope Threshold", "")
                                    )
                                    
                                    # Check for CCD_Result_NG and CCD_Map_NG: only mark NG when >= 3 images have CCD at same position
                                    ccd_ng_result = "OK"
                                    ccd_ng_map = ""
                                    if ccd_cluster_info is not None:
                                        try:
                                            import re
                                            folder_val = self._safe_str(row.get("Folder", "")).strip()
                                            pattern_val = self._safe_str(row.get("Pattern", "")).strip()
                                            file_name_val = self._safe_str(row.get("File Name", "")).strip()
                                            error_pos_str = self._safe_str(row.get("Error Positions", "")).strip()
                                            
                                            if error_pos_str and folder_val and pattern_val and file_name_val:
                                                # Parse error positions from this row
                                                error_pattern = r"\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*-\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)"
                                                matches = re.finditer(error_pattern, error_pos_str)
                                                
                                                ng_positions = []
                                                for match in matches:
                                                    x1, y1, x2, y2 = map(int, match.groups())
                                                    error_pos_str_formatted = f"({x1},{y1})-({x2},{y2})"
                                                    
                                                    # Check if this file's error position is in a valid cluster (>= 3 images)
                                                    mask = (
                                                        (ccd_cluster_info["Folder"] == folder_val) &
                                                        (ccd_cluster_info["Pattern"] == pattern_val) &
                                                        (ccd_cluster_info["File_Name"] == file_name_val) &
                                                        (ccd_cluster_info["Error_Pos"] == error_pos_str_formatted)
                                                    )
                                                    match_rows = ccd_cluster_info[mask]
                                                    if not match_rows.empty and match_rows["Cluster_Size"].iloc[0] >= 3:
                                                        ng_positions.append(error_pos_str_formatted)
                                                        ccd_ng_result = "NG"
                                                
                                                if ng_positions:
                                                    ccd_ng_map = "; ".join(ng_positions)
                                        except Exception as e:
                                            self.update_log.emit(f"Warning: CCD cluster check failed: {e}")
                                    
                                    combined_data[unique_key]["CCD_Result_NG"] = ccd_ng_result
                                    combined_data[unique_key]["CCD_Map_NG"] = ccd_ng_map
                                    
                                    if ccd_ng_result == "NG":
                                        combined_data[unique_key]['Status'].add("CCD")
                                
                                elif detector_name == "Hiaa":
                                    has_hiaa = row.get("Has Hiaa", "No")
                                    result_val = self._normalize_result(has_hiaa)
                                    combined_data[unique_key]["Hiaa_result"] = result_val
                                    combined_data[unique_key]["Hiaa_Map"] = self._format_special_values(
                                        row.get("Affected Region", "")
                                    )
                                    combined_data[unique_key]["Hiaa_Value"] = self._format_special_values(
                                        row.get("D Value", "")
                                    )
                                    combined_data[unique_key]["Hiaa_Threshold"] = self._format_special_values(
                                        row.get("Threshold Used", "")
                                    )
                                    
                                    if result_val == "NG":
                                        combined_data[unique_key]['Status'].add("Hiaa")
                                
                                elif detector_name == "TopEdge":
                                    has_topedge = row.get("Has Top_Edge", "No")
                                    result_val = self._normalize_result(has_topedge)
                                    combined_data[unique_key]["TopEdge_Result"] = result_val
                                    combined_data[unique_key]["TopEdge_Map"] = self._format_special_values(
                                        row.get("Affected Region", "")
                                    )
                                    combined_data[unique_key]["TopEdge_Value"] = self._format_special_values(
                                        row.get("D Value", "")
                                    )
                                    combined_data[unique_key]["TopEdge_Threshold"] = self._format_special_values(
                                        row.get("Threshold Used", "")
                                    )
                                    
                                    if result_val == "NG":
                                        combined_data[unique_key]['Status'].add("TopEdge")
                                    
                    except Exception as e:
                        self.update_log.emit(f"Error processing {detector_name} CSV: {e}")
                        import traceback
                        self.update_log.emit(f"Traceback: {traceback.format_exc()}")
                else:
                    self.update_log.emit(f"CSV file not found for {detector_name}")
            
            if not combined_data:
                self.update_log.emit("No data to combine")
                return
            
            # Convert dictionary to list of rows
            rows = []
            for unique_key, data in combined_data.items():
                # Convert Status set to string for Result column
                status_list = list(data['Status'])
                
                # Remove CCD from status list if CCD_Result_NG is not NG
                if "CCD" in status_list and data.get("CCD_Result_NG") != "NG":
                    status_list.remove("CCD")
                
                if status_list:
                    result_status = ', '.join(sorted(status_list))
                    data['Result'] = result_status
                else:
                    data['Result'] = 'OK'
                
                # Remove the Status set (already converted to Result)
                del data['Status']
                
                # Add Date_Time column using original file name
                def get_file_datetime(camera, original_file_name):
                    """Get Modified time of TIF file and format as YYYYMMDDHHMMSS"""
                    try:
                        if not camera or not original_file_name:
                            return ""
                        
                        camera_folder = os.path.join(self.root_folder, camera)
                        if not os.path.exists(camera_folder):
                            return ""
                        
                        tif_file_path = None
                        possible_names = [
                            original_file_name,
                            original_file_name if original_file_name.endswith('.tif') else f"{original_file_name}.tif",
                            original_file_name if original_file_name.endswith('.TIF') else f"{original_file_name}.TIF"
                        ]
                        
                        for name in possible_names:
                            candidate_path = os.path.join(camera_folder, name)
                            if os.path.exists(candidate_path):
                                tif_file_path = candidate_path
                                break
                        
                        if not tif_file_path:
                            for root, dirs, files in os.walk(camera_folder):
                                for name in possible_names:
                                    candidate_path = os.path.join(root, name)
                                    if os.path.exists(candidate_path):
                                        tif_file_path = candidate_path
                                        break
                                if tif_file_path:
                                    break
                        
                        if tif_file_path and os.path.exists(tif_file_path):
                            modified_time = os.path.getmtime(tif_file_path)
                            from datetime import datetime
                            dt = datetime.fromtimestamp(modified_time)
                            return "'" + dt.strftime("%Y%m%d%H%M%S")
                        else:
                            return ""
                    except Exception as e:
                        self.update_log.emit(f"Warning: Could not get datetime for {camera}/{original_file_name}: {e}")
                        return ""
                
                # Add Date_Time column
                original_file_name = data.get('File_Name_Original', '')
                data['Date_Time'] = get_file_datetime(data.get('Camera', ''), original_file_name)
                
                # Remove temporary columns
                if 'File_Name_Original' in data:
                    del data['File_Name_Original']
                if 'Resolution' in data:
                    del data['Resolution']
                
                rows.append(data)
            
            combined_df = pd.DataFrame(rows)
            
            # Define the exact column order
            desired_columns = [
                'Camera', 'PID', 'Date_Time', 'Pattern', 'Result',
                'Hotpixel_Result', 'Hotpixel_Map', 'Hotpixel_Intesity',
                'CCD_Result', 'CCD_Map', 'CCD_Result_NG', 'CCD_Map_NG', 'CCD_Slope', 'CCD_Threshold',
                'Bubble_Result', 'Bubble_Map', 'Bubble_Value',
                'LShape_Result', 'LShape_Map', 'LShape_Value',
                'Dust_Result', 'Dust_Map', 'Dust_Value',
                'Hiaa_result', 'Hiaa_Map', 'Hiaa_Value', 'Hiaa_Threshold',
                'TopEdge_Result', 'TopEdge_Map', 'TopEdge_Value', 'TopEdge_Threshold'
            ]
            
            # Create missing columns with empty values
            for col in desired_columns:
                if col not in combined_df.columns:
                    # Initialize CCD_Result_NG and CCD_Map_NG with "No Check" if not set
                    if col in ['CCD_Result_NG']:
                        combined_df[col] = "No Check"
                    else:
                        combined_df[col] = ""
            
            # Ensure Date_Time is string type
            if 'Date_Time' in combined_df.columns:
                combined_df['Date_Time'] = combined_df['Date_Time'].astype(str)
                combined_df['Date_Time'] = combined_df['Date_Time'].replace('nan', '')
            
            # Reorder DataFrame columns
            final_columns = [col for col in desired_columns if col in combined_df.columns]
            combined_df = combined_df[final_columns]
            
            # Sort by Camera -> Pattern -> PID
            sort_cols = [c for c in ['Camera', 'Pattern', 'PID'] if c in combined_df.columns]
            if sort_cols:
                combined_df = combined_df.sort_values(by=sort_cols)
            
            # Reset index
            combined_df = combined_df.reset_index(drop=True)
            
            # Apply final cleaning
            combined_df = self._clean_dataframe_columns(combined_df)
            
            # Ensure Date_Time is string after cleaning
            if 'Date_Time' in combined_df.columns:
                combined_df['Date_Time'] = combined_df['Date_Time'].astype(str)
                combined_df['Date_Time'] = combined_df['Date_Time'].replace('nan', '')
            
            # Save combined CSV file
            csv_output_path = self.summary_csv_path
            import csv
            combined_df.to_csv(csv_output_path, index=False, encoding='utf-8-sig', quoting=csv.QUOTE_ALL)

            self.update_log.emit(f"✅ Summary log CSV file saved: {csv_output_path}")
            self.update_log.emit(f"Total unique PID-Pattern combinations: {len(combined_df)}")
            
        except Exception as e:
            self.update_log.emit(f"Error creating combined CSV: {type(e).__name__} - {str(e)}")
            import traceback
            self.update_log.emit(f"Traceback: {traceback.format_exc()}")

class DetectorStatusWidget(QWidget):
    """Compact widget for detector status"""
    def __init__(self, detector_name, parent=None):
        super().__init__(parent)
        self.detector_name = detector_name
        self.status = "pending"
        
        self.setFixedHeight(30)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(8)
        
        # Status icon
        self.icon_label = QLabel()
        self.icon_label.setFixedSize(16, 16)
        self._update_icon()
        layout.addWidget(self.icon_label)
        
        # Detector name
        self.name_label = QLabel(detector_name)
        self.name_label.setFont(QFont("Segoe UI", 9))
        self.name_label.setStyleSheet("color: #2c3e50;")
        layout.addWidget(self.name_label)
        
        # Status text
        self.status_label = QLabel("Pending")
        self.status_label.setFont(QFont("Segoe UI", 8))
        layout.addWidget(self.status_label)
        
        layout.addStretch()
    
    def _update_icon(self):
        if self.status == "completed":
            self.icon_label.setStyleSheet("""
                QLabel {
                    background: #27ae60;
                    border-radius: 8px;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.icon_label.setText("✓")
        elif self.status == "Checking":
            self.icon_label.setStyleSheet("""
                QLabel {
                    background: #3498db;
                    border-radius: 8px;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.icon_label.setText("▶")
        else:  # pending
            self.icon_label.setStyleSheet("""
                QLabel {
                    background: #95a5a6;
                    border-radius: 8px;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.icon_label.setText("●")
    
    def update_status(self, status):
        self.status = status
        self._update_icon()
        
        if status == "completed":
            self.status_label.setText("Completed")
            self.status_label.setStyleSheet("color: #27ae60; font-weight: bold;")
            self.name_label.setStyleSheet("color: #27ae60; font-weight: bold;")
        elif status == "Checking":
            self.status_label.setText("Checking...")
            self.status_label.setStyleSheet("color: #3498db; font-weight: bold;")
            self.name_label.setStyleSheet("color: #3498db; font-weight: bold;")
        else:  # pending
            self.status_label.setText("Pending")
            self.status_label.setStyleSheet("color: #7f8c8d;")
            self.name_label.setStyleSheet("color: #2c3e50;")

class SummaryDialog(QDialog):
    def __init__(self, parent, table_rows, open_cb):
        super().__init__(parent)
        self.setWindowTitle("Image Analysis Results")
        self.setModal(True)
        self.resize(800, 700)
        
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)
        
        header = QWidget()
        header.setFixedHeight(70)
        header.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 10px;
            }
        """)
        hl = QHBoxLayout(header)
        hl.setContentsMargins(20, 0, 20, 0)
        
        title = QLabel("📊 Image Analysis Results")
        title.setStyleSheet("color: white; font-weight: bold;")
        title.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        hl.addWidget(title)
        hl.addStretch()
        
        self.btn_open = QPushButton("📁 Open Report Excel")
        self.btn_open.setStyleSheet("""
            QPushButton {
                background: #fff;
                color: #2c3e50;
                border: 2px solid #fff;
                border-radius: 8px;
                padding: 8px 16px;
                font-weight: bold;
                font-size: 12px;
            }
            QPushButton:hover {
                background: #eaf2fb;
                border-color: #eaf2fb;
            }
            QPushButton:pressed {
                background: #d0e0f0;
            }
        """)
        self.btn_open.clicked.connect(open_cb)
        hl.addWidget(self.btn_open)
        layout.addWidget(header)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("""
            QScrollArea {
                background: transparent;
                border: none;
            }
            QScrollBar:vertical {
                background: #f0f0f0;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background: #3498db;
                border-radius: 6px;
                min-height: 30px;
            }
            QScrollBar::handle:vertical:hover {
                background: #2980b9;
            }
        """)
        
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Detector", "Total Camera", "Camera List"])
        self.table.setStyleSheet("""
            QTableWidget {
                background: #ffffff;
                border: 2px solid #e0e0e0;
                border-radius: 10px;
                gridline-color: #e8e8e8;
                font-size: 12px;
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid #f0f0f0;
            }
            QTableWidget::item:selected {
                background: #e3f2fd;
                color: #1976d2;
            }
            QHeaderView::section {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #f5f5f5, stop:1 #e8e8e8);
                color: #2c3e50;
                font-weight: bold;
                font-size: 13px;
                padding: 10px;
                border: none;
                border-bottom: 2px solid #3498db;
            }
        """)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        
        error_ratios = []
        for row in table_rows:
            if len(row) >= 5:
                error_count = row[3]
                total_count = row[4]
                if total_count > 0:
                    ratio = error_count / total_count
                    error_ratios.append(ratio)
                else:
                    error_ratios.append(0.0)
        
        min_ratio = min(error_ratios) if error_ratios else 0.0
        max_ratio = max(error_ratios) if error_ratios else 1.0
        
        for i, row in enumerate(table_rows):
            r = self.table.rowCount()
            self.table.insertRow(r)
            for c, val in enumerate(row[:3]):
                item = QTableWidgetItem(str(val))
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if c == 0:
                    item.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
                    item.setForeground(QColor("#2c3e50"))
                elif c == 1:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    item.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
                    if len(row) >= 5 and i < len(error_ratios):
                        ratio = error_ratios[i]
                        if max_ratio > min_ratio:
                            normalized = (ratio - min_ratio) / (max_ratio - min_ratio)
                        else:
                            normalized = 0.0
                        
                        red = int(255 * normalized)
                        green = int(255 * (1 - normalized))
                        blue = int(255 * (1 - normalized))
                        
                        red = min(255, max(200, red))
                        green = min(255, max(200, green))
                        blue = min(255, max(200, blue))
                        
                        bg_color = QColor(red, green, blue)
                        brightness = red * 0.299 + green * 0.587 + blue * 0.114
                        text_color = QColor("#000000") if brightness > 180 else QColor("#FFFFFF")
                        
                        item.setBackground(bg_color)
                        item.setForeground(text_color)
                else:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
                self.table.setItem(r, c, item)
        
        self.table.setColumnWidth(0, 200)
        self.table.setColumnWidth(1, 150)
        self.table.setWordWrap(True)
        self.table.resizeRowsToContents()
        
        scroll_area.setWidget(self.table)
        layout.addWidget(scroll_area)
        
        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)
        btn_close = QPushButton("✕ Close")
        btn_close.setStyleSheet("""
            QPushButton {
                background: #3498db;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px 24px;
                font-weight: bold;
                font-size: 13px;
                min-width: 100px;
            }
            QPushButton:hover {
                background: #2980b9;
            }
            QPushButton:pressed {
                background: #21618c;
            }
        """)
        btn_close.clicked.connect(self.accept)
        btn_row.addStretch()
        btn_row.addWidget(btn_close)
        layout.addLayout(btn_row)


class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_app_window = parent
        self.setWindowTitle("Automatic Image Analysis Tool")
        self.resize(700, 900)  # Slightly taller for status grid
        self.setWindowIcon(QIcon(":/icons/image_analysis.png"))

        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 247, 250))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(52, 73, 94))
        self.setPalette(palette)

        app = QApplication.instance()
        if app is not None:
            try:
                app.setQuitOnLastWindowClosed(False)
            except Exception:
                pass

        self.selected_folder = None
        self.analysis_output_folder = None
        self.models_config = load_model_config()
        self.detector_widgets = {}

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Header
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(90)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)
        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))
        icon_button.setGraphicsEffect(icon_shadow)
        icon = QtGui.QIcon(":/icons/image_analysis.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70))
        header_layout.addWidget(icon_button)

        text_container = QtWidgets.QWidget()
        text_container.setStyleSheet("""
            QWidget {
                background: transparent;
            }
        """)
        text_layout = QtWidgets.QVBoxLayout(text_container)
        text_layout.setSpacing(5)

        title_label = QtWidgets.QLabel("Automatic Image Analysis Tool")
        title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        title_label.setFont(QtGui.QFont("Segoe UI", 22, QtGui.QFont.Weight.Bold))
        title_label.setStyleSheet("""
            color: white;
            padding: 0;
            margin: 0;
            letter-spacing: 1px;
        """)

        subtitle_label = QtWidgets.QLabel("HotPixel, CCD, Bubble, LShape, Dust, Hiaa, TopEdge Camera defect Checker")
        subtitle_label.setFont(QtGui.QFont("Segoe UI", 9, QtGui.QFont.Weight.Bold))
        subtitle_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.95);
            margin-top: 0px;
            padding: 0;
            letter-spacing: 0.5px;
        """)

        text_layout.addWidget(title_label)
        text_layout.addWidget(subtitle_label)
        header_layout.addWidget(text_container)

        header_layout.addStretch()

        self.btn_manage_models = QtWidgets.QPushButton("")
        self.btn_manage_models.setIcon(QIcon(":/icons/setting.png"))
        self.btn_manage_models.setIconSize(QSize(50, 50))
        self.btn_manage_models.setFixedSize(60, 60)
        self.btn_manage_models.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_manage_models.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.2);
                border: none;
                border-radius: 20px;
                padding: 5px;
                color: white;
            }
            QPushButton:hover { background-color: rgba(255, 255, 255, 0.3); }
            QPushButton:pressed { background-color: rgba(255, 255, 255, 0.4); }
        """)
        settings_shadow = QtWidgets.QGraphicsDropShadowEffect()
        settings_shadow.setBlurRadius(8)
        settings_shadow.setXOffset(1)
        settings_shadow.setYOffset(1)
        settings_shadow.setColor(QtGui.QColor(0, 0, 0, 60))
        self.btn_manage_models.setGraphicsEffect(settings_shadow)
        self.btn_manage_models.clicked.connect(self.manage_models)
        header_layout.addWidget(self.btn_manage_models)
        main_layout.addWidget(header_container)

        # Controls
        controls_container = QWidget()
        controls_container.setObjectName("controlsContainer")
        controls_container.setStyleSheet("""
            #controlsContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        controls_container.setGraphicsEffect(self.create_shadow_effect())
        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setSpacing(10)

        model_label = QLabel("Select Model:")
        model_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        model_label.setStyleSheet("color: #2c3e50;")
        controls_layout.addWidget(model_label)

        self.combo_model_selection = QtWidgets.QComboBox()
        self.combo_model_selection.setStyleSheet("""
            QComboBox {
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 8px;
                padding: 5px 10px;
                min-width: 80px;
                color: #2c3e50;
                font-size: 14px;
            }
            QComboBox:hover {
                border: 2px solid #3498db;
                background-color: #f7fbff;
            }
            QComboBox:focus {
                border: 2px solid #3498db;
                background-color: white;
            }

            /* Nút dropdown */
            QComboBox::drop-down {
                border: none;
                padding-right: 10px;
            }
            QComboBox::down-arrow {
                image: url(:/icons/down_arrow.png);
                width: 12px;
                height: 12px;
            }

            /* Drop-down list */
            QComboBox QAbstractItemView {
                background: white;  /* White background */
                border: 1px solid rgba(0, 0, 0, 0.2);  /* Light shadow border */
                border-radius: 6px;
                padding: 2px;
                outline: 0px;
                selection-background-color: transparent;
            }

            /* Reduced list padding */
            QComboBox QAbstractItemView::item {
                font-size: 14px;
                padding: 3px 10px;
                color: #2c3e50;
                background-color: white; /* White background */
            }

            /* Hover stands out more */
            QComboBox QAbstractItemView::item:hover {
                color: white;
                background-color: #00c2c7; /* Turquoise background */
                border-radius: 4px; /* Bo góc nhẹ */
            }

            /* Item is selected */
            QComboBox QAbstractItemView::item:selected {
                color: white;
                background-color: #00a2b3; /* Darker turquoise */
                border-radius: 4px;
            }
        """)
        controls_layout.addWidget(self.combo_model_selection)

        self.combo_model_selection.blockSignals(True)
        self.combo_model_selection.currentTextChanged.connect(self.on_model_selected)
        initial_config = load_model_config()
        self.models_config = initial_config["models"]
        self.last_selected_model = initial_config["last_selected_model"]
        if not self.models_config:
            self.models_config = {"D965": 721, "D914": 699}
            self.last_selected_model = "D965"
            save_model_config({"models": self.models_config, "last_selected_model": self.last_selected_model})
        self._load_models_to_combobox()
        if self.last_selected_model and self.last_selected_model in self.models_config:
            self.combo_model_selection.setCurrentText(self.last_selected_model)
            self.selected_model = self.last_selected_model
        elif self.models_config:
            self.selected_model = next(iter(self.models_config))
            self.combo_model_selection.setCurrentText(self.selected_model)
        else:
            self.selected_model = None
        self.combo_model_selection.blockSignals(False)
        if self.selected_model:
            self.on_model_selected()

        separator = QLabel("|")
        separator.setStyleSheet("color: #3498db; font-size: 20px;")
        separator.setFixedHeight(40)
        controls_layout.addWidget(separator)

        self.btn_select_folder = QPushButton("Select Folder")
        self.btn_select_folder.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_DirIcon))
        self.btn_select_folder.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_select_folder.setStyleSheet(self._button_style())
        self.btn_select_folder.clicked.connect(self.select_folder)
        controls_layout.addWidget(self.btn_select_folder)

        separator1 = QLabel("|")
        separator1.setStyleSheet("color: #3498db; font-size: 20px;")
        separator1.setFixedHeight(40)
        controls_layout.addWidget(separator1)

        self.btn_start = QPushButton("Start Checking")
        self.btn_start.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MediaPlay))
        self.btn_start.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_start.setEnabled(False)
        self.btn_start.setStyleSheet(self._button_style())
        self.btn_start.clicked.connect(self.start_checking)
        controls_layout.addWidget(self.btn_start)

        main_layout.addWidget(controls_container)

        # Detector Status Section - Compact
        status_container = QWidget()
        status_container.setObjectName("statusContainer")
        status_container.setStyleSheet("""
            #statusContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        status_container.setGraphicsEffect(self.create_shadow_effect())
        status_layout = QVBoxLayout(status_container)
        status_layout.setSpacing(0)
        
        status_header = QWidget()
        status_header_layout = QHBoxLayout(status_header)
        status_header_layout.setContentsMargins(0, 0, 0, 5)
        
        status_title = QLabel("Detector Status")
        status_title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        status_title.setStyleSheet("color: #2c3e50;")
        status_header_layout.addWidget(status_title)
        status_header_layout.addStretch()
        
        self.overall_status_label = QLabel("Overall: Ready")
        self.overall_status_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        self.overall_status_label.setStyleSheet("color: #3498db;")
        status_header_layout.addWidget(self.overall_status_label)
        
        status_layout.addWidget(status_header)
        
        # Grid for detector status widgets (4 columns for compact layout)
        grid_widget = QWidget()
        grid_layout = QGridLayout(grid_widget)
        grid_layout.setHorizontalSpacing(10)
        grid_layout.setVerticalSpacing(0)
        grid_layout.setContentsMargins(0, 0, 0, 0)
        
        detectors = ["HotPixel", "CCD", "Bubble", "LShape", "Dust", "Hiaa", "TopEdge"]
        for i, detector_name in enumerate(detectors):
            widget = DetectorStatusWidget(detector_name)
            self.detector_widgets[detector_name] = widget
            row = i // 4
            col = i % 4
            grid_layout.addWidget(widget, row, col)
        
        status_layout.addWidget(grid_widget)
        main_layout.addWidget(status_container)

        # Overall Progress
        progress_container = QWidget()
        progress_container.setObjectName("progressContainer")
        progress_container.setStyleSheet("""
            #progressContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        progress_container.setGraphicsEffect(self.create_shadow_effect())
        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setSpacing(0)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 1px;
                text-align: center;
                height: 25px;
                font-size: 11px;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 7px;
            }
        """)
        progress_layout.addWidget(self.progress_bar)
        main_layout.addWidget(progress_container)

        # Log
        log_container = QWidget()
        log_container.setObjectName("logContainer")
        log_container.setStyleSheet("""
            #logContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        log_container.setGraphicsEffect(self.create_shadow_effect())
        log_layout = QVBoxLayout(log_container)
        log_layout.setSpacing(0)
        log_header = QWidget()
        log_header_layout = QHBoxLayout(log_header)
        log_header_layout.setContentsMargins(0, 0, 0, 10)
        log_icon = QPushButton()
        log_icon.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MessageBoxInformation))
        log_icon.setIconSize(QSize(18, 18))
        log_icon.setFixedSize(18, 18)
        log_icon.setStyleSheet("""
            QPushButton {
                background: #f0f2f5;
                border: none;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        log_header_layout.addWidget(log_icon)
        log_label = QLabel("Processing Log:")
        log_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #2c3e50;")
        log_header_layout.addWidget(log_label)
        log_header_layout.addStretch()
        log_layout.addWidget(log_header)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        log_layout.addWidget(self.log_text)
        main_layout.addWidget(log_container)

        author_label = QLabel("Created by nguyenvanvuong1")
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        author_label.setStyleSheet("color: #3498db; padding: 0; margin: 0;")
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        self.controller = None
        self.summary_results = None

    def _button_style(self):
        return """
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 32px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 25))
        return shadow

    def _load_models_to_combobox(self):
        try:
            self.combo_model_selection.clear()
            for model_name in self.models_config.keys():
                self.combo_model_selection.addItem(model_name)
        except Exception:
            pass

    def on_model_selected(self):
        try:
            self.selected_model = self.combo_model_selection.currentText()
            self.last_selected_model = self.selected_model
            save_model_config({"models": self.models_config, "last_selected_model": self.last_selected_model})
            if hasattr(self, 'log_text'):
                self.log_text.append(f"Selected model: {self.selected_model}")
        except Exception:
            pass

    def select_folder(self):
        self.selected_folder = QFileDialog.getExistingDirectory(
            self,
            "Select Folder Containing TIFF Images",
            "",
            QFileDialog.Option.ShowDirsOnly
        )
        if self.selected_folder:
            self.log_text.append(f"Selected folder: {self.selected_folder}")
            self.analysis_output_folder = self.selected_folder
            self.btn_start.setEnabled(True)
            self.statusBar().showMessage(f"Selected folder: {os.path.basename(self.selected_folder)}")

    def start_checking(self):
        if not self.selected_folder:
            QMessageBox.warning(self, "Warning", "Please select a folder first!")
            return
        
        current_model = getattr(self, 'selected_model', None) or (self.combo_model_selection.currentText() if hasattr(self, 'combo_model_selection') else None)
        if current_model:
            save_model_config({"models": self.models_config, "last_selected_model": current_model})

        # Reset all detector widgets
        for detector_name, widget in self.detector_widgets.items():
            widget.update_status("pending")
        
        self.controller = CombinedDetectorController(self.selected_folder, current_model, self.models_config)
        self.controller.update_progress.connect(self.update_progress)
        self.controller.update_log.connect(self.update_log)
        self.controller.update_detector_status.connect(self.update_detector_status)
        self.controller.finished.connect(self.on_finished)
        self.controller.start()

        self.btn_start.setEnabled(False)
        self.overall_status_label.setText("Overall: Checking")
        self.overall_status_label.setStyleSheet("color: #3498db; font-weight: bold;")
        self.statusBar().showMessage("Running detectors...")

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_detector_status(self, detector_name, status):
        """Update individual detector status widget"""
        if detector_name in self.detector_widgets:
            self.detector_widgets[detector_name].update_status(status)

    def update_log(self, message):
        self.log_text.append(message)

    def on_finished(self, results):
        self.btn_start.setEnabled(True)
        self.overall_status_label.setText("Overall: Completed")
        self.overall_status_label.setStyleSheet("color: #27ae60; font-weight: bold;")
        self.statusBar().showMessage("Check completed")
        self.summary_results = results

        combined_path = None
        table_rows = []
        try:
            combined_path, table_rows = self._create_combined_excel_report(results)
        except Exception as e:
            self.log_text.append(f"Error creating combined report: {e}")

        def open_combined():
            if not combined_path or not os.path.exists(combined_path):
                QMessageBox.warning(self, "Error", "Combined report is not available.")
                return
            try:
                os.startfile(combined_path)
            except Exception as ee:
                QMessageBox.warning(self, "Error", f"Could not open Excel file: {ee}")

        self.summary_dialog = SummaryDialog(self, table_rows, open_combined)
        self.summary_dialog.exec()

    def _create_combined_excel_report(self, results):
        # Use the same output folder as CombinedDetectorController, if available,
        # so that Analysis_Report.xlsx is always stored under PUC_Crop_Image_Result\<timestamp>_Check_Result.
        root = getattr(self.controller, "run_output_folder", self.selected_folder)
        if not root:
            return None, []

        from openpyxl import load_workbook as _lw
        combined_path = os.path.join(root, "Analysis_Report.xlsx")
        if os.path.exists(combined_path):
            wb = _lw(combined_path)
            if "Summary" in wb.sheetnames:
                ws = wb["Summary"]
                ws.delete_rows(1, ws.max_row)
            else:
                ws = wb.create_sheet("Summary", 0)
        else:
            wb = Workbook()
            ws = wb.active
            ws.title = "Summary"

        headers = ["Detector", "Total Camera", "Camera List"]
        header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        header_font = Font(size=12, bold=True, color="333333")
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=1, column=col_idx)
            c.alignment = Alignment(horizontal='center', vertical='center')
            c.fill = header_fill
            c.font = header_font
            c.border = thin_border
            ws.column_dimensions[get_column_letter(col_idx)].width = 30 if col_idx != 3 else 60

        total_cameras = 0
        if os.path.exists(root):
            total_cameras = len([f for f in os.listdir(root) if os.path.isdir(os.path.join(root, f)) 
                                and f not in ["Hotpixel_Analysis_Results", "CCD_Analysis_Results", "Dust_Analysis_Results", "Hiaa_Analysis_Results",
                                              "Bubble_Analysis_Results", "LShape_Analysis_Results", "Top_Edge_Analysis_Results"]])

        table_rows = []
        error_ratios = []

        def add_row(name, folders):
            folders_sorted = sorted(set(folders)) if folders else []
            error_count = len(folders_sorted)
            camera_count_text = f"{error_count} / {total_cameras}" if total_cameras > 0 else str(error_count)
            ws.append([name, camera_count_text, "\n".join(folders_sorted)])
            row = ws.max_row
            
            if total_cameras > 0:
                error_ratio = error_count / total_cameras
            else:
                error_ratio = 0.0
            error_ratios.append(error_ratio)
            
            for col in range(1, len(headers) + 1):
                cell = ws.cell(row=row, column=col)
                cell.alignment = Alignment(horizontal='left', vertical='top', wrapText=True)
                cell.border = thin_border
            
            camera_list_text = "\n".join(folders_sorted) if folders_sorted else ""
            table_rows.append([name, camera_count_text, camera_list_text, error_count, total_cameras])

        add_row("HotPixel Checking", results.get('hotpixel', []))
        add_row("CCD Checking", results.get('ccd', []))
        add_row("Bubble Checking", results.get('bubble', []))
        add_row("LShape", results.get('lshape', []))
        add_row("Dust", results.get('dust', []))
        add_row("Hiaa", results.get('hiaa', []))
        add_row("TopEdge", results.get('topedge', []))

        if error_ratios:
            min_ratio = min(error_ratios)
            max_ratio = max(error_ratios)
            
            for i, ratio in enumerate(error_ratios, start=2):
                if max_ratio > min_ratio:
                    normalized = (ratio - min_ratio) / (max_ratio - min_ratio)
                else:
                    normalized = 0.0
                
                red = int(255 * normalized)
                green = int(255 * (1 - normalized))
                blue = int(255 * (1 - normalized))
                
                red = min(255, max(200, red))
                green = min(255, max(200, green))
                blue = min(255, max(200, blue))
                
                fill_color = PatternFill(start_color=f"{red:02x}{green:02x}{blue:02x}", 
                                       end_color=f"{red:02x}{green:02x}{blue:02x}", 
                                       fill_type="solid")
                
                total_camera_cell = ws.cell(row=i, column=2)
                total_camera_cell.fill = fill_color
                
                brightness = red * 0.299 + green * 0.587 + blue * 0.114
                if brightness > 180:
                    total_camera_cell.font = Font(bold=True, color="000000")
                else:
                    total_camera_cell.font = Font(bold=True, color="FFFFFF")

        combined_path = os.path.join(root, "Analysis_Report.xlsx")
        wb.save(combined_path)
        self.log_text.append(f"Combined report saved: {combined_path}")
        return combined_path, table_rows

    def _try_copy_report(self, src_path, dest_wb, expected_sheet_name):
        return

    def _try_merge_reports_with_excel_com(self, combined_path, src_list):
        return

    def closeEvent(self, event):
        if self.main_app_window:
            self.main_app_window.setEnabled(True)
            self.main_app_window.remove_blur_effect()
        super().closeEvent(event)

    def manage_models(self):
        dialog = ModelManagementDialog(self.models_config.copy(), self)
        if dialog.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            updated = load_model_config()
            self.models_config = updated.get("models", {})
            last = updated.get("last_selected_model")
            self.combo_model_selection.clear()
            self.combo_model_selection.addItems(list(self.models_config.keys()))
            if last and last in self.models_config:
                self.combo_model_selection.setCurrentText(last)
                self.selected_model = last
            elif self.models_config:
                self.combo_model_selection.setCurrentIndex(0)
                self.selected_model = self.combo_model_selection.currentText()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())