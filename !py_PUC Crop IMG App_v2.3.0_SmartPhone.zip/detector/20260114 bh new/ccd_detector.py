import os
import sys
import math
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from PIL import Image, ImageDraw
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, 
    QLabel, QTextEdit, QFileDialog, QProgressBar, QMessageBox, 
    QHBoxLayout, QFrame, QGraphicsDropShadowEffect, QFormLayout, QDialog
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
import openpyxl
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill, Border, Side, Font # Import Border, Side, Font
import re
import rc.icons
from PyQt6 import QtCore, QtGui, QtWidgets
import json
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

# Config file for models
CONFIG_FILE = "models_config.json"

def load_model_config():
    """Loads model configuration from JSON file."""
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            config = json.load(f)
            # Ensure default structure if old config is loaded
            if "models" not in config: # Handle old config format
                return {"models": config, "last_selected_model": next(iter(config)) if config else None}
            return config
    default_models = {"D965": 721, "D914": 737, "D967": 699, "D970": 888}
    return {"models": default_models, "last_selected_model": "D965"}

def save_model_config(config_data):
    """Saves model configuration to JSON file."""
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config_data, f, indent=4)

# Slope threshold for error detection default
SLOPE_THRESHOLD = 0.006

# Padding size for error bounding box
BOUNDING_BOX_PADDING = 18

# Scale factors for images and plots in Excel (0.0 to 1.0)
IMAGE_SCALE_FACTOR = 0.18

class CCDChecker(QThread):
    # Signals to update progress and log
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)

    # Define dynamic thresholds based on PTN color and direction
    _THRESHOLDS = {
        'B': {'horizontal': {'slope': 0.005, 'deviation': 3.0},
              'vertical': {'slope': 0.005, 'deviation': 3.0}},
        'G': {'horizontal': {'slope': 0.007, 'deviation': 3.0},
              'vertical': {'slope': 0.007, 'deviation': 3.0}},
        'R': {'horizontal': {'slope': 0.008, 'deviation': 3.0},
              'vertical': {'slope': 0.008, 'deviation': 3.0}},
    }

    def __init__(self, root_folder, model_name, models_config):
        super().__init__()
        self.root_folder = root_folder
        self.model_name = model_name
        self.models_config = models_config
        self.temp_files_to_delete = []
        self.all_profile_data = []  # Store all profile data for CSV export

    def _get_ptn_color(self, ptn_code):
        """Extracts the color (B, G, R) from a PTN code like 'step01_0300NIT_R192' or 'R192'."""
        if not ptn_code:
            return None
        
        # Use regex to find the color channel before the values ​​192 or 216
        match = re.search(r'([BGR])(192|216)', ptn_code, re.IGNORECASE)
        if match:
            return match.group(1).upper()
        return None

    def _is_valid_step_file(self, filename):
        """Check if filename contains step01 to step09"""
        return re.search(r'step0[1-9]', filename, re.IGNORECASE) is not None

    def _has_valid_ptn_number(self, filename):
        """Only accept files with 192 or 216 characters"""
        return re.search(r'(192|216)', filename) is not None

    def _describe_missing_image_reason(self, stats):
        """Generate human-readable reason when no valid TIFF images are available"""
        if not stats.get("has_any_tiff"):
            return "No TIFF images found in folder"
        if not stats.get("has_valid_step"):
            return "No matching step01-step09 images found"
        if not stats.get("has_valid_ptn"):
            return "No images containing 192 or 216 found"
        return "No eligible TIFF images for checking"

    def run(self):
        try:
            import matplotlib
            matplotlib.use('Agg') # Use non-interactive backend for Matplotlib
            
            # Get all subfolders
            folders = self.get_subfolders_with_tiff_images(self.root_folder)
            if not folders:
                self.update_log.emit("No folders with TIFF images found!")
                self.finished.emit([])
                return

            self.update_log.emit(f"Found {len(folders)} folders to process")
            all_results = {}
            all_ccd_folders = {}
            all_best_images = {}
            folder_status_notes = []
            all_processed_folders = set()  # Track all folders that have been checked
            
            total_folders = len(folders)
            processed_folders = 0
            
            for folder_path in folders:
                folder_name = os.path.basename(folder_path)
                all_processed_folders.add(folder_name)  # Track this folder as processed
                self.update_log.emit(f"Processing folder: {folder_name}")
                
                # Check if folder exists and is accessible
                if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
                    folder_status_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": "Folder not accessible or does not exist",
                        "details": ""
                    })
                    processed_folders += 1
                    progress = int((processed_folders / total_folders) * 100)
                    self.update_progress.emit(progress)
                    continue
                
                # Process images in this folder
                try:
                    images, image_stats = self.read_tiff_images(folder_path)
                except Exception as e:
                    folder_status_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": f"Error reading folder: {str(e)}",
                        "details": ""
                    })
                    processed_folders += 1
                    progress = int((processed_folders / total_folders) * 100)
                    self.update_progress.emit(progress)
                    continue
                
                if not images:
                    reason = self._describe_missing_image_reason(image_stats)
                    folder_status_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": reason,
                        "details": ""
                    })
                    self.update_log.emit(f"No TIFF images found in {folder_name}!")
                    processed_folders += 1
                    progress = int((processed_folders / total_folders) * 100)
                    self.update_progress.emit(progress)
                    continue
                
                results, ccd_folders, best_images, processed_images = self.process_all_images(images, folder_path)
                
                # Collect results
                all_results.update(results)
                all_ccd_folders.update(ccd_folders)
                all_best_images.update(best_images)

                # Always add folder to notes if it doesn't have CCD or best images
                if folder_name not in best_images:
                    note_status = "No valid 192/216 images after filtering" if processed_images == 0 else "No CCD detected"
                    detail = "" if processed_images == 0 else f"Processed {processed_images} valid images"
                    folder_status_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": note_status,
                        "details": detail
                    })
                
                processed_folders += 1
                progress = int((processed_folders / total_folders) * 100)
                self.update_progress.emit(progress)
            
            # Export results to Excel - pass all processed folders to ensure all are included
            self.update_log.emit(f"Total folders processed: {len(all_processed_folders)}")
            self.update_log.emit(f"Folders with CCD: {len(all_best_images)}")
            self.update_log.emit(f"Folders in status notes: {len(folder_status_notes)}")
            excel_report_path, folders_with_ccd = self.export_to_excel(
                all_results, all_ccd_folders, all_best_images, self.root_folder, folder_status_notes, all_processed_folders
            )
            
            self.update_progress.emit(100)
            self.finished.emit(folders_with_ccd)
            
        except Exception as e:
            self.update_log.emit(f"Error: {str(e)}")
            self.finished.emit([])

    def get_subfolders_with_tiff_images(self, root_folder):
        """Get all immediate subfolders of root_folder (excluding analysis results folders).
        Include ALL folders so that folders without images can also be reported."""
        folders_to_process = []
        # Skip analysis results folders when exporting report
        excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
        
        for item in os.listdir(root_folder):
            path = os.path.join(root_folder, item)
            if os.path.isdir(path):
                # Skip analysis results folders
                if os.path.basename(path) in excluded_folders:
                    continue
                
                # Include ALL folders (not just those with TIFF images)
                # This ensures folders without images are also processed and reported
                folders_to_process.append(path)
        
        return folders_to_process

    def _has_relevant_tiff_images_in_folder(self, folder_path):
        """Helper to check if a folder directly contains relevant TIFF images or its immediate subfolders do."""
        # Check direct level
        for file in os.listdir(folder_path):
            if (file.lower().endswith(('.tif', '.tiff')) and 
                self._has_valid_ptn_number(file) and 
                self._is_valid_step_file(file) and 
                '_ori.tif' not in file.lower()):
                return True
        
        # If no direct TIFFs, check one level deeper into immediate subfolders
        excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
        for item in os.listdir(folder_path):
            subfolder_path = os.path.join(folder_path, item)
            if os.path.isdir(subfolder_path) and os.path.basename(subfolder_path) not in excluded_folders:
                for file in os.listdir(subfolder_path):
                    if (file.lower().endswith(('.tif', '.tiff')) and 
                        self._has_valid_ptn_number(file) and 
                        self._is_valid_step_file(file) and 
                        '_ori.tif' not in file.lower()):
                        return True
                        
        return False

    def _extract_ptn_from_subfolder_name(self, subfolder_name):
        """Extracts the PTN prefix from a subfolder name"""
        match = re.match(r'([A-Z0-9]+)_.*', subfolder_name)
        if match:
            return match.group(1)
        return None

    def read_tiff_images(self, folder_path):
        """Read all 16-bit TIFF images in the folder that contain valid PTN numbers and step patterns, handling nested images.

        Returns (images, stats) describing why images might be missing.
        """
        tiff_files = []
        has_any_tiff = False
        has_valid_step = False
        has_valid_ptn = False

        for file in os.listdir(folder_path):
            file_lower = file.lower()
            if file_lower.endswith(('.tif', '.tiff')):
                if '_ori.tif' in file_lower:
                    has_any_tiff = True
                    continue

                has_any_tiff = True
                valid_step = self._is_valid_step_file(file)
                valid_ptn = self._has_valid_ptn_number(file)
                has_valid_step = has_valid_step or valid_step
                has_valid_ptn = has_valid_ptn or valid_ptn

                if valid_step and valid_ptn:
                    tiff_files.append(os.path.join(folder_path, file))
        
        # If no TIFF files are found directly, check one level deeper and copy them out
        if not tiff_files:
            self.update_log.emit(f"No direct TIFF images found in {os.path.basename(folder_path)}. Checking subfolders...")
            for item in os.listdir(folder_path):
                subfolder_path = os.path.join(folder_path, item)
                if os.path.isdir(subfolder_path):
                    for file in os.listdir(subfolder_path):
                        file_lower = file.lower()
                        if file_lower.endswith(('.tif', '.tiff')):
                            if '_ori.tif' in file_lower:
                                has_any_tiff = True
                                continue

                            has_any_tiff = True
                            valid_step = self._is_valid_step_file(file)
                            valid_ptn = self._has_valid_ptn_number(file)
                            has_valid_step = has_valid_step or valid_step
                            has_valid_ptn = has_valid_ptn or valid_ptn

                            if valid_step and valid_ptn:
                                original_nested_file_path = os.path.join(subfolder_path, file)
                                
                                # Remove '_imgY_Crop' from filename if present
                                cleaned_filename = file.replace('_imgY_Crop', '')
                                
                                # Extract PTN from subfolder name and prepend it to the filename
                                ptn_prefix = self._extract_ptn_from_subfolder_name(os.path.basename(subfolder_path))
                                if ptn_prefix:
                                    new_filename = f"{ptn_prefix}_{cleaned_filename}"
                                else:
                                    new_filename = cleaned_filename
                                    
                                destination_path = os.path.join(folder_path, new_filename)
                                
                                try:
                                    # Copy the file to the current folder_path
                                    shutil.copy2(original_nested_file_path, destination_path)
                                    tiff_files.append(destination_path) # Add the copied file to our list
                                    self.temp_files_to_delete.append(destination_path) # Mark for deletion
                                    self.update_log.emit(f"Copied and renamed nested TIFF: {original_nested_file_path} -> {destination_path}")
                                except Exception as e:
                                    self.update_log.emit(f"Error copying file {original_nested_file_path}: {e}")
        
        images = {}
        self.update_log.emit(f"Found {len(tiff_files)} relevant TIFF images in {os.path.basename(folder_path)}. Reading...")
        for file_path in tiff_files:
            try:
                img = Image.open(file_path)
                img_array = np.array(img)
                relative_path = os.path.relpath(file_path, self.root_folder)
                images[relative_path] = {
                    'array': img_array,
                    'full_path': file_path,
                    'folder': os.path.basename(os.path.dirname(relative_path)),
                    'filename': os.path.basename(file_path)
                }
            except Exception as e:
                self.update_log.emit(f"Error reading {file_path}: {e}")
        self.update_log.emit(f"Finished reading {len(images)} images from {os.path.basename(folder_path)}.")
        stats = {
            "has_any_tiff": has_any_tiff,
            "has_valid_step": has_valid_step,
            "has_valid_ptn": has_valid_ptn
        }
        return images, stats

    def process_all_images(self, images, folder_path):
        """Process all images in a single folder and return results"""
        results = {}
        folder_ccd_status = {}  # Track CCD status by folder and PTN
        
        total_images = len(images)
        processed_images = 0
        folder_name = os.path.basename(folder_path)
        
        for img_rel_path, img_info in images.items():
            img_name = img_info['filename']
            
            # Extract PTN from filename
            ptn = self.extract_ptn_from_filename(img_name)
            if ptn is None:
                self.update_log.emit(f"Skipping image (no valid PTN found): {img_rel_path}")
                continue
            
            image = img_info['array']

            # Extract PTN color
            ptn_color = self._get_ptn_color(ptn)
            if ptn_color is None:
                self.update_log.emit(f"Skipping image (unknown PTN color): {img_rel_path}")
                continue
            
            processed_images += 1
            self.update_log.emit(f"Processing image {processed_images}/{total_images} in {folder_name}: {img_name}")
            
            # Save original image path
            original_image_path = img_info['full_path']
            
            # Create subfolder CCD Analysis Results in the root folder
            ccd_analysis_results_folder = os.path.join(self.root_folder, "CCD_Analysis_Results")
            os.makedirs(ccd_analysis_results_folder, exist_ok=True)

            # Divide image
            division_info = self.divide_image(image)
            center_y = division_info['horizontal_line']
            vertical_lines = division_info['vertical_lines']
            
            # Calculate horizontal line data (4x3 = 12 intervals)
            horizontal_data_result = self.calculate_horizontal_data(image, center_y, vertical_lines, ptn_color)
            
            # Calculate data for 3 vertical lines (3 lines x 2x3 = 18 intervals)
            vertical_data_all_result = {}
            for i, vertical_line in enumerate(vertical_lines):
                vertical_data_result = self.calculate_vertical_data(image, vertical_line, center_y, ptn_color)
                for key, value in vertical_data_result.items():
                    vertical_data_all_result[f'line_{i+1}_{key}'] = value
            
            all_error_coords_for_marking = [] # đánh dấu trên ảnh
            all_error_data_for_cropping = [] # tìm max slope và crop
            horizontal_errors = 0
            vertical_errors = 0
            
            # Collect all error coordinates and slope values from horizontal data
            for key, data_obj in horizontal_data_result.items():
                for idx, slope_val in enumerate(data_obj['slopes']):
                    if idx < len(data_obj['errors']):
                        error_coord = data_obj['errors'][idx]
                        all_error_coords_for_marking.append(error_coord)
                        all_error_data_for_cropping.append((error_coord, slope_val))
                        horizontal_errors += 1 # Increment horizontal_errors
                horizontal_data_result[key] = data_obj['slopes'] # Keep only slopes for final result

            # Collect all error coordinates and slope values from vertical data
            for key, data_obj in vertical_data_all_result.items():
                for idx, slope_val in enumerate(data_obj['slopes']):
                    if idx < len(data_obj['errors']):
                        error_coord = data_obj['errors'][idx]
                        all_error_coords_for_marking.append(error_coord)
                        all_error_data_for_cropping.append((error_coord, slope_val))
                        vertical_errors += 1 # Increment vertical_errors
                vertical_data_all_result[key] = data_obj['slopes'] # Keep only slopes for final result
            
            # Calculate error severity
            severity_score = self.calculate_error_severity(horizontal_data_result, vertical_data_all_result, ptn_color)
            
            self.update_log.emit(f"[{img_name}] Total errors detected: {len(all_error_coords_for_marking)}")
            self.update_log.emit(f"[{img_name}] Horizontal errors: {horizontal_errors}, Vertical errors: {vertical_errors}")
            self.update_log.emit(f"[{img_name}] Severity score: {severity_score:.6f}")
            
            cropped_error_path = None
            if all_error_data_for_cropping: # Nếu có lỗi, tạo ảnh crop
                height, width = image.shape
                cropped_error_path = self.save_cropped_error_region(
                    original_image_path, 
                    all_error_data_for_cropping, 
                    ccd_analysis_results_folder,
                    img_name,
                    height, width
                )

            if all_error_coords_for_marking:
                self.update_log.emit(f"[{img_name}] First error coordinates: {all_error_coords_for_marking[0]}")
                
                # Update folder CCD status - now organized by PTN
                if folder_name not in folder_ccd_status:
                    folder_ccd_status[folder_name] = {}
                
                # Use PTN as the key instead of grouping all 192/216 together
                if ptn not in folder_ccd_status[folder_name]:
                    folder_ccd_status[folder_name][ptn] = {
                        'count': 0, 
                        'images': [],
                        'error_regions': self.get_error_regions(all_error_coords_for_marking)
                    }
                
                folder_ccd_status[folder_name][ptn]['count'] += 1
                folder_ccd_status[folder_name][ptn]['images'].append({
                    'path': img_rel_path,
                    'severity': severity_score,
                    'error_regions': self.get_error_regions(all_error_coords_for_marking),
                    'ptn': ptn 
                })

            # Extract resolution information
            img_height, img_width = image.shape[:2]
            resolution = f"{img_width}x{img_height}"
            
            # Get PTN color for threshold info
            ptn_color = self._get_ptn_color(ptn)
            slope_threshold = SLOPE_THRESHOLD
            deviation_threshold = 3.0
            if ptn_color and ptn_color in self._THRESHOLDS:
                slope_threshold = self._THRESHOLDS[ptn_color]['horizontal']['slope']
                deviation_threshold = self._THRESHOLDS[ptn_color]['horizontal']['deviation']
            
            # Save profile information for CSV
            self.all_profile_data.append({
                "Folder": folder_name,
                "File Name": img_name,
                "Pattern": ptn if ptn else "Unknown",
                "Resolution": resolution,
                "Model": self.model_name,
                "PTN Color": ptn_color if ptn_color else "Unknown",
                "Slope Threshold": slope_threshold,
                "Deviation Threshold": deviation_threshold,
                "Horizontal Errors": horizontal_errors,
                "Vertical Errors": vertical_errors,
                "Total Errors": len(all_error_coords_for_marking),
                "Severity Score": severity_score,
                "Has CCD": "Yes" if len(all_error_coords_for_marking) > 0 else "No",
                "Status": "CCD Detected" if len(all_error_coords_for_marking) > 0 else "OK"
            })
            
            # Combine data and error coordinates
            results[img_rel_path] = {
                'horizontal_data': horizontal_data_result,
                'vertical_data': vertical_data_all_result,
                'error_coords': all_error_coords_for_marking,
                'original_path': original_image_path,
                'folder': folder_name,
                'ptn': ptn,
                'has_ccd': len(all_error_coords_for_marking) > 0,
                'horizontal_errors': horizontal_errors,
                'vertical_errors': vertical_errors,
                'severity_score': severity_score,
                'error_regions': self.get_error_regions(all_error_coords_for_marking),
                'cropped_error_path': cropped_error_path # Add cropped image path to results
            }
        
        # Determine which folders have CCD issues (ít nhất 3 ảnh cùng PTN có CCD tại vị trí tương tự)
        ccd_folders = {}
        best_images = {}  # Track the best image for each PTN in each folder
        
        for folder_name, ptn_data in folder_ccd_status.items():
            for ptn, data in ptn_data.items():
                if data['count'] >= 3:  # Cần ít nhất 3 ảnh cùng PTN
                    # Check if at least 3 images have similar error regions
                    similar_error_count = 0
                    image_list = data['images']
                    
                    # Kiểm tra từng cặp ảnh để tìm vùng lỗi tương tự
                    for i in range(len(image_list)):
                        for j in range(i + 1, len(image_list)):
                            if self.check_similar_error_regions(image_list[i]['error_regions'], image_list[j]['error_regions']):
                                similar_error_count += 1
                                if similar_error_count >= 2:  # Chỉ cần 2 cặp tương đương với 3 ảnh
                                    break
                        if similar_error_count >= 2:
                            break
                    
                    if similar_error_count >= 2:  # Ít nhất 2 cặp có lỗi tương tự
                        if folder_name not in ccd_folders:
                            ccd_folders[folder_name] = []
                            best_images[folder_name] = {}
                        
                        # Tìm ảnh có severity cao nhất trong PTN này
                        max_severity = -1
                        best_image_path = None
                        for img_info in data['images']:
                            if img_info['severity'] > max_severity:
                                max_severity = img_info['severity']
                                best_image_path = img_info['path']
                        
                        ccd_folders[folder_name].append(ptn)
                        best_images[folder_name][ptn] = best_image_path
                        self.update_log.emit(f"CCD detected in folder '{folder_name}' for PTN '{ptn}' with {data['count']} images")
                        self.update_log.emit(f"Best image: {best_image_path} with severity {max_severity:.6f}")
                        self.update_log.emit(f"Similar error regions found in {similar_error_count} image pairs")
        
        return results, ccd_folders, best_images, processed_images

    def divide_image(self, image):
        """Divide image into 8 parts using special lines"""
        height, width = image.shape
        
        # Use the models_config from MainWindow instead of hardcoded values
        # Get the offset for the current model, default to 721 if not found
        offset = self.models_config.get(self.model_name, 721)
        
        # Find center and ±offset lines
        center_x = width // 2
        center_y = height // 2
        
        line1_x = center_x - offset
        line2_x = center_x
        line3_x = center_x + offset
        
        return {
            'horizontal_line': center_y,
            'vertical_lines': [line1_x, line2_x, line3_x]
        }

    def divide_interval_into_three(self, start, end):
        """Divide an interval into three equal sub-intervals"""
        interval_length = end - start
        sub_interval_length = interval_length / 3
        
        sub_intervals = [
            (start, start + sub_interval_length),
            (start + sub_interval_length, start + 2 * sub_interval_length),
            (start + 2 * sub_interval_length, end)
        ]
        
        return sub_intervals

    def calculate_slope_for_region(self, region_data, is_horizontal=True, ptn_color=None):
        """Calculate data slope for a region and return error positions"""
        if is_horizontal:
            # For horizontal line: calculate average by row
            averages = np.mean(region_data, axis=1)
        else:
            # For vertical line: calculate average by column
            averages = np.mean(region_data, axis=0)
        
        slopes = []
        error_indices = []
        
        # Get the appropriate thresholds
        slope_threshold = SLOPE_THRESHOLD # Fallback to global if ptn_color not provided or not in config
        deviation_threshold = 3.0 # Fallback to default if ptn_color not provided or not in config

        if ptn_color and ptn_color in self._THRESHOLDS:
            direction_key = 'horizontal' if is_horizontal else 'vertical'
            if direction_key in self._THRESHOLDS[ptn_color]:
                slope_threshold = self._THRESHOLDS[ptn_color][direction_key]['slope']
                deviation_threshold = self._THRESHOLDS[ptn_color][direction_key]['deviation']

        for j in range(len(averages) - 5):
            avg_first_3 = np.mean(averages[j:j+3])
            avg_next_3 = np.mean(averages[j+3:j+6])
            avg_all_6 = np.mean(averages[j:j+6])
            
            if avg_all_6 > 0:
                slope = abs(avg_first_3 - avg_next_3) / avg_all_6
            else:
                slope = 0
            slopes.append(slope)
        
        # Calculate average of all slopes in this region
        if slopes:
            avg_slope_region = np.mean(slopes)
            
            # Check for errors using the new condition
            for j, slope_val in enumerate(slopes):
                # Condition 1: slope value is above threshold
                condition1 = slope_val > slope_threshold
                
                # Condition 2: (slope_val - avg_slope_region) / avg_slope_region > deviation_threshold
                condition2 = False
                if avg_slope_region > 0:
                    relative_deviation = (slope_val - avg_slope_region) / avg_slope_region
                    condition2 = relative_deviation > deviation_threshold
                
                # Both conditions must be met for error detection
                if condition1 and condition2:
                    error_indices.append(j)
                    self.update_log.emit(f"Error detected at index {j}: slope={slope_val:.6f}, "
                                    f"avg_region={avg_slope_region:.6f}, "
                                    f"relative_deviation={relative_deviation:.2f}")
        
        return slopes, error_indices


    def calculate_horizontal_data(self, image, center_y, vertical_lines, ptn_color):
        """Calculate data for horizontal line divided into 3 sub-intervals"""
        height, width = image.shape
        horizontal_data = {}
        
        # Get 41 rows around the horizontal line (20 above + 1 at line + 20 below)
        start_row = max(0, center_y - 20)
        end_row = min(height, center_y + 21)
        horizontal_region = image[start_row:end_row, :]
        
        # Divide into 4 large horizontal segments based on vertical lines
        large_intervals = [
            (0, vertical_lines[0]),
            (vertical_lines[0], vertical_lines[1]),
            (vertical_lines[1], vertical_lines[2]),
            (vertical_lines[2], width)
        ]
        
        for i, (start_col, end_col) in enumerate(large_intervals):
            # Divide each large interval into 3 sub-intervals
            sub_intervals = self.divide_interval_into_three(start_col, end_col)
            
            for j, (sub_start, sub_end) in enumerate(sub_intervals):
                segment_key = f'horizontal_segment_{i+1}_sub_{j+1}'
                
                # Skip error detection for horizontal_segment_1_sub_1
                skip_error_detection = (segment_key == 'horizontal_segment_1_sub_1')
                
                # Get the part of horizontal region corresponding to this sub-interval
                sub_region = horizontal_region[:, int(sub_start):int(sub_end)]
                
                # Calculate data slope for this sub-interval
                slopes, error_indices = self.calculate_slope_for_region(sub_region, is_horizontal=True, ptn_color=ptn_color)
                
                horizontal_data[segment_key] = {
                    'slopes': slopes,
                    'errors': []
                }
                
                # Skip error coordinate conversion for horizontal_segment_1_sub_1
                if skip_error_detection:
                    self.update_log.emit(f"Skipping error detection for {segment_key}")
                    continue
                
                # Convert error indices to actual pixel coordinates (only for non-skipped segments)
                for error_idx in error_indices:
                    # Pixel y position (row) in original image
                    pixel_y_center = start_row + error_idx
                    original_pixel_y_start = max(0, pixel_y_center - 2)
                    original_pixel_y_end = min(height, pixel_y_center + 3)
                    
                    # Pixel x position (column) in original image - entire sub-interval
                    original_pixel_x_start = int(sub_start)
                    original_pixel_x_end = int(sub_end)
                    
                    # Apply padding
                    padded_pixel_x_start = max(0, original_pixel_x_start - BOUNDING_BOX_PADDING)
                    padded_pixel_x_end = min(width, original_pixel_x_end + BOUNDING_BOX_PADDING)
                    padded_pixel_y_start = max(0, original_pixel_y_start - BOUNDING_BOX_PADDING)
                    padded_pixel_y_end = min(height, original_pixel_y_end + BOUNDING_BOX_PADDING)
                    
                    horizontal_data[segment_key]['errors'].append(
                        ((padded_pixel_x_start, padded_pixel_y_start), (padded_pixel_x_end, padded_pixel_y_end))
                    )
        
        return horizontal_data

    def calculate_vertical_data(self, image, vertical_line, center_y, ptn_color):
        """Calculate data for a vertical line divided into 3 sub-intervals"""
        height, width = image.shape
        vertical_data = {}
        
        # Get 41 columns around the vertical line (20 left + 1 at line + 20 right)
        start_col = max(0, vertical_line - 20)
        end_col = min(width, vertical_line + 21)
        vertical_region = image[:, start_col:end_col]
        
        # Divide into 2 large vertical segments based on horizontal line
        large_intervals = [
            (0, center_y),
            (center_y, height)
        ]
        
        for i, (start_row, end_row) in enumerate(large_intervals):
            # Divide each large interval into 3 sub-intervals
            sub_intervals = self.divide_interval_into_three(start_row, end_row)
            
            for j, (sub_start, sub_end) in enumerate(sub_intervals):
                # Get the part of vertical region corresponding to this sub-interval
                sub_region = vertical_region[int(sub_start):int(sub_end), :]
                
                # Calculate data slope for this sub-interval
                slopes, error_indices = self.calculate_slope_for_region(sub_region, is_horizontal=False, ptn_color=ptn_color)
                
                vertical_data[f'vertical_segment_{i+1}_sub_{j+1}'] = {
                    'slopes': slopes,
                    'errors': []
                }
                
                # Convert error indices to actual pixel coordinates
                for error_idx in error_indices:
                    # Pixel x position (column) in original image
                    pixel_x_center = start_col + error_idx
                    original_pixel_x_start = max(0, pixel_x_center - 2)
                    original_pixel_x_end = min(width, pixel_x_center + 3)
                    
                    # Pixel y position (row) in original image - entire sub-interval
                    original_pixel_y_start = int(sub_start)
                    original_pixel_y_end = int(sub_end)
                    
                    # Apply padding
                    padded_pixel_x_start = max(0, original_pixel_x_start - BOUNDING_BOX_PADDING)
                    padded_pixel_x_end = min(width, original_pixel_x_end + BOUNDING_BOX_PADDING)
                    padded_pixel_y_start = max(0, original_pixel_y_start - BOUNDING_BOX_PADDING)
                    padded_pixel_y_end = min(height, original_pixel_y_end + BOUNDING_BOX_PADDING)
                    
                    vertical_data[f'vertical_segment_{i+1}_sub_{j+1}']['errors'].append(
                        ((padded_pixel_x_start, padded_pixel_y_start), (padded_pixel_x_end, padded_pixel_y_end))
                    )
        
        return vertical_data

    def mark_image_with_errors(self, original_image_path, error_coords_list, output_folder, img_name):
        """Mark error regions on the original image and save"""
        try:
            img = Image.open(original_image_path)
            # Convert 16-bit image to 8-bit grayscale or RGB for drawing
            if img.mode == 'I;16':
                img_array = np.array(img, dtype=np.float32)
                img_array -= img_array.min()
                img_array /= img_array.max()
                img_array *= 255.0
                img = Image.fromarray(img_array.astype(np.uint8), mode='L').convert('RGB')
            elif img.mode == 'L':  # 8-bit Grayscale
                img = img.convert('RGB')
            
            draw = ImageDraw.Draw(img)
            
            for (x1, y1), (x2, y2) in error_coords_list:
                # Draw red rectangle around error region with 3-pixel width
                draw.rectangle([(x1, y1), (x2, y2)], outline="red", width=3)
            
            if not os.path.exists(output_folder):
                os.makedirs(output_folder)
            
            marked_image_path = os.path.join(output_folder, f"{os.path.splitext(img_name)[0]}_marked.jpg")
            # Save with high quality
            img.save(marked_image_path, quality=95)
            self.update_log.emit(f"Saved marked image: {marked_image_path}")
            
            # Create a scaled version for Excel with high quality
            new_width = int(img.width * IMAGE_SCALE_FACTOR)
            new_height = int(img.height * IMAGE_SCALE_FACTOR)
            
            # Use high-quality resampling
            scaled_img = img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            scaled_image_path = os.path.join(output_folder, f"{os.path.splitext(img_name)[0]}_marked_scaled.jpg")
            # Save with maximum quality
            scaled_img.save(scaled_image_path, quality=100, optimize=True)
            self.temp_files_to_delete.append(scaled_image_path) # Thêm vào danh sách xóa
            
            return marked_image_path, scaled_image_path, img.size
        except Exception as e:
            self.update_log.emit(f"Error marking image {original_image_path}: {e}")
            return None, None, None

    def save_cropped_error_region(self, original_image_path, all_error_data_for_cropping, output_folder, img_name, height, width):
        """Save a cropped image of the region with the highest slope within the error regions"""
        try:
            img = Image.open(original_image_path)
            if img.mode == 'I;16':
                img_array = np.array(img, dtype=np.float32)
                img_array -= img_array.min()
                img_array /= img_array.max()
                img_array *= 255.0
                img = Image.fromarray(img_array.astype(np.uint8), mode='L').convert('RGB')
            elif img.mode == 'L':
                img = img.convert('RGB')
            
            if not all_error_data_for_cropping:
                return None

            # Find the highest slope and its corresponding coordinates
            max_slope_value = -1
            best_error_coord = None
            
            for (error_coord, slope_val) in all_error_data_for_cropping:
                if slope_val > max_slope_value:
                    max_slope_value = slope_val
                    best_error_coord = error_coord

            if best_error_coord is None:
                return None
            
            ((x1, y1), (x2, y2)) = best_error_coord
            
            # Calculate crop region around the error
            crop_center_x = (x1 + x2) // 2
            crop_center_y = (y1 + y2) // 2
            crop_width = 400  # Tăng chiều ngang
            crop_height = 200 # Tăng chiều cao

            left = max(0, crop_center_x - crop_width // 2)
            top = max(0, crop_center_y - crop_height // 2)
            right = min(width, crop_center_x + crop_width // 2)
            bottom = min(height, crop_center_y + crop_height // 2)
            
            cropped_img = img.crop((left, top, right, bottom))
            
            # Create subfolder for cropped images
            crop_output_folder = os.path.join(output_folder, "Cropped_Errors")
            os.makedirs(crop_output_folder, exist_ok=True)
            
            cropped_image_path = os.path.join(crop_output_folder, f"{os.path.splitext(img_name)[0]}_crop_max_slope.jpg")
            cropped_img.save(cropped_image_path, quality=90) # Save with high quality
            self.update_log.emit(f"Saved cropped error image: {cropped_image_path}")
            return cropped_image_path
        except Exception as e:
            self.update_log.emit(f"Error saving cropped error image {original_image_path}: {e}")
            return None

    def extract_ptn_from_filename(self, filename):
        """Extract PTN từ filename, chỉ nhận giá trị 192 hoặc 216"""
        # Look for patterns like step01_0300NIT_R192 hoặc R216
        patterns = [
            r'step\d+_\d+NIT_[RGB](192|216)',  # Pattern like step01_0300NIT_R192
            r'[RGB](192|216)',  # Chỉ phần màu + 192/216 như R192
        ]
        
        for pattern in patterns:
            match = re.search(pattern, filename)
            if match:
                return match.group(0)
        return None

    def calculate_error_severity(self, horizontal_data, vertical_data, ptn_color=None):
        """Calculate error severity based on slope values with new condition"""
        severity_score = 0
        
        # Get the appropriate thresholds for severity calculation
        horizontal_slope_threshold = SLOPE_THRESHOLD
        horizontal_deviation_threshold = 3.0
        vertical_slope_threshold = SLOPE_THRESHOLD
        vertical_deviation_threshold = 3.0

        if ptn_color and ptn_color in self._THRESHOLDS:
            if 'horizontal' in self._THRESHOLDS[ptn_color]:
                horizontal_slope_threshold = self._THRESHOLDS[ptn_color]['horizontal']['slope']
                horizontal_deviation_threshold = self._THRESHOLDS[ptn_color]['horizontal']['deviation']
            if 'vertical' in self._THRESHOLDS[ptn_color]:
                vertical_slope_threshold = self._THRESHOLDS[ptn_color]['vertical']['slope']
                vertical_deviation_threshold = self._THRESHOLDS[ptn_color]['vertical']['deviation']

        # Calculate severity from horizontal data (skip horizontal_segment_1_sub_1)
        for key, slopes in horizontal_data.items():
            # Skip severity calculation for horizontal_segment_1_sub_1
            if key == 'horizontal_segment_1_sub_1':
                continue
                
            if len(slopes) > 0:
                avg_slope = np.mean(slopes)
                
                for slope_val in slopes:
                    # Apply new condition: (slope_val - avg_slope) / avg_slope > deviation_threshold
                    if avg_slope > 0 and slope_val > horizontal_slope_threshold:
                        relative_deviation = (slope_val - avg_slope) / avg_slope
                        if relative_deviation > horizontal_deviation_threshold:
                            severity_score += slope_val
        
        # Calculate severity from vertical data (all vertical segments are processed)
        for key, slopes in vertical_data.items():
            if len(slopes) > 0:
                avg_slope = np.mean(slopes)
                
                for slope_val in slopes:
                    # Apply new condition: (slope_val - avg_slope) / avg_slope > deviation_threshold
                    if avg_slope > 0 and slope_val > vertical_slope_threshold:
                        relative_deviation = (slope_val - avg_slope) / avg_slope
                        if relative_deviation > vertical_deviation_threshold:
                            severity_score += slope_val
        
        return severity_score

    def get_error_regions(self, error_coords):
        """Extract error regions from coordinates"""
        regions = []
        for (x1, y1), (x2, y2) in error_coords:
            regions.append({
                'x1': x1,
                'y1': y1,
                'x2': x2,
                'y2': y2,
                'center_x': (x1 + x2) / 2,
                'center_y': (y1 + y2) / 2
            })
        return regions

    def check_similar_error_regions(self, regions1, regions2, tolerance=40):
        """Check if two sets of error regions are similar within tolerance"""
        if len(regions1) == 0 or len(regions2) == 0:
            return False
        
        # Check if at least one region in each set is similar
        for region1 in regions1:
            for region2 in regions2:
                # Check if centers are within tolerance distance
                distance = np.sqrt((region1['center_x'] - region2['center_x'])**2 + 
                                  (region1['center_y'] - region2['center_y'])**2)
                if distance <= tolerance:
                    return True
        
        return False

    def create_selective_plot_image(self, img_name, horizontal_data, vertical_data, horizontal_errors, vertical_errors, output_folder, ptn_color=None):
        """Create a selective plot image based on which direction has errors with threshold line"""
        
        # Get the appropriate thresholds for plotting
        horizontal_plot_threshold = SLOPE_THRESHOLD
        vertical_plot_threshold = SLOPE_THRESHOLD

        if ptn_color and ptn_color in self._THRESHOLDS:
            if 'horizontal' in self._THRESHOLDS[ptn_color]:
                horizontal_plot_threshold = self._THRESHOLDS[ptn_color]['horizontal']['slope']
            if 'vertical' in self._THRESHOLDS[ptn_color]:
                vertical_plot_threshold = self._THRESHOLDS[ptn_color]['vertical']['slope']
        
        # Determine which plot to create
        if horizontal_errors > 0 and vertical_errors > 0:
            # Both directions have errors - create both plots
            plt.figure(figsize=(10, 8), dpi=150)
            
            # Horizontal plot
            plt.subplot(2, 1, 1)
            colors = plt.cm.tab20(np.linspace(0, 1, len(horizontal_data)))
            for (key, values), color in zip(horizontal_data.items(), colors):
                plt.plot(values, label=key, color=color, linewidth=1.5)
            
            # Add threshold line
            plt.axhline(y=horizontal_plot_threshold, color='r', linestyle='--', linewidth=1, 
                       label=f'Threshold ({horizontal_plot_threshold:.4f})')
            
            plt.title(f'{img_name} - Horizontal Data Slope (12 sub-intervals)')
            plt.xlabel('Position Index')
            plt.ylabel('Slope Value')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.grid(True, alpha=0.3)
            
            # Vertical plot
            plt.subplot(2, 1, 2)
            colors = plt.cm.tab20(np.linspace(0, 1, len(vertical_data)))
            for (key, values), color in zip(vertical_data.items(), colors):
                plt.plot(values, label=key, color=color, linewidth=1.5)
            
            # Add threshold line
            plt.axhline(y=vertical_plot_threshold, color='r', linestyle='--', linewidth=1, 
                       label=f'Threshold ({vertical_plot_threshold:.4f})')
            
            plt.title(f'{img_name} - Vertical Data Slope (18 sub-intervals)')
            plt.xlabel('Position Index')
            plt.ylabel('Slope Value')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
        elif horizontal_errors > 0:
            # Only horizontal errors - create horizontal plot only
            plt.figure(figsize=(10, 4), dpi=150)
            
            colors = plt.cm.tab20(np.linspace(0, 1, len(horizontal_data)))
            for (key, values), color in zip(horizontal_data.items(), colors):
                plt.plot(values, label=key, color=color, linewidth=1.5)
            
            # Add threshold line
            plt.axhline(y=horizontal_plot_threshold, color='r', linestyle='--', linewidth=1, 
                       label=f'Threshold ({horizontal_plot_threshold:.4f})')
            
            plt.title(f'{img_name} - Horizontal Data Slope (12 sub-intervals)')
            plt.xlabel('Position Index')
            plt.ylabel('Slope Value')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.grid(True, alpha=0.3)
            
        elif vertical_errors > 0:
            # Only vertical errors - create vertical plot only
            plt.figure(figsize=(10, 4), dpi=150)
            
            colors = plt.cm.tab20(np.linspace(0, 1, len(vertical_data)))
            for (key, values), color in zip(vertical_data.items(), colors):
                plt.plot(values, label=key, color=color, linewidth=1.5)
            
            # Add threshold line
            plt.axhline(y=vertical_plot_threshold, color='r', linestyle='--', linewidth=1, 
                       label=f'Threshold ({vertical_plot_threshold:.4f})')
            
            plt.title(f'{img_name} - Vertical Data Slope (18 sub-intervals)')
            plt.xlabel('Position Index')
            plt.ylabel('Slope Value')
            plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
            plt.grid(True, alpha=0.3)
        
        else:
            # No errors - no plot needed
            return None, None
        
        # Create subfolder for plots
        plots_output_folder = output_folder
        os.makedirs(plots_output_folder, exist_ok=True)
        
        # Save plot with high quality (removed quality parameter for PNG)
        plot_filename = os.path.join(plots_output_folder, f"{os.path.splitext(img_name)[0]}_selective_plot.png")
        plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
        plt.close()
        self.update_log.emit(f"Saved selective plot: {plot_filename}")
        
        # Create a scaled version for Excel with high quality
        plot_img = Image.open(plot_filename)
        new_width = int(plot_img.width * IMAGE_SCALE_FACTOR)
        new_height = int(plot_img.height * IMAGE_SCALE_FACTOR)
        
        # Use high-quality resampling
        scaled_plot = plot_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        scaled_plot_path = os.path.join(plots_output_folder, f"{os.path.splitext(img_name)[0]}_selective_plot_scaled.png")
        # Save with maximum quality
        scaled_plot.save(scaled_plot_path, optimize=True)
        self.temp_files_to_delete.append(scaled_plot_path) # Thêm file scaled plot vào danh sách xóa
        
        plot_img.close()
        scaled_plot.close()
        
        return plot_filename, scaled_plot_path

    def export_to_excel(self, results, ccd_folders, best_images, folder_path, folder_notes=None, all_processed_folders=None):
        """Export results to Excel file with only the best image for each PTN"""
        output_folder = os.path.join(folder_path, "CCD_Analysis_Results")
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)
        
        # Create Excel workbook
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "CCD Analysis Report"
        # Prepare Summary workbook and sheet
        summary_path = os.path.join(self.root_folder, "Analysis_Report.xlsx")
        if os.path.exists(summary_path):
            summary_wb = _load_wb(summary_path)
        else:
            from openpyxl import Workbook as _WB
            summary_wb = _WB()
            summary_wb.active.title = "Summary"
        if "CCD Analysis Report" in summary_wb.sheetnames:
            s_ws = summary_wb["CCD Analysis Report"]
            summary_wb.remove(s_ws)
            s_ws = summary_wb.create_sheet("CCD Analysis Report")
        else:
            s_ws = summary_wb.create_sheet("CCD Analysis Report")
        
        # Set column headers
        headers = [
            "Folder with CCD", 
            "Detected PTN", 
            "CCD Coordinates", 
            "CCD Status", 
            "Marked Image", 
            "Cropped Error Image", 
            "Plot" # Changed from "Severity Score"
        ]
        
        # Header background color
        header_fill_color = "D9E1F2" # Light blue/grey

        # Font for headers
        header_font = Font(size=12, bold=True, color="333333") # Lớn hơn, đậm hơn
        
        # Border style
        thin_border = Border(left=Side(style='thin'), 
                             right=Side(style='thin'), 
                             top=Side(style='thin'), 
                             bottom=Side(style='thin'))

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.fill = PatternFill(start_color=header_fill_color, end_color=header_fill_color, fill_type="solid")
            cell.font = header_font # Áp dụng font cho header
            cell.border = thin_border # Kẻ bảng cho header
            ws.column_dimensions[get_column_letter(col_idx)].width = 20
            scell = s_ws.cell(row=1, column=col_idx, value=header)
            scell.alignment = Alignment(horizontal='center', vertical='center')
            scell.fill = PatternFill(start_color=header_fill_color, end_color=header_fill_color, fill_type="solid")
            scell.font = header_font
            scell.border = thin_border
            s_ws.column_dimensions[get_column_letter(col_idx)].width = 20
        
        # Process each image result
        row_idx = 2
        
        # Create subfolders for marked images and cropped errors
        marked_images_folder = os.path.join(output_folder, "Marked_Images")
        cropped_errors_folder = os.path.join(output_folder, "Cropped_Errors") 
        plots_output_folder = os.path.join(output_folder, "Plots") # Thêm dòng này
        os.makedirs(marked_images_folder, exist_ok=True)
        os.makedirs(cropped_errors_folder, exist_ok=True) 
        os.makedirs(plots_output_folder, exist_ok=True) # Thêm dòng này
        
        # Track which folders have CCD issues
        folders_with_ccd = set()

        # Colors for alternating folder rows (sáng hơn)
        background_colors = ["E0E0E0", "F8F8F8", "D0E0F8", "F8F0E0"]
        folder_color_map = {}
        color_index = 0

        def calc_status_height(text):
            clean_text = (text or "").strip()
            if not clean_text:
                return 20
            approx_chars_per_line = 30
            lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
            return lines * 18 + 4

        def adjust_status_cells(row_number, status_text, target_ws=ws, summary_ws=s_ws, column_index=4):
            desired_height = calc_status_height(status_text)
            for board in (target_ws, summary_ws):
                cell = board.cell(row=row_number, column=column_index)
                cell.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                current_height = board.row_dimensions[row_number].height if board.row_dimensions[row_number].height is not None else 0
                if desired_height > current_height:
                    board.row_dimensions[row_number].height = desired_height
        
        # Only process the best image for each PTN in each folder
        for folder_name, ptn_best_images in best_images.items():
            if folder_name not in folder_color_map:
                folder_color_map[folder_name] = background_colors[color_index % len(background_colors)]
                color_index += 1

            current_folder_fill = PatternFill(start_color=folder_color_map[folder_name], end_color=folder_color_map[folder_name], fill_type="solid")

            for ptn, best_image_path in ptn_best_images.items():
                if best_image_path in results:
                    data = results[best_image_path]
                    img_name = os.path.basename(best_image_path)
                    
                    folders_with_ccd.add(folder_name)
                    
                    # Column 1: Folder with CCD
                    cell_col1 = ws.cell(row=row_idx, column=1, value=folder_name)
                    cell_col1.alignment = Alignment(horizontal='center', vertical='center')
                    cell_col1.fill = current_folder_fill
                    cell_col1.border = thin_border # Kẻ bảng
                    s_cell_col1 = s_ws.cell(row=row_idx, column=1, value=folder_name)
                    s_cell_col1.alignment = Alignment(horizontal='center', vertical='center')
                    s_cell_col1.fill = current_folder_fill
                    s_cell_col1.border = thin_border
                    
                    # Column 2: Detected PTN
                    cell_col2 = ws.cell(row=row_idx, column=2, value=ptn)
                    cell_col2.alignment = Alignment(horizontal='center', vertical='center')
                    cell_col2.fill = current_folder_fill
                    cell_col2.border = thin_border # Kẻ bảng
                    s_cell_col2 = s_ws.cell(row=row_idx, column=2, value=ptn)
                    s_cell_col2.alignment = Alignment(horizontal='center', vertical='center')
                    s_cell_col2.fill = current_folder_fill
                    s_cell_col2.border = thin_border
                    
                    # Column 3: CCD Coordinates
                    error_coords = data['error_coords']
                    coord_text = "\n".join([f"({start_x},{start_y})-({end_x},{end_y})" for (start_x, start_y), (end_x, end_y) in error_coords[:5]]) # Hiển thị tọa độ chi tiết
                    if len(error_coords) > 5:
                        coord_text += f"\n... and {len(error_coords) - 5} more"
                    cell_col3 = ws.cell(row=row_idx, column=3, value=coord_text)
                    cell_col3.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                    cell_col3.fill = current_folder_fill
                    cell_col3.border = thin_border # Kẻ bảng
                    ws.row_dimensions[row_idx].height = 120  # Adjust row height for coordinates
                    s_cell_col3 = s_ws.cell(row=row_idx, column=3, value=coord_text)
                    s_cell_col3.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                    s_cell_col3.fill = current_folder_fill
                    s_cell_col3.border = thin_border
                    s_ws.row_dimensions[row_idx].height = 120
                    
                    # Column 4: CCD Status
                    status = "CCD Detected"
                    cell_col4 = ws.cell(row=row_idx, column=4, value=status)
                    cell_col4.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                    cell_col4.fill = current_folder_fill
                    cell_col4.border = thin_border # Kẻ bảng
                    s_cell_col4 = s_ws.cell(row=row_idx, column=4, value=status)
                    s_cell_col4.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                    s_cell_col4.fill = current_folder_fill
                    s_cell_col4.border = thin_border
                    adjust_status_cells(row_idx, status)
                    
                    # Column 5: Marked Image (scaled)
                    marked_image_path, scaled_image_path, img_size = self.mark_image_with_errors(
                        data['original_path'], error_coords, marked_images_folder, img_name
                    )
                    
                    if scaled_image_path and os.path.exists(scaled_image_path):
                        try:
                            excel_img = ExcelImage(scaled_image_path)
                            # Read the actual size of the image after scaling to maintain aspect ratio
                            with Image.open(scaled_image_path) as scaled_pil_img:
                                excel_img.width = scaled_pil_img.width
                                excel_img.height = scaled_pil_img.height
                            
                            # Adjust row height and column width based on image size
                            current_row_height = ws.row_dimensions[row_idx].height if ws.row_dimensions[row_idx].height is not None else 0
                            new_row_height = int(excel_img.height / 1.33) + 2 # 1.33 pixel = 1 point
                            ws.row_dimensions[row_idx].height = max(current_row_height, new_row_height)
                            
                            current_col_width = ws.column_dimensions['E'].width if ws.column_dimensions['E'].width is not None else 0
                            new_col_width = int(excel_img.width / 7) + 2 # 7 pixel = 1 unit
                            ws.column_dimensions['E'].width = max(current_col_width, new_col_width)
                            
                            excel_img.anchor = f'E{row_idx}'
                            ws.add_image(excel_img)
                            excel_img2 = ExcelImage(scaled_image_path)
                            with Image.open(scaled_image_path) as scaled_pil_img:
                                excel_img2.width = scaled_pil_img.width
                                excel_img2.height = scaled_pil_img.height
                            # Mirror row height/width for summary
                            s_current_row_height = s_ws.row_dimensions[row_idx].height if s_ws.row_dimensions[row_idx].height is not None else 0
                            s_new_row_height = int(excel_img2.height / 1.33) + 2
                            s_ws.row_dimensions[row_idx].height = max(s_current_row_height, s_new_row_height)
                            s_current_col_width = s_ws.column_dimensions['E'].width if s_ws.column_dimensions['E'].width is not None else 0
                            s_new_col_width = int(excel_img2.width / 7) + 2
                            s_ws.column_dimensions['E'].width = max(s_current_col_width, s_new_col_width)
                            excel_img2.anchor = f'E{row_idx}'
                            s_ws.add_image(excel_img2)
                        except Exception as e:  
                            self.update_log.emit(f"Error adding marked image to Excel: {e}")
                            cell_col5 = ws.cell(row=row_idx, column=5, value=f"Error: {str(e)}")
                            cell_col5.alignment = Alignment(horizontal='center', vertical='center')
                            cell_col5.fill = current_folder_fill
                            cell_col5.border = thin_border # Kẻ bảng
                    else:
                        cell_col5 = ws.cell(row=row_idx, column=5, value="No marked image available")
                        cell_col5.alignment = Alignment(horizontal='center', vertical='center')
                        cell_col5.fill = current_folder_fill
                        cell_col5.border = thin_border # Kẻ bảng
                        s_cell_col5 = s_ws.cell(row=row_idx, column=5, value="No marked image available")
                        s_cell_col5.alignment = Alignment(horizontal='center', vertical='center')
                        s_cell_col5.fill = current_folder_fill
                        s_cell_col5.border = thin_border
                    
                    # Create charts
                    plot_path, scaled_plot_path = self.create_selective_plot_image(
                        img_name, data['horizontal_data'], data['vertical_data'], 
                        data['horizontal_errors'], data['vertical_errors'], plots_output_folder, ptn_color=self._get_ptn_color(data['ptn'])
                    )

                    # Column 6: Cropped Error Image
                    cropped_error_path = data['cropped_error_path']
                    if cropped_error_path and os.path.exists(cropped_error_path):
                        try:
                            excel_cropped_img = ExcelImage(cropped_error_path)
                            excel_cropped_img.width = 300
                            excel_cropped_img.height = 150
                            
                            # Adjust row height and column width
                            # Use slightly larger values ​​to allow for padding around the image
                            current_row_height = ws.row_dimensions[row_idx].height if ws.row_dimensions[row_idx].height is not None else 0
                            new_row_height = int(excel_cropped_img.height / 1.33) + 2 # 1.33 pixel = 1 point
                            ws.row_dimensions[row_idx].height = max(current_row_height, new_row_height)
                            
                            current_col_width = ws.column_dimensions['F'].width if ws.column_dimensions['F'].width is not None else 0
                            new_col_width = int(excel_cropped_img.width / 7) + 2 # 7 pixel = 1 unit
                            ws.column_dimensions['F'].width = max(current_col_width, new_col_width)

                            excel_cropped_img.anchor = f'F{row_idx}'
                            ws.add_image(excel_cropped_img)
                            excel_cropped_img2 = ExcelImage(cropped_error_path)
                            excel_cropped_img2.width = 300
                            excel_cropped_img2.height = 150
                            s_current_row_height = s_ws.row_dimensions[row_idx].height if s_ws.row_dimensions[row_idx].height is not None else 0
                            s_new_row_height = int(excel_cropped_img2.height / 1.33) + 2
                            s_ws.row_dimensions[row_idx].height = max(s_current_row_height, s_new_row_height)
                            s_current_col_width = s_ws.column_dimensions['F'].width if s_ws.column_dimensions['F'].width is not None else 0
                            s_new_col_width = int(excel_cropped_img2.width / 7) + 2
                            s_ws.column_dimensions['F'].width = max(s_current_col_width, s_new_col_width)
                            excel_cropped_img2.anchor = f'F{row_idx}'
                            s_ws.add_image(excel_cropped_img2)
                        except Exception as e:
                            self.update_log.emit(f"Error adding cropped image to Excel: {e}")
                            cell_col6 = ws.cell(row=row_idx, column=6, value=f"Error: {str(e)}")
                            cell_col6.alignment = Alignment(horizontal='center', vertical='center')
                            cell_col6.fill = current_folder_fill
                            cell_col6.border = thin_border
                    else:
                        cell_col6 = ws.cell(row=row_idx, column=6, value="No cropped image available")
                        cell_col6.alignment = Alignment(horizontal='center', vertical='center')
                        cell_col6.fill = current_folder_fill
                        cell_col6.border = thin_border
                        s_cell_col6 = s_ws.cell(row=row_idx, column=6, value="No cropped image available")
                        s_cell_col6.alignment = Alignment(horizontal='center', vertical='center')
                        s_cell_col6.fill = current_folder_fill
                        s_cell_col6.border = thin_border

                    # Column 7: Plot
                    if scaled_plot_path and os.path.exists(scaled_plot_path):
                        try:
                            excel_plot_img = ExcelImage(scaled_plot_path)
                            # Read the actual size of the image after scaling to maintain aspect ratio
                            with Image.open(scaled_plot_path) as scaled_pil_plot_img:
                                excel_plot_img.width = scaled_pil_plot_img.width
                                excel_plot_img.height = scaled_pil_plot_img.height
                            
                            # Adjust row height and column width based on image size
                            current_row_height = ws.row_dimensions[row_idx].height if ws.row_dimensions[row_idx].height is not None else 0
                            new_row_height = int(excel_plot_img.height / 1.33) + 2 # 1.33 pixel = 1 point
                            ws.row_dimensions[row_idx].height = max(current_row_height, new_row_height)
                            
                            current_col_width = ws.column_dimensions['G'].width if ws.column_dimensions['G'].width is not None else 0
                            new_col_width = int(excel_plot_img.width / 7) + 2 # 7 pixel = 1 unit
                            ws.column_dimensions['G'].width = max(current_col_width, new_col_width)
                            
                            excel_plot_img.anchor = f'G{row_idx}'
                            ws.add_image(excel_plot_img)
                            excel_plot_img2 = ExcelImage(scaled_plot_path)
                            with Image.open(scaled_plot_path) as scaled_pil_plot_img:
                                excel_plot_img2.width = scaled_pil_plot_img.width
                                excel_plot_img2.height = scaled_pil_plot_img.height
                            s_current_row_height = s_ws.row_dimensions[row_idx].height if s_ws.row_dimensions[row_idx].height is not None else 0
                            s_new_row_height = int(excel_plot_img2.height / 1.33) + 2
                            s_ws.row_dimensions[row_idx].height = max(s_current_row_height, s_new_row_height)
                            s_current_col_width = s_ws.column_dimensions['G'].width if s_ws.column_dimensions['G'].width is not None else 0
                            s_new_col_width = int(excel_plot_img2.width / 7) + 2
                            s_ws.column_dimensions['G'].width = max(s_current_col_width, s_new_col_width)
                            excel_plot_img2.anchor = f'G{row_idx}'
                            s_ws.add_image(excel_plot_img2)
                        except Exception as e:
                            self.update_log.emit(f"Error adding plot image to Excel: {e}")
                            cell_col7 = ws.cell(row=row_idx, column=7, value=f"Error: {str(e)}")
                            cell_col7.alignment = Alignment(horizontal='center', vertical='center')
                            cell_col7.fill = current_folder_fill
                            cell_col7.border = thin_border # Kẻ bảng
                    else:
                        cell_col7 = ws.cell(row=row_idx, column=7, value="No plot available")
                        cell_col7.alignment = Alignment(horizontal='center', vertical='center')
                        cell_col7.fill = current_folder_fill
                        cell_col7.border = thin_border # Kẻ bảng
                        s_cell_col7 = s_ws.cell(row=row_idx, column=7, value="No plot available")
                        s_cell_col7.alignment = Alignment(horizontal='center', vertical='center')
                        s_cell_col7.fill = current_folder_fill
                        s_cell_col7.border = thin_border
                    
                    row_idx += 1
        
        # Ensure all processed folders are included in the report
        # Track folders already included (those with CCD in best_images or in folder_notes)
        folders_in_report = set()
        
        # Add folders from best_images (folders with CCD)
        for folder_name in best_images.keys():
            folders_in_report.add(folder_name)
        
        # Add folders from folder_notes
        folder_notes = folder_notes or []
        for note in folder_notes:
            folder = note.get("folder", "-")
            if folder and folder != "-":
                folders_in_report.add(folder)
        
        # Add any missing folders that were processed but not yet in report
        if all_processed_folders:
            missing_folders = all_processed_folders - folders_in_report
            if missing_folders:
                self.update_log.emit(f"Adding {len(missing_folders)} missing folders to report: {', '.join(missing_folders)}")
                for folder_name in missing_folders:
                    folder_notes.append({
                        "folder": folder_name,
                        "ptn": "-",
                        "status": "Processed but no valid data",
                        "details": ""
                    })
        
        if folder_notes:
            note_fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
            note_font = Font(italic=True)
            for note in folder_notes:
                note_row = row_idx
                folder = note.get("folder", "-")
                ptn = note.get("ptn", "-")
                details = note.get("details", "")
                status = note.get("status", "No CCD detected")

                cell1 = ws.cell(row=note_row, column=1, value=folder)
                cell1.alignment = Alignment(horizontal='center', vertical='center')
                cell1.fill = note_fill
                cell1.border = thin_border
                cell1.font = note_font
                s_cell1 = s_ws.cell(row=note_row, column=1, value=folder)
                s_cell1.alignment = Alignment(horizontal='center', vertical='center')
                s_cell1.fill = note_fill
                s_cell1.border = thin_border
                s_cell1.font = note_font

                cell2 = ws.cell(row=note_row, column=2, value=ptn)
                cell2.alignment = Alignment(horizontal='center', vertical='center')
                cell2.fill = note_fill
                cell2.border = thin_border
                cell2.font = note_font
                s_cell2 = s_ws.cell(row=note_row, column=2, value=ptn)
                s_cell2.alignment = Alignment(horizontal='center', vertical='center')
                s_cell2.fill = note_fill
                s_cell2.border = thin_border
                s_cell2.font = note_font

                cell3 = ws.cell(row=note_row, column=3, value=details)
                cell3.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                cell3.fill = note_fill
                cell3.border = thin_border
                cell3.font = note_font
                s_cell3 = s_ws.cell(row=note_row, column=3, value=details)
                s_cell3.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                s_cell3.fill = note_fill
                s_cell3.border = thin_border
                s_cell3.font = note_font

                cell4 = ws.cell(row=note_row, column=4, value=status)
                cell4.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                cell4.fill = note_fill
                cell4.border = thin_border
                cell4.font = note_font
                s_cell4 = s_ws.cell(row=note_row, column=4, value=status)
                s_cell4.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
                s_cell4.fill = note_fill
                s_cell4.border = thin_border
                s_cell4.font = note_font
                adjust_status_cells(note_row, status)

                for col_idx in range(5, 8):
                    ws_cell = ws.cell(row=note_row, column=col_idx, value="N/A")
                    ws_cell.alignment = Alignment(horizontal='center', vertical='center')
                    ws_cell.fill = note_fill
                    ws_cell.border = thin_border
                    ws_cell.font = note_font
                    s_cell = s_ws.cell(row=note_row, column=col_idx, value="N/A")
                    s_cell.alignment = Alignment(horizontal='center', vertical='center')
                    s_cell.fill = note_fill
                    s_cell.border = thin_border
                    s_cell.font = note_font

                note_min_height = 45
                for board in (ws, s_ws):
                    current_height = board.row_dimensions[note_row].height if board.row_dimensions[note_row].height is not None else 0
                    if note_min_height > current_height:
                        board.row_dimensions[note_row].height = note_min_height
                row_idx += 1

        # Adjust column widths for text columns (final adjustment)
        ws.column_dimensions['A'].width = 25  # Folder
        ws.column_dimensions['B'].width = 20  # PTN
        ws.column_dimensions['C'].width = 20  # Coordinates
        ws.column_dimensions['D'].width = 15  # Status
        # ws.column_dimensions['G'].width = 15  # Removed Severity Score column
        
        # Save Excel file
        excel_filename = os.path.join(output_folder, "CCD_Analysis_Report.xlsx")
        try:
            wb.save(excel_filename)
            # Save summary workbook simultaneously
            summary_wb.save(summary_path)
            self.update_log.emit(f"Saved Excel report: {excel_filename}")
            try:
                self.update_log.emit(f"Summary updated: {summary_path} -> 'CCD Analysis Report'")
            except Exception:
                pass
        except Exception as e:
            self.update_log.emit(f"Error saving Excel file: {e}")
            # Try saving without images if there's an error
            excel_filename = os.path.join(output_folder, "CCD_Analysis_Report_No_Images.xlsx")
            wb.save(excel_filename)
            self.update_log.emit(f"Saved Excel report without images: {excel_filename}")
        
        # Delete temporary files after saving Excel
        for temp_file in self.temp_files_to_delete:
            if os.path.exists(temp_file):
                os.remove(temp_file)
                self.update_log.emit(f"Deleted temporary file: {temp_file}")
        self.temp_files_to_delete.clear() # Delete the list after deleting the file
        
        # Create a CSV file containing profile details
        if self.all_profile_data:
            csv_file_path = os.path.join(output_folder, "CCD_Profile_Details.csv")
            df = pd.DataFrame(self.all_profile_data)
            
            # Arrange columns for easier readability
            column_order = [
                "Folder", "File Name", "Pattern", "Resolution", "Status",
                "Model", "PTN Color", "Slope Threshold", "Deviation Threshold",
                "Horizontal Errors", "Vertical Errors", "Total Errors",
                "Severity Score", "Has CCD"
            ]
            # Only retain the columns present in the DataFrame
            available_columns = [col for col in column_order if col in df.columns]
            df = df[available_columns]
            
            # Sort by Folder and File Name
            df = df.sort_values(by=["Folder", "File Name"])
            
            # Save file CSV
            df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
            self.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
            self.update_log.emit(f"Total records in CSV: {len(df)}")
        
        return excel_filename, list(folders_with_ccd)



class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_app_window = parent # Store reference to the main application window
        self.setWindowTitle("CCD Detection Tool")
        self.resize(600, 600)
        self.setWindowIcon(QIcon(":/icons/ccd.png"))
        
        # Set light modern theme color palette
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 247, 250))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(52, 73, 94))
        self.setPalette(palette)

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Header container with gradient background
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(75)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)

        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        # Icon in header with shadow effect
        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        
        # Create a more prominent shadow effect for the icon button
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))  # Increase shadow intensity
        icon_button.setGraphicsEffect(icon_shadow)
        
        # Set a larger icon for the button
        icon = QtGui.QIcon(":/icons/ccd.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70))  # Increase icon size
        
        # Add the icon button to the header layout
        header_layout.addWidget(icon_button)

        # Title container
        title_container = QVBoxLayout()
        title_container.setSpacing(-2)

        title_label = QLabel("CCD Detection Tool")
        title_label.setFont(QFont("Segoe UI", 20, QFont.Weight.Bold))
        title_label.setStyleSheet("color: white; padding: 0; margin: 0;")

        subtitle_label = QLabel("Detect CCD issues in TIFF images automatically")
        subtitle_label.setFont(QFont("Segoe UI", 10))
        subtitle_label.setStyleSheet("color: rgba(255, 255, 255, 0.85);")
        subtitle_label.setContentsMargins(0, -5, 0, 0)

        title_container.addWidget(title_label)
        title_container.addWidget(subtitle_label)

        header_layout.addLayout(title_container)
        header_layout.addStretch()

        # Manage Models button in header
        self.btn_manage_models = QPushButton("")
        self.btn_manage_models.setIcon(QIcon(":/icons/setting.png"))
        self.btn_manage_models.setIconSize(QSize(50, 50)) # Adjust icon size for header
        self.btn_manage_models.setFixedSize(60, 60) # Smaller fixed size
        self.btn_manage_models.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_manage_models.setStyleSheet("""
            QPushButton {
                background: rgba(255, 255, 255, 0.2); /* Slightly transparent white */
                border: none;
                border-radius: 20px; /* Make it circular */
                padding: 5px;
                color: white;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.3);
            }
            QPushButton:pressed {
                background-color: rgba(255, 255, 255, 0.4);
            }
        """)
        # Add a subtle shadow to the settings button
        settings_shadow = QtWidgets.QGraphicsDropShadowEffect()
        settings_shadow.setBlurRadius(8)
        settings_shadow.setXOffset(1)
        settings_shadow.setYOffset(1)
        settings_shadow.setColor(QtGui.QColor(0, 0, 0, 60))
        self.btn_manage_models.setGraphicsEffect(settings_shadow)
        self.btn_manage_models.clicked.connect(self.manage_models)
        header_layout.addWidget(self.btn_manage_models)

        main_layout.addWidget(header_container)

        # Log text area (Moved up for early initialization)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        # Not adding to layout yet, will add later in the log_container
        
        # Controls container
        controls_container = QWidget()
        controls_container.setObjectName("controlsContainer")
        controls_container.setStyleSheet("""
            #controlsContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        controls_container.setGraphicsEffect(self.create_shadow_effect())

        controls_layout = QHBoxLayout(controls_container)
        controls_layout.setSpacing(15)

        # Model selection
        model_label = QLabel("Select Model:")
        model_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        model_label.setStyleSheet("color: #2c3e50;")
        controls_layout.addWidget(model_label)

        self.combo_model_selection = QtWidgets.QComboBox()
        self.combo_model_selection.setStyleSheet("""
            QComboBox {
                border: 2px solid #3498db;
                border-radius: 8px;
                padding: 8px 10px;
                font-size: 14px;
                color: #2c3e50;
                background-color: white;
                min-width: 100px;
            }
            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 25px;
                border-left-width: 1px;
                border-left-color: #3498db;
                border-left-style: solid;
                border-top-right-radius: 8px;
                border-bottom-right-radius: 8px;
            }
            QComboBox::down-arrow {
                image: url(:/icons/down_arrow.png);
                width: 15px;
                height: 15px;
            }
            QComboBox:hover {
                border-color: #2980b9;
            }
        """)
        controls_layout.addWidget(self.combo_model_selection)
        
        # Temporarily disconnect the signal
        self.combo_model_selection.blockSignals(True)

        self.combo_model_selection.currentTextChanged.connect(self.on_model_selected)
        initial_config = load_model_config() # Load models
        self.models_config = initial_config["models"]
        self.last_selected_model = initial_config["last_selected_model"]
        
        if not self.models_config: # If config is empty, set defaults
            self.models_config = {"D965": 721, "D914": 699}
            self.last_selected_model = "D965"
            save_model_config({"models": self.models_config, "last_selected_model": self.last_selected_model})
        
        self._load_models_to_combobox()
        # Set the current model to the last selected one, or the first available
        if self.last_selected_model and self.last_selected_model in self.models_config:
            self.combo_model_selection.setCurrentText(self.last_selected_model)
            self.selected_model = self.last_selected_model
        elif self.models_config:
            self.selected_model = next(iter(self.models_config))
            self.combo_model_selection.setCurrentText(self.selected_model)
        else:
            self.selected_model = None # No models loaded
        
        # Reconnect the signal and call the on_model_selected function to update the log and save the initial state
        self.combo_model_selection.blockSignals(False)
        if self.selected_model:
            self.on_model_selected() # Call manually to ensure initial logging and saving

        # Select folder button
        self.btn_select_folder = QPushButton("Select Folder")
        self.btn_select_folder.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_DirIcon))
        self.btn_select_folder.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_select_folder.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """)
        self.btn_select_folder.clicked.connect(self.select_folder)
        controls_layout.addWidget(self.btn_select_folder)

        # Separator
        separator = QLabel("|")
        separator.setStyleSheet("color: #3498db; font-size: 20px;")
        separator.setFixedHeight(40)
        controls_layout.addWidget(separator)

        # Start button
        self.btn_start = QPushButton("Start Checking")
        self.btn_start.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MediaPlay))
        self.btn_start.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_start.setEnabled(False)
        self.btn_start.setStyleSheet("""
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 12px;
                font-weight: bold;
                font-size: 14px;
                min-width: 140px;
                min-height: 35px;
                padding-left: 15px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                color: white;
                border: none;
            }
            QPushButton:disabled {
                background-color: #ecf0f1;
                border-color: #bdc3c7;
                color: #95a5a6;
            }
        """)
        self.btn_start.clicked.connect(self.start_checking)
        controls_layout.addWidget(self.btn_start)

        main_layout.addWidget(controls_container)

        # Progress container
        progress_container = QWidget()
        progress_container.setObjectName("progressContainer")
        progress_container.setStyleSheet("""
            #progressContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        progress_container.setGraphicsEffect(self.create_shadow_effect())

        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setSpacing(8)

        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 1px;
                text-align: center;
                height: 25px;
            }
            QProgressBar::chunk {
                background: #3498db;
                border-radius: 7px;
            }
        """)
        progress_layout.addWidget(self.progress_bar)

        main_layout.addWidget(progress_container)

        # Log container
        log_container = QWidget()
        log_container.setObjectName("logContainer")
        log_container.setStyleSheet("""
            #logContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        log_container.setGraphicsEffect(self.create_shadow_effect())

        log_layout = QVBoxLayout(log_container)
        log_layout.setSpacing(8)

        # Log header with icon
        log_header = QWidget()
        log_header_layout = QHBoxLayout(log_header)
        log_header_layout.setContentsMargins(0, 0, 0, 10)

        log_icon = QPushButton()
        log_icon.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MessageBoxInformation))
        log_icon.setIconSize(QSize(25, 25))
        log_icon.setFixedSize(25, 25)
        log_icon.setStyleSheet("""
            QPushButton {
                background: #f0f2f5;
                border: none;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        log_header_layout.addWidget(log_icon)

        log_label = QLabel("Processing Log:")
        log_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #2c3e50;")
        log_header_layout.addWidget(log_label)
        log_header_layout.addStretch()

        log_layout.addWidget(log_header)

        # Log text area
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        log_layout.addWidget(self.log_text)

        main_layout.addWidget(log_container)

        # Author info
        author_label = QLabel("Created by nguyenvanvuong1")
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        author_label.setStyleSheet("color: #3498db; padding: 0; margin: 0;")
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 25))
        return shadow

    def _load_models_to_combobox(self):
        """Loads model configurations from self.models_config into the combo box."""
        self.combo_model_selection.clear()
        for model_name in self.models_config.keys():
            self.combo_model_selection.addItem(model_name)

    def select_folder(self):
        self.selected_folder = QFileDialog.getExistingDirectory(
            self, 
            "Select Folder Containing TIFF Images",
            "",
            QFileDialog.Option.ShowDirsOnly
        )
        if self.selected_folder:
            self.log_text.append(f"Selected folder: {self.selected_folder}")
            self.btn_start.setEnabled(True)
            self.statusBar().showMessage(f"Selected folder: {os.path.basename(self.selected_folder)}")

    def on_model_selected(self):
        self.selected_model = self.combo_model_selection.currentText()
        self.last_selected_model = self.selected_model # Update last selected model
        save_model_config({"models": self.models_config, "last_selected_model": self.last_selected_model})
        self.log_text.append(f"Selected model: {self.selected_model}")

    def start_checking(self):
        if self.selected_folder:
            self.checker = CCDChecker(self.selected_folder, self.selected_model, self.models_config)  # add self.models_config
            self.checker.update_progress.connect(self.update_progress)
            self.checker.update_log.connect(self.update_log)
            self.checker.finished.connect(self.on_finished)
            self.checker.start()

            self.btn_start.setEnabled(False)
            self.statusBar().showMessage("Checking for CCD issues...")

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_log(self, message):
        self.log_text.append(message)

    def on_finished(self, ccd_folders):
        self.btn_start.setEnabled(True)
        self.statusBar().showMessage("Check completed")

        if ccd_folders:
            # Get a list of unique folders with CCD issues
            unique_folders = list(set(ccd_folders))
            message = "Folders with CCD issues:\n"
            message += "\n".join(f"- {folder}" for folder in unique_folders)
            
            # Create a styled message box
            msg = QMessageBox(self)
            msg.setWindowTitle("Check Results")
            msg.setText(message)
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: #f5f5f5;
                }
                QMessageBox QLabel {
                    font-size: 14px;
                    color: #333;
                    padding: 10px;
                }
                QPushButton {
                    background-color: #2196F3;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 12px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #1976D2;
                }
            """)
            
            # Add 'Open Report' button to QMessageBox
            open_report_button = msg.addButton("Open Report", QMessageBox.ButtonRole.ActionRole)
            open_report_button.clicked.connect(self.open_excel_report)
            open_report_button.setStyleSheet("""
                QPushButton {
                    background-color: #28a745; /* Green for success action */
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 12px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #218838;
                }
            """)
            
            msg.exec()
        else:
            msg = QMessageBox(self)
            msg.setWindowTitle("Check Results")
            msg.setText("No CCD issues found")
            msg.setIcon(QMessageBox.Icon.Information)
            msg.setStyleSheet("""
                QMessageBox {
                    background-color: #f5f5f5;
                }
                QMessageBox QLabel {
                    font-size: 14px;
                    color: #333;
                    padding: 10px;
                }
                QPushButton {
                    background-color: #2196F3;
                    color: white;
                    border: none;
                    padding: 8px 16px;
                    border-radius: 4px;
                    font-size: 12px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background-color: #1976D2;
                }
            """)
            msg.exec()

    def open_excel_report(self):
        try:
            excel_path = os.path.join(self.selected_folder, "CCD_Analysis_Results", "CCD_Analysis_Report.xlsx")
            if os.path.exists(excel_path):
                os.startfile(excel_path)
            else:
                QMessageBox.warning(self, "Error", "Excel report file not found!")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not open Excel file: {str(e)}")

    def manage_models(self):
        # Pass a copy of the current models config
        dialog = ModelManagementDialog(self.models_config.copy(), self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            # Update models_config with the changes from dialog
            # No need to reload from file since dialog already saved it
            updated_config = load_model_config()
            self.models_config = updated_config["models"]
            self.last_selected_model = updated_config["last_selected_model"]
            
            self._load_models_to_combobox()
            
            if self.last_selected_model and self.last_selected_model in self.models_config:
                self.combo_model_selection.setCurrentText(self.last_selected_model)
                self.selected_model = self.last_selected_model
            elif self.models_config:
                self.combo_model_selection.setCurrentIndex(0)
                self.selected_model = self.combo_model_selection.currentText()
            else:
                self.selected_model = None
                self.combo_model_selection.clear()
            
            self.log_text.append("Model configuration updated.")
            self.statusBar().showMessage("Model configuration updated.")

    def closeEvent(self, event):
        if self.main_app_window: # Check if main window reference exists
            self.main_app_window.setEnabled(True) # Re-enable the main window
            self.main_app_window.remove_blur_effect() # Remove blur effect from main window
        super().closeEvent(event)


class ModelManagementDialog(QtWidgets.QDialog):
    def __init__(self, current_models_config, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Manage Models and Offsets")
        self.setMinimumSize(400, 300)
        self.models_config = current_models_config.copy() # Work with a copy

        self.init_ui()
        self._load_models_to_list()

    def init_ui(self):
        main_layout = QVBoxLayout()

        # Model List
        self.model_list_widget = QtWidgets.QListWidget()
        self.model_list_widget.itemSelectionChanged.connect(self._display_selected_model_details)
        main_layout.addWidget(self.model_list_widget)

        # Input fields for Model Name and Offset
        input_layout = QFormLayout()

        self.model_name_input = QtWidgets.QLineEdit()
        self.model_name_input.setPlaceholderText("Model Name (e.g., D965)")
        input_layout.addRow("Model Name:", self.model_name_input)

        self.offset_input = QtWidgets.QLineEdit()
        self.offset_input.setPlaceholderText("Offset Value (e.g., 721)")
        self.offset_input.setValidator(QtGui.QIntValidator())
        input_layout.addRow("Offset:", self.offset_input)

        main_layout.addLayout(input_layout)

        # Buttons for Add, Update, Delete
        button_layout = QHBoxLayout()

        self.add_button = QtWidgets.QPushButton("Add Model")
        self.add_button.clicked.connect(self._add_model)
        button_layout.addWidget(self.add_button)

        self.edit_button = QtWidgets.QPushButton("Update Model")
        self.edit_button.clicked.connect(self._update_model)
        self.edit_button.setEnabled(False) # Enabled when an item is selected
        button_layout.addWidget(self.edit_button)

        self.delete_button = QtWidgets.QPushButton("Delete Model")
        self.delete_button.clicked.connect(self._delete_model)
        self.delete_button.setEnabled(False) # Enabled when an item is selected
        button_layout.addWidget(self.delete_button)

        main_layout.addLayout(button_layout)

        # Dialog buttons (Save and Cancel)
        dialog_button_box = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Save | QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        dialog_button_box.accepted.connect(self.accept) # Connect to accept and save
        dialog_button_box.rejected.connect(self.reject) # Connect to reject and discard
        main_layout.addWidget(dialog_button_box)

        self.setLayout(main_layout)

    def _load_models_to_list(self):
        self.model_list_widget.clear()
        for model_name, offset in self.models_config.items():
            self.model_list_widget.addItem(f"{model_name}: {offset}")

    def _display_selected_model_details(self):
        selected_items = self.model_list_widget.selectedItems()
        if selected_items:
            selected_text = selected_items[0].text()
            model_name, offset_str = selected_text.split(": ", 1) # Limit split to 1
            self.model_name_input.setText(model_name)
            self.offset_input.setText(offset_str)
            self.add_button.setEnabled(False)
            self.edit_button.setEnabled(True)
            self.delete_button.setEnabled(True)
        else:
            self.model_name_input.clear()
            self.offset_input.clear()
            self.add_button.setEnabled(True)
            self.edit_button.setEnabled(False)
            self.delete_button.setEnabled(False)

    def _add_model(self):
        model_name = self.model_name_input.text().strip()
        offset_str = self.offset_input.text().strip()
        if not model_name or not offset_str:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Model Name and Offset cannot be empty.")
            return
        try:
            offset = int(offset_str)
        except ValueError:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Offset must be an integer.")
            return
        
        if model_name in self.models_config:
            QtWidgets.QMessageBox.warning(self, "Input Error", f"Model '{model_name}' already exists. Use Update Model to change it.")
            return
            
        self.models_config[model_name] = offset
        self._load_models_to_list()
        self.model_name_input.clear()
        self.offset_input.clear()
        self.add_button.setEnabled(True) # Re-enable add after adding
        self.edit_button.setEnabled(False)
        self.delete_button.setEnabled(False)

    def _update_model(self):
        selected_items = self.model_list_widget.selectedItems()
        if not selected_items:
            QtWidgets.QMessageBox.warning(self, "Selection Error", "Please select a model to update.")
            return
        
        old_model_name = selected_items[0].text().split(": ")[0]
        new_model_name = self.model_name_input.text().strip()
        offset_str = self.offset_input.text().strip()
        
        if not new_model_name or not offset_str:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Model Name and Offset cannot be empty.")
            return
        try:
            offset = int(offset_str)
        except ValueError:
            QtWidgets.QMessageBox.warning(self, "Input Error", "Offset must be an integer.")
            return
        
        # Handle renaming a model
        if old_model_name != new_model_name:
            if new_model_name in self.models_config and new_model_name != old_model_name:
                QtWidgets.QMessageBox.warning(self, "Input Error", f"Model '{new_model_name}' already exists.")
                return
            self.models_config.pop(old_model_name) # Remove old entry
        
        self.models_config[new_model_name] = offset
        self._load_models_to_list()
        self.model_name_input.clear()
        self.offset_input.clear()
        self.add_button.setEnabled(True) # Re-enable add after updating
        self.edit_button.setEnabled(False)
        self.delete_button.setEnabled(False)

    def _delete_model(self):
        selected_items = self.model_list_widget.selectedItems()
        if not selected_items:
            QtWidgets.QMessageBox.warning(self, "Selection Error", "Please select a model to delete.")
            return
        
        model_to_delete = selected_items[0].text().split(": ")[0]
        reply = QtWidgets.QMessageBox.question(self, "Confirm Delete", 
                                               f"Are you sure you want to delete model '{model_to_delete}'?",
                                               QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No)
        
        if reply == QtWidgets.QMessageBox.StandardButton.Yes:
            self.models_config.pop(model_to_delete)
            self._load_models_to_list()
            self.model_name_input.clear()
            self.offset_input.clear()
            self.add_button.setEnabled(True)
            self.edit_button.setEnabled(False)
            self.delete_button.setEnabled(False)

    def accept(self):
        save_model_config(self.models_config)
        super().accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())