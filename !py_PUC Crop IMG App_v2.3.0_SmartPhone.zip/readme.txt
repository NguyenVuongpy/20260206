# PUC Crop Image Analysis Tool - Hướng dẫn sử dụng

## Giới thiệu
PUC Crop Image Analysis Tool là ứng dụng chuyên dụng để sao chép và phân tích ảnh PUC Crop từ các máy trong mạng nội bộ. Ứng dụng hỗ trợ cả ảnh 1stPUC (Mono) và 2ndPUC (Color).

## Các tính năng chính

### 1. Sao chép ảnh PUC Crop
#### 1.1. Chọn ngày
- Chọn ngày bắt đầu và ngày kết thúc từ lịch
- Có thể mở/đóng lịch bằng nút calendar
- Ngày kết thúc phải sau hoặc bằng ngày bắt đầu

#### 1.2. Chọn Line
- Tick chọn một hoặc nhiều line cần sao chép ảnh
- Các line được hiển thị dưới dạng checkbox
- Phải chọn ít nhất 1 line trước khi sao chép

#### 1.3. Chọn Pattern
- Chọn pattern cho 1stPUC từ dropdown "1stPUC Folder"
- Chọn pattern cho 2ndPUC từ dropdown "2ndPUC Folder"
- Các pattern được cấu hình trong phần Settings

#### 1.4. Số lượng folder
- Nhập số lượng folder muốn sao chép trong ô "Number of folders to copy"
- Mặc định là 5 folder

#### 1.5. Thực hiện sao chép
- Nhấn "Loading 1stPUC Crop" để sao chép ảnh 1stPUC
- Nhấn "Loading 2ndPUC Crop" để sao chép ảnh 2ndPUC
- Quá trình sao chép sẽ hiển thị trong khung Processing Log

### 2. Chuyển đổi và phân tích ảnh

#### 2.1. Chuyển đổi ảnh (Convert JPG)
- Chuyển đổi ảnh từ định dạng TIF sang JPG
- Cho phép điều chỉnh chất lượng ảnh
- Giữ nguyên cấu trúc thư mục

#### 2.2. Chèn ảnh vào Excel (Insert to Excel)
- Chọn template Excel
- Chọn ảnh JPG cần chèn
- Thiết lập kích thước ảnh
- Tự động chèn vào các ô được chỉ định

#### 2.3. Kiểm tra cường độ sáng (Check Intensity)
- Phân tích pattern Mono/Color
- Tính toán cường độ trung bình
- So sánh giữa các camera
- Xuất biểu đồ cường độ


#### 2.4. Kiểm tra hotpixel (HotPixel Derector)
- Chọn đường dẫn chứa các folder có ảnh tif cần kiểm tra
- Kiểm tra trong các ảnh tif, nếu có it nhất 3 ảnh ở cùng 1 PTN mà bị hotpixel ở cùng 1 vị trí thì camera đó bị hotpixel
- Xuất ra excel để dễ quan sát tổng quan: tên camera bị hotpixel, vị trí bị hotpixel, ảnh đánh dấu vị trí hotpixel, ảnh crop vị trí hotpixel

### 3. Cài đặt (Settings)

#### 3.1. Quản lý Line
- Thêm/Sửa/Xóa các line
- Line mới sẽ tự động được thêm vào giao diện chính
- Format tên line: "XXX Line" (ví dụ: "501 Line")

#### 3.2. Quản lý Pattern
- Thêm/Sửa/Xóa pattern cho 1stPUC và 2ndPUC
- Pattern mới sẽ được thêm vào dropdown tương ứng
- Đặt tên pattern theo quy chuẩn (ví dụ: X2146A_P2_Mono_DEV_Glossy_ver1)

#### 3.3. Quản lý Credentials
- Thêm/Sửa/Xóa thông tin đăng nhập
- Hỗ trợ nhiều tài khoản
- Thông tin được mã hóa và lưu an toàn

#### 3.4. Cài đặt đường dẫn (Path Settings)
- Tùy chỉnh đường dẫn cơ sở cho 1stPUC và 2ndPUC
- Mặc định là "d\\POCB\\HEX"
- Đường dẫn mới sẽ được áp dụng cho việc sao chép ảnh

## Lưu ý quan trọng

### Quy trình làm việc khuyến nghị
1. Cấu hình các thông số trong Settings trước khi sử dụng
2. Kiểm tra kết nối mạng đến các máy
3. Chọn ngày, line và pattern phù hợp
4. Thực hiện sao chép ảnh
5. Chuyển đổi và phân tích ảnh theo nhu cầu

### Xử lý lỗi thường gặp
- Nếu không kết nối được máy: Kiểm tra credentials và mạng NB
- Nếu không tìm thấy ảnh: Kiểm tra đường dẫn và pattern
- Nếu lỗi sao chép: Kiểm tra quyền truy cập và không gian đĩa

### Bảo mật
- Không chia sẻ thông tin đăng nhập
- Đăng xuất sau khi sử dụng
- Cập nhật mật khẩu định kỳ

## Thông tin thêm
- Tác giả: nguyenvanvuongvmu@gmail.com
- Phiên bản: 2.0
- Liên hệ hỗ trợ: [Nguyễn Văn Vương-Medium PUC] 