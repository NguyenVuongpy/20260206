import sys
import os
import pandas as pd
from datetime import datetime, timedelta
import shutil
import time
import glob
import numpy as np
from PIL import Image 
from PyQt6.QtWidgets import QMessageBox
import subprocess
import json

def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

def clear_destination_directories(mono_only=False, color_only=False, log_callback=None):
    """Delete all data in the destination folder before copying."""
    directories_to_clear = []
    
    if mono_only:
        directories_to_clear.append(os.path.join(script_dir, 'PUC1 Crop Images'))
    elif color_only:
        directories_to_clear.append(os.path.join(script_dir, 'PUC2 Crop Images'))
    else:
        directories_to_clear = [
            os.path.join(script_dir, 'PUC1 Crop Images'),
            os.path.join(script_dir, 'PUC2 Crop Images')
        ]
    
    for directory in directories_to_clear:
        if os.path.exists(directory):
            try:
                deleted_count = 0
                deleted_folders = 0
                # Delete all files and subfolders.
                for item in os.listdir(directory):
                    item_path = os.path.join(directory, item)
                    if os.path.isfile(item_path):
                        os.remove(item_path)
                        deleted_count += 1
                    elif os.path.isdir(item_path):
                        shutil.rmtree(item_path)
                        deleted_folders += 1
                
                log_message = f"Cleared directory: {directory} - Deleted {deleted_count} files and {deleted_folders} folders"
                if log_callback:
                    log_callback(log_message)
                else:
                    print(log_message)
            except Exception as e:
                error_message = f"Error clearing directory {directory}: {str(e)}"
                if log_callback:
                    log_callback(error_message)
                else:
                    print(error_message)

def authenticate_share(ip):
    """Authenticate access to the shared drive"""
    try:
        # Read config from file
        config = {'lines': [], 'credentials': [{'username': 'user', 'password': '1'}]}
        if os.path.exists('app_config.json'):
            with open('app_config.json', 'r') as f:
                config = json.load(f)
        
        credentials = config.get('credentials', [{'username': 'user', 'password': '1'}])
        
        # Try each credential until you succeed
        for cred in credentials:
            username = cred.get('username')
            password = cred.get('password')
            
            command = f'net use \\\\{ip} /user:{username} {password}'
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            
            if result.returncode == 0:
                return True
                
        return False
    except Exception as e:
        print(f"Authentication error: {str(e)}")
        return False

def copy_logs_mono(start_date, end_date, selected_lines, selected_folder, folder_count=8, log_callback=None):
    # Delete only PUC1 Crop Images directory before copying mono
    if log_callback:
        log_callback("Clearing PUC1 destination directory before mono copy...")
    clear_destination_directories(mono_only=True, log_callback=log_callback)
    
    csv_path = os.path.join(script_dir, 'IP_List.csv')
    df = pd.read_csv(csv_path, index_col=None, sep=',', header=0)
    #Drop NaN values in the 'PUC1 Name' column
    df = df.dropna(subset=['PUC1 Name']) 
    if selected_lines:
        df = df[df['PUC1 Name'].str.contains('|'.join(selected_lines))]
    
    pc_info = [(str(row['PUC1 Name']), str(row['PUC1 IP'])) for index, row in df.iterrows()]
    inaccessible_machines = set()
    authenticated_ips = set()

    for name, ip in pc_info:
        if ip not in authenticated_ips:
            if log_callback:
                log_callback(f"Authenticating access to {ip}...")
            
            if authenticate_share(ip):
                authenticated_ips.add(ip)
                if log_callback:
                    log_callback(f"Authentication successful for {ip}")
            else:
                if log_callback:
                    log_callback(f"Authentication failed for {ip}")
                inaccessible_machines.add(f'{name}\\{ip}')
                continue

        files_found = False
        current_date = start_date
        while current_date <= end_date:
            month_str = current_date.strftime('%m')
            day_str = current_date.strftime('%d')
            date_yyyymmdd = current_date.strftime('%Y%m%d')
            
            # List of paths to try in order of priority
            possible_paths = [
                # Structure: {drive}:\POCB\HEX\{folder}\{MM}\{DD}
                f'\\\\{ip}\\d\\POCB\\HEX\\{selected_folder}\\{month_str}\\{day_str}',
                f'\\\\{ip}\\e\\POCB\\HEX\\{selected_folder}\\{month_str}\\{day_str}',
                
                # Structure: {drive}:\POCB\HEX\{YYYYMMDD}\{folder}
                f'\\\\{ip}\\d\\POCB\\HEX\\{date_yyyymmdd}\\{selected_folder}',
                f'\\\\{ip}\\e\\POCB\\HEX\\{date_yyyymmdd}\\{selected_folder}'
            ]
            
            src_dir = None
            for path in possible_paths:
                if os.path.exists(path):
                    src_dir = path
                    if log_callback:
                        log_callback(f"Found source directory: {src_dir}")
                    break
            
            if not src_dir:
                if log_callback:
                    log_callback(f"Source directory not found for {name}\\{ip} on {current_date.strftime('%Y-%m-%d')}")
                current_date += timedelta(days=1)
                continue
                
            dest_dir = os.path.join(script_dir, 'PUC1 Crop Images', name)

            try:
                if os.path.exists(src_dir):
                    # Get the list of subdirectories and sort by modification time (newest first).
                    subfolders = []
                    for f in os.listdir(src_dir):
                        folder_path = os.path.join(src_dir, f)
                        if os.path.isdir(folder_path):
                            # Get the directory modification time.
                            try:
                                mtime = os.path.getmtime(folder_path)
                                subfolders.append((f, mtime))
                            except (OSError, FileNotFoundError):
                                # If the modified time is not available, use the current time.
                                subfolders.append((f, time.time()))
                    
                    # Sort by date of modification (newest first)
                    subfolders.sort(key=lambda x: x[1], reverse=True)
                    
                    # Get the folder names after sorting.
                    sorted_folder_names = [f[0] for f in subfolders]
                    sorted_folder_names = sorted_folder_names[:int(folder_count)]
                    
                    if log_callback:
                        log_callback(f"Found {len(sorted_folder_names)} folders, copying from newest {folder_count} folders")

                    for folder in sorted_folder_names:
                        folder_path = os.path.join(src_dir, folder)
                        # Only include .tif files and exclude files with the "_ori.tif" extension
                        tif_files = [f for f in os.listdir(folder_path) 
                                    if f.endswith('.tif') and not f.endswith('_ori.tif')]

                        if tif_files:
                            files_found = True
                            if not os.path.exists(dest_dir):
                                os.makedirs(dest_dir)
                                if log_callback:
                                    log_callback(f"Created destination directory: {dest_dir}")
                            
                            for filename in tif_files:
                                src_file = os.path.join(folder_path, filename)

                                # Create a new file name
                                folder_name = folder.split('_')[0]  # Take the part of the name before the symbol '_'
                                parts = filename.split('_')
                                # Extract the necessary parts from the file name
                                step_info = '_'.join(parts[:2]) 
                                color_info = parts[2]            
                                
                                # Create a new file name
                                new_filename = f"{folder_name}_{step_info}_{color_info}.tif"
                                dest_file = os.path.join(dest_dir, new_filename)

                                shutil.copy2(src_file, dest_file)
                                if log_callback:
                                    log_callback(f"Copied: {dest_file}")
                        else:
                            if log_callback:
                                log_callback(f"No .tif files found in folder: {folder}")
            except Exception as e:
                if f'{name}\\{ip}' not in inaccessible_machines:
                    inaccessible_machines.add(f'{name}\\{ip}')
                    if log_callback:
                        log_callback(f"Error accessing {name}\\{ip}: {str(e)}")
            
            current_date += timedelta(days=1)
        
        if not files_found:
            if log_callback:
                log_callback(f"No .tif files found for {name}\\{ip} in the specified date range")
        else:
            if log_callback:
                log_callback(f"Successfully copied files from {name}\\{ip}")

    if inaccessible_machines:
        message = 'The following machines were inaccessible:\n' + '\n'.join(sorted(inaccessible_machines))
        if log_callback:
            log_callback(message)
        QMessageBox.warning(None, 'Warning', message)
    else:
        if log_callback:
            log_callback('All machines were accessible.')
        QMessageBox.information(None, 'Success', 'All machines were accessible.')


def copy_logs_color(start_date, end_date, selected_lines, selected_folder, folder_count=8, log_callback=None):
    # Delete only PUC2 Crop Images directory before copying color
    if log_callback:
        log_callback("Clearing PUC2 destination directory before color copy...")
    clear_destination_directories(color_only=True, log_callback=log_callback)
    
    csv_path = os.path.join(script_dir, 'IP_List.csv')
    df = pd.read_csv(csv_path, index_col=None, sep=',', header=0)
    #Drop NaN values in the 'PUC2 Name' column
    df = df.dropna(subset=['PUC2 Name'])    
    if selected_lines:
        df = df[df['PUC2 Name'].str.contains('|'.join(selected_lines))]
    
    pc_info = [(str(row['PUC2 Name']), str(row['PUC2 IP'])) for index, row in df.iterrows()]
    inaccessible_machines = set()
    authenticated_ips = set()

    for name, ip in pc_info:
        if ip not in authenticated_ips:
            if log_callback:
                log_callback(f"Authenticating access to {ip}...")
            
            if authenticate_share(ip):
                authenticated_ips.add(ip)
                if log_callback:
                    log_callback(f"Authentication successful for {ip}")
            else:
                if log_callback:
                    log_callback(f"Authentication failed for {ip}")
                inaccessible_machines.add(f'{name}\\{ip}')
                continue

        files_found = False
        current_date = start_date
        while current_date <= end_date:
            month_str = current_date.strftime('%m')
            day_str = current_date.strftime('%d')
            date_yyyymmdd = current_date.strftime('%Y%m%d')
            
            # List of paths to try in order of priority
            possible_paths = [
                # Structure: {drive}:\POCB\HEX\{folder}\{MM}\{DD}
                f'\\\\{ip}\\d\\POCB\\HEX\\{selected_folder}\\{month_str}\\{day_str}',
                f'\\\\{ip}\\e\\POCB\\HEX\\{selected_folder}\\{month_str}\\{day_str}',
                
                # Structure: {drive}:\POCB\HEX\{YYYYMMDD}\{folder}
                f'\\\\{ip}\\d\\POCB\\HEX\\{date_yyyymmdd}\\{selected_folder}',
                f'\\\\{ip}\\e\\POCB\\HEX\\{date_yyyymmdd}\\{selected_folder}'
            ]
            
            src_dir = None
            for path in possible_paths:
                if os.path.exists(path):
                    src_dir = path
                    if log_callback:
                        log_callback(f"Found source directory: {src_dir}")
                    break
            
            if not src_dir:
                if log_callback:
                    log_callback(f"Source directory not found for {name}\\{ip} on {current_date.strftime('%Y-%m-%d')}")
                current_date += timedelta(days=1)
                continue
                
            dest_dir = os.path.join(script_dir, 'PUC2 Crop Images', name)

            try:
                if os.path.exists(src_dir):
                    # Get the list of subdirectories and sort by modification time (newest first).
                    subfolders = []
                    for f in os.listdir(src_dir):
                        folder_path = os.path.join(src_dir, f)
                        if os.path.isdir(folder_path):
                            # Get the directory modification time.
                            try:
                                mtime = os.path.getmtime(folder_path)
                                subfolders.append((f, mtime))
                            except (OSError, FileNotFoundError):
                                # If the modified time is not available, use the current time.
                                subfolders.append((f, time.time()))
                    
                    # Sort by date of modification (newest first)
                    subfolders.sort(key=lambda x: x[1], reverse=True)
                    
                    # Get the folder names after sorting.
                    sorted_folder_names = [f[0] for f in subfolders]
                    sorted_folder_names = sorted_folder_names[:int(folder_count)]
                    
                    if log_callback:
                        log_callback(f"Found {len(sorted_folder_names)} folders, copying from newest {folder_count} folders")

                    for folder in sorted_folder_names:
                        folder_path = os.path.join(src_dir, folder)
                        # Only include .tif files and exclude files with the "_ori.tif" extension
                        tif_files = [f for f in os.listdir(folder_path) 
                                    if f.endswith('.tif') and not f.endswith('_ori.tif')]

                        if tif_files:
                            files_found = True
                            if not os.path.exists(dest_dir):
                                os.makedirs(dest_dir)
                                if log_callback:
                                    log_callback(f"Created destination directory: {dest_dir}")
                            
                            for filename in tif_files:
                                src_file = os.path.join(folder_path, filename)

                                # Create a new file name.
                                folder_name = folder.split('_')[0]  # Take the part of the name before the symbol '_'
                                parts = filename.split('_')
                                # Extract the necessary parts from the file name
                                step_info = '_'.join(parts[:2]) 
                                color_info = parts[2]            
                                
                                # Create a new file name
                                new_filename = f"{folder_name}_{step_info}_{color_info}.tif"
                                dest_file = os.path.join(dest_dir, new_filename)

                                shutil.copy2(src_file, dest_file)
                                if log_callback:
                                    log_callback(f"Copied: {dest_file}")
                        else:
                            if log_callback:
                                log_callback(f"No .tif files found in folder: {folder}")
            except Exception as e:
                if f'{name}\\{ip}' not in inaccessible_machines:
                    inaccessible_machines.add(f'{name}\\{ip}')
                    if log_callback:
                        log_callback(f"Error accessing {name}\\{ip}: {str(e)}")
            
            current_date += timedelta(days=1)
        
        if not files_found:
            if log_callback:
                log_callback(f"No .tif files found for {name}\\{ip} in the specified date range")
        else:
            if log_callback:
                log_callback(f"Successfully copied files from {name}\\{ip}")

    if inaccessible_machines:
        message = 'The following machines were inaccessible:\n' + '\n'.join(sorted(inaccessible_machines))
        if log_callback:
            log_callback(message)
        QMessageBox.warning(None, 'Warning', message)
    else:
        if log_callback:
            log_callback('All machines were accessible.')
        QMessageBox.information(None, 'Success', 'All machines were accessible.')